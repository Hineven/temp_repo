#!/usr/bin/env python3
"""
AO 补全脚本 - 方案B
Phase 1: 为每个模型烘焙AO贴图（每模型一张，UV空间）
Phase 2: 为每个视角渲染AO输出（加载AO贴图 + Emission Shader）

用法:
    blender scene.blend --background --python batch_ao.py
"""

import bpy
import json
import os
import sys
from pathlib import Path
from mathutils import Vector, Euler

# ============================================================================
# CONFIG
# ============================================================================

SCRIPT_DIR = Path(__file__).parent.resolve()
DATASET_DIR = SCRIPT_DIR / "dataset"
AO_BAKED_DIR = SCRIPT_DIR / "ao_baked"
ITEMS_DIR = SCRIPT_DIR / "Items"

RESOLUTION = 1024
AO_BAKE_SAMPLES = 128
AO_RENDER_SAMPLES = 1

# ============================================================================
# UTILITIES
# ============================================================================

def get_mesh_obj(obj):
    """获取根mesh物体（处理有子物体的GLB导入）"""
    if obj.type == 'MESH':
        return obj
    meshes = [c for c in obj.children_recursive if c.type == 'MESH']
    return meshes[0] if meshes else obj


def clear_scene_model():
    """删除名为 Model 的物体及其mesh数据"""
    if "Model" in bpy.data.objects:
        obj = bpy.data.objects["Model"]
        data = obj.data
        bpy.data.objects.remove(obj)
        if data and data.users == 0:
            if data.__class__.__name__ == 'Mesh':
                bpy.data.meshes.remove(data)


def import_glb(filepath):
    """导入GLB并返回根物体"""
    existing = set(bpy.context.scene.objects)
    bpy.ops.import_scene.gltf(filepath=str(filepath))
    new_objs = [o for o in bpy.context.scene.objects if o not in existing]

    root_meshes = [o for o in new_objs if o.type == 'MESH' and o.parent is None]
    if root_meshes:
        root = root_meshes[0]
    else:
        meshes = [o for o in new_objs if o.type == 'MESH']
        root = meshes[0] if meshes else new_objs[0]

    root.name = "Model"
    return root


def setup_camera():
    """获取或创建场景相机"""
    scene = bpy.context.scene
    if "Camera" in bpy.data.objects and bpy.data.objects["Camera"].type == 'CAMERA':
        return bpy.data.objects["Camera"]
    cam_data = bpy.data.cameras.new("Camera")
    cam_obj = bpy.data.objects.new("Camera", cam_data)
    scene.collection.objects.link(cam_obj)
    scene.camera = cam_obj
    return cam_obj


def set_render_for_ao_bake():
    """配置Cycles用于AO烘焙"""
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    cycles = scene.cycles
    cycles.samples = AO_BAKE_SAMPLES
    cycles.device = 'GPU'
    prefs = bpy.context.preferences
    cpref = prefs.addons['cycles'].preferences
    cpref.get_devices()
    for device in cpref.devices:
        device.use = True


def set_render_for_ao_view():
    """配置Cycles用于AO视角渲染（AO贴图已烘焙，只需1 sample）"""
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    cycles = scene.cycles
    cycles.samples = AO_RENDER_SAMPLES
    cycles.device = 'GPU'
    cycles.use_denoising = False
    scene.render.resolution_x = RESOLUTION
    scene.render.resolution_y = RESOLUTION
    scene.render.resolution_percentage = 100
    scene.render.use_compositing = False
    scene.use_nodes = False


# ============================================================================
# PHASE 1: BAKE AO TEXTURE
# ============================================================================

def bake_ao_for_model(obj, output_path):
    """
    为模型烘焙AO贴图到UV空间。
    如果output_path已存在，直接加载返回。
    """
    if os.path.exists(output_path):
        print(f"  AO already baked: {output_path}")
        img_name = f"AO_{obj.name}"
        if img_name in bpy.data.images:
            bpy.data.images.remove(bpy.data.images[img_name])
        return bpy.data.images.load(str(output_path))

    set_render_for_ao_bake()
    target = get_mesh_obj(obj)

    # 确保UV
    if not target.data.uv_layers:
        target.data.uv_layers.new(name="UVMap")

    # 创建Image
    img_name = f"AO_{target.name}"
    if img_name in bpy.data.images:
        bpy.data.images.remove(bpy.data.images[img_name])
    img = bpy.data.images.new(img_name, width=RESOLUTION, height=RESOLUTION)

    # 创建临时烘焙材质
    bake_mat = bpy.data.materials.new(name=f"BakeAO_{target.name}")
    bake_mat.use_nodes = True
    nt = bake_mat.node_tree
    for node in list(nt.nodes):
        nt.nodes.remove(node)

    img_tex = nt.nodes.new(type='ShaderNodeTexImage')
    img_tex.image = img
    img_tex.name = "BakeTarget"
    img_tex.location = (0, 0)
    img_tex.select = True
    nt.nodes.active = img_tex

    output = nt.nodes.new(type='ShaderNodeOutputMaterial')
    output.location = (300, 0)
    nt.links.new(img_tex.outputs['Color'], output.inputs['Surface'])

    # 保存原材质并替换
    orig_materials = [slot.material for slot in target.material_slots]
    while len(target.material_slots) > 0:
        target.active_material_index = 0
        bpy.ops.object.material_slot_remove()
    target.data.materials.append(bake_mat)

    # 选中和烘焙
    bpy.ops.object.select_all(action='DESELECT')
    target.select_set(True)
    bpy.context.view_layer.objects.active = target

    bpy.context.scene.cycles.bake_type = 'AO'
    bpy.context.scene.render.bake.margin = 4

    print(f"  Baking AO...")
    bpy.ops.object.bake(type='AO')
    print(f"  AO baked!")

    # 保存
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    img.filepath_raw = str(output_path)
    img.file_format = 'PNG'
    img.save()
    print(f"  AO saved: {output_path}")

    # 恢复原材质
    target.data.materials.clear()
    for mat in orig_materials:
        if mat:
            target.data.materials.append(mat)
    bpy.data.materials.remove(bake_mat)

    return img


# ============================================================================
# PHASE 2: RENDER AO VIEW
# ============================================================================

def render_ao_view(obj, ao_img, camera_pos, camera_rot, output_path):
    """
    从指定相机位置，使用AO贴图渲染AO输出。
    如果output_path已存在，跳过。
    """
    if os.path.exists(output_path):
        return

    set_render_for_ao_view()

    camera = setup_camera()
    camera.location = Vector(camera_pos)
    camera.rotation_euler = Euler(camera_rot)

    target = get_mesh_obj(obj)

    # 创建AO渲染材质: AO贴图 → Emission
    ao_mat_name = "AO_Render_Material"
    if ao_mat_name in bpy.data.materials:
        bpy.data.materials.remove(bpy.data.materials[ao_mat_name])

    ao_mat = bpy.data.materials.new(name=ao_mat_name)
    ao_mat.use_nodes = True
    nt = ao_mat.node_tree
    for node in list(nt.nodes):
        nt.nodes.remove(node)

    img_tex = nt.nodes.new(type='ShaderNodeTexImage')
    img_tex.image = ao_img
    img_tex.location = (-300, 0)

    emission = nt.nodes.new(type='ShaderNodeEmission')
    emission.location = (0, 0)
    nt.links.new(img_tex.outputs['Color'], emission.inputs['Color'])

    output_node = nt.nodes.new(type='ShaderNodeOutputMaterial')
    output_node.location = (300, 0)
    nt.links.new(emission.outputs['Emission'], output_node.inputs['Surface'])

    # 替换材质
    orig_materials = [slot.material for slot in target.material_slots]
    while len(target.material_slots) > 0:
        target.active_material_index = 0
        bpy.ops.object.material_slot_remove()
    target.data.materials.append(ao_mat)

    # 渲染
    scene = bpy.context.scene
    scene.render.filepath = str(output_path)
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGB'
    scene.render.image_settings.color_depth = '16'

    bpy.ops.render.render(write_still=True)

    # 恢复原材质
    target.data.materials.clear()
    for mat in orig_materials:
        if mat:
            target.data.materials.append(mat)
    bpy.data.materials.remove(ao_mat)


# ============================================================================
# MAIN
# ============================================================================

def main():
    print("=" * 60)
    print("AO Bake + Render Batch")
    print("=" * 60)

    # CLI args (Blender style: blender ... -- --dataset_dir ... --model ...)
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_dir", default=None,
                        help="目标 dataset 目录（默认 ./dataset）")
    parser.add_argument("--model", default=None, help="只处理指定模型")
    cli = parser.parse_args(argv)
    dataset_dir = Path(cli.dataset_dir).resolve() if cli.dataset_dir else DATASET_DIR

    # 收集所有模型
    models = sorted([p.stem for p in ITEMS_DIR.glob("*.glb")])
    if cli.model:
        models = [m for m in models if m == cli.model]
    print(f"Models: {models}")
    print(f"Dataset dir: {dataset_dir}")
    print(f"Total models: {len(models)}")

    total_views = 0
    completed_views = 0
    skipped_views = 0

    for model_name in models:
        print(f"\n{'='*60}")
        print(f"Model: {model_name}")
        print(f"{'='*60}")

        # Phase 1: 烘焙AO贴图
        glb_path = ITEMS_DIR / f"{model_name}.glb"
        ao_tex_path = AO_BAKED_DIR / f"{model_name}_ao.png"

        clear_scene_model()
        obj = import_glb(str(glb_path))
        ao_img = bake_ao_for_model(obj, str(ao_tex_path))

        model_dir = dataset_dir / model_name
        if not model_dir.exists():
            print(f"  No dataset found for {model_name}, skipping Phase 2")
            continue

        # Phase 2: 逐变体逐视角渲染AO
        for variant_dir in sorted(model_dir.glob("variant_*")):
            variant_name = variant_dir.name
            print(f"  {variant_name}")

            # 读取第一个view的metadata获取模型旋转
            first_view_dir = sorted(variant_dir.glob("view_*"))[0]
            meta_path = first_view_dir / "metadata.json"
            with open(meta_path) as f:
                meta = json.load(f)
            model_rot = Euler(meta['model_transform']['rotation_euler'])

            # 应用旋转
            obj.location = Vector((0, 0, 0))
            obj.rotation_euler = model_rot
            obj.scale = Vector((1, 1, 1))

            for view_dir in sorted(variant_dir.glob("view_*")):
                total_views += 1
                ao_output = view_dir / "ao.png"

                if ao_output.exists():
                    skipped_views += 1
                    continue

                # 读取metadata获取相机参数
                meta_path = view_dir / "metadata.json"
                with open(meta_path) as f:
                    meta = json.load(f)

                cam_pos = meta['camera']['location']
                cam_rot = meta['camera']['rotation_euler']

                render_ao_view(obj, ao_img, cam_pos, cam_rot, str(ao_output))
                completed_views += 1

                if completed_views % 50 == 0:
                    print(f"    Progress: {completed_views} views rendered, {skipped_views} skipped")

    print(f"\n{'='*60}")
    print("AO Batch Complete!")
    print(f"  Total views: {total_views}")
    print(f"  Rendered: {completed_views}")
    print(f"  Skipped (already exist): {skipped_views}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
