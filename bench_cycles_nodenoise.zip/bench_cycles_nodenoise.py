#!/usr/bin/env python3
"""
Cycles 不降噪基准 —— 用于分解固定开销 / 边际采样成本 / 降噪开销。

复用 bench_cycles.py 方法，仅覆盖 RENDER_CONFIGS 为不降噪档位，与已测的降噪
1/4/16spp 配对比较，并加一个高 spp (256) 不降噪来钉死边际采样成本 k。

  blender scene.blend --background --python bench_cycles_nodenoise.py -- \
      --out benchmark_cycles_nodenoise.json
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bench_cycles as BC

BC.RENDER_CONFIGS = [
    ("cycles_1spp_nodenoise", 1, False, 1, 3),
    ("cycles_16spp_nodenoise", 16, False, 1, 3),
    ("cycles_256spp_nodenoise", 256, False, 1, 3),
]

if __name__ == "__main__":
    BC.main()
