#!/usr/bin/env python3
"""
Cycles 低采样基准 —— 1spp + 降噪 / 4spp + 降噪（71.glb）。

复用 bench_cycles.py 的全部方法（视角重建、sRGB-L1/MSE 指标、计时），仅覆盖
RENDER_CONFIGS 为低采样档位。运行方式与 bench_cycles 相同：

  blender scene.blend --background --python bench_cycles_lowspp.py -- \
      --out benchmark_cycles_lowspp.json
"""
import sys
from pathlib import Path

# bench_cycles 与本脚本同目录；必须由 blender 运行（顶部 import bpy）
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bench_cycles as BC

# 1spp / 4spp + 降噪，其余沿用 16spp 的计时设定（1 次 warmup + 3 次计时）
BC.RENDER_CONFIGS = [
    ("cycles_1spp_denoise", 1, True, 1, 3),
    ("cycles_4spp_denoise", 4, True, 1, 3),
]

if __name__ == "__main__":
    BC.main()
