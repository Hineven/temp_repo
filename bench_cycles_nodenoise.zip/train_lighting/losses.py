"""
Loss functions shared across experiments.

Kept dependency-free (torch only) so any experiment can import them without
pulling in the training engine.
"""

import torch
import torch.nn as nn


class MaskedL1Loss(nn.Module):
    """Masked L1 loss: only count object pixels."""
    def __init__(self):
        super().__init__()

    def forward(self, pred, target, mask):
        diff = (pred - target).abs()
        loss = (diff * mask).sum() / (mask.sum() + 1e-8)
        return loss


def _image_grad(x):
    """First-order image gradients of [B, C, H, W]. Returns (dx, dy).

    dx: difference along W  -> [B, C, H, W-1]
    dy: difference along H  -> [B, C, H-1, W]
    """
    dx = x[:, :, :, 1:] - x[:, :, :, :-1]
    dy = x[:, :, 1:, :] - x[:, :, :-1, :]
    return dx, dy


def masked_grad_l1_loss(pred, target, mask):
    """Masked L1 between image gradients of pred and target.

    A gradient sample is counted only where BOTH neighboring pixels are inside
    the object mask (so silhouette jumps across the object boundary are not
    penalized). Encourages the prediction to preserve high-frequency detail
    (edges, specular peaks) that plain L1 tends to over-smooth.
    """
    pdx, pdy = _image_grad(pred)
    tdx, tdy = _image_grad(target)

    # mask: [B,1,H,W] -> neighbor products
    mdx = mask[:, :, :, 1:] * mask[:, :, :, :-1]   # [B,1,H,W-1]
    mdy = mask[:, :, 1:, :] * mask[:, :, :-1, :]   # [B,1,H-1,W]

    lx = ((pdx - tdx).abs() * mdx).sum() / (mdx.sum() + 1e-8)
    ly = ((pdy - tdy).abs() * mdy).sum() / (mdy.sum() + 1e-8)
    return 0.5 * (lx + ly)
