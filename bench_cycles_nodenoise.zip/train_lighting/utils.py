"""
Utility functions for view direction computation, normal decoding, etc.
"""

import math
import numpy as np
from PIL import Image


def _decode_normal(normal_img):
    """Decode world-space normal from PNG: N = img * 2 - 1, then normalize."""
    n = normal_img.astype(np.float32) / 255.0
    n = n * 2.0 - 1.0
    norm = np.linalg.norm(n, axis=2, keepdims=True)
    n = n / (norm + 1e-8)
    return n


def compute_view_direction_map(cam_pos, cam_rot_euler, fov_deg, h, w):
    """
    Compute per-pixel view direction (world-space) from camera parameters.

    Args:
        cam_pos: [3] camera position in world space
        cam_rot_euler: [3] rotation_euler from metadata (Blender XYZ order)
        fov_deg: horizontal FOV in degrees
        h, w: image resolution

    Returns:
        view_dir: [h, w, 3] normalized world-space direction from camera to pixel
    """
    # Blender camera: default forward is -Z, X right, Y up
    # Image coords: u from left (0) to right (w-1), v from top (0) to bottom (h-1)
    aspect = w / h
    fov_rad = math.radians(fov_deg)
    tan_half_fov = math.tan(fov_rad / 2.0)

    u = np.arange(w, dtype=np.float32) + 0.5
    v = np.arange(h, dtype=np.float32) + 0.5

    # Camera-space ray direction
    x = (2.0 * u / w - 1.0) * aspect * tan_half_fov
    y = (1.0 - 2.0 * v / h) * tan_half_fov
    z = np.full_like(x, -1.0)

    # Stack to [h, w, 3] via broadcasting
    xs, ys = np.meshgrid(x, y, indexing='xy')
    ray_cam = np.stack([xs, ys, np.full_like(xs, -1.0)], axis=2)

    # Normalize in camera space
    ray_cam = ray_cam / (np.linalg.norm(ray_cam, axis=2, keepdims=True) + 1e-8)

    # Convert to world space using rotation matrix
    # Blender Euler XYZ order
    rx, ry, rz = cam_rot_euler
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)

    # Rotation matrix from Euler XYZ (R = Rz @ Ry @ Rx)
    # Verified against Blender's mathutils.Euler.to_matrix()
    R = np.array([
        [cy*cz,   sx*sy*cz - sz*cx,   cx*sy*cz + sz*sx],
        [cy*sz,   sx*sy*sz + cz*cx,   cx*sy*sz - cz*sx],
        [-sy,     sx*cy,              cx*cy],
    ], dtype=np.float32)

    # Apply rotation: R @ ray_cam (local to world)
    ray_world = np.einsum('ij,hwj->hwi', R, ray_cam)
    ray_world = ray_world / (np.linalg.norm(ray_world, axis=2, keepdims=True) + 1e-8)

    return ray_world


def compute_shading_features(normal_img, cam_pos, cam_rot_euler, fov_deg):
    """
    Compute view_dir, NDotV, and reflection_dir for a single view.

    Args:
        normal_img: [h, w, 3] uint8 PNG (encoded world-space normal)
        cam_pos: [3] camera position
        cam_rot_euler: [3] camera rotation euler
        fov_deg: FOV in degrees

    Returns:
        view_dir: [h, w, 3]
        ndotv: [h, w, 1]
        reflection_dir: [h, w, 3]
    """
    h, w = normal_img.shape[:2]

    # Decode normal
    normal = _decode_normal(normal_img)

    # Compute view direction
    view_dir = compute_view_direction_map(cam_pos, cam_rot_euler, fov_deg, h, w)

    # NDotV = dot(N, V), clamp to [0, 1]
    ndotv = np.sum(normal * view_dir, axis=2, keepdims=True)
    ndotv = np.clip(ndotv, 0.0, 1.0)

    # Reflection direction: R = 2 * NDotV * N - V
    reflection_dir = 2.0 * ndotv * normal - view_dir
    reflection_norm = np.linalg.norm(reflection_dir, axis=2, keepdims=True)
    reflection_dir = reflection_dir / (reflection_norm + 1e-8)

    return view_dir, ndotv, reflection_dir


def compute_mask(albedo_img):
    """
    Compute object mask from albedo.
    Background pixels have albedo = [0, 0, 0].
    """
    mask = np.sum(albedo_img, axis=2, keepdims=True) > 0
    return mask.astype(np.float32)
