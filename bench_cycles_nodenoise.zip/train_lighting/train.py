"""
Generic training engine for per-tile neural radiance prediction.

This module contains only the training loop — no experiment-specific logic.
All model behavior (input assembly, network, output decoder, regularization,
optimizer construction) lives in the Experiment class. The engine drives any
experiment through the (experiment, modules) interface.

Entry point for running experiments is run.py:
    python -m train_lighting.run --experiment baseline --epochs 100
(`python -m train_lighting.train ...` still works — it delegates to run.py.)
"""

import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.tensorboard import SummaryWriter

from train_lighting.dataset import build_dataloaders
from train_lighting.experiments.base import Experiment
from train_lighting.losses import MaskedL1Loss


def _ts():
    """Return current timestamp string for log messages."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ============================================================================
# Training
# ============================================================================

def _set_mode(modules, mode):
    """Set train/eval mode on every module."""
    for m in modules.values():
        getattr(m, mode)()  # 'train' or 'eval'


def _all_parameters(modules):
    """Collect parameters from all modules (for grad clipping)."""
    params = []
    for m in modules.values():
        params.extend(m.parameters())
    return params


class EMA:
    """Exponential moving average of module parameters. Eval/save under `.swap()` to use EMA weights
    (often improves generalization at ~zero cost). Operates on float params/buffers via state_dict."""
    def __init__(self, modules, decay=0.999):
        from contextlib import contextmanager
        self._cm = contextmanager
        self.decay = decay
        self.shadow = {
            n: {k: v.detach().clone() for k, v in m.state_dict().items()
                if v.dtype.is_floating_point}
            for n, m in modules.items()
        }

    @torch.no_grad()
    def update(self, modules):
        d = self.decay
        for n, m in modules.items():
            sd = m.state_dict()
            for k, sh in self.shadow[n].items():
                sh.mul_(d).add_(sd[k].detach(), alpha=1 - d)

    def swap(self, modules):
        @self._cm
        def _ctx():
            backup = {n: {} for n in modules}
            for n, m in modules.items():
                sd = m.state_dict()
                for k in self.shadow[n]:
                    backup[n][k] = sd[k].detach().clone()   # save trained params
                    sd[k].copy_(self.shadow[n][k])          # load EMA into modules
            try:
                yield
            finally:
                for n, m in modules.items():
                    sd = m.state_dict()
                    for k in self.shadow[n]:
                        sd[k].copy_(backup[n][k])           # restore trained params
        return _ctx()


def train_one_epoch(experiment, modules, train_loader, optimizer, device,
                    epoch, log_interval=50, ema=None):
    _set_mode(modules, "train")

    comp_sums = {}      # running sum of each named loss component
    n_batches = 0

    # Track radiance statistics (if the experiment exposes them)
    rad_min = float('inf')
    rad_max = float('-inf')
    rad_mean_sum = 0.0

    for batch_idx, batch in enumerate(train_loader):
        # Forward (experiment does input assembly + network + decode)
        pred_color = experiment.forward(batch, modules, device)

        # Experiment owns the loss (masked L1 + whatever it adds)
        loss, components = experiment.compute_loss(pred_color, batch, modules, device)

        if torch.isnan(loss) or torch.isinf(loss):
            print(f"  [WARN] NaN/Inf loss at batch {batch_idx}, skipping")
            continue

        optimizer.zero_grad(set_to_none=True)
        loss.backward()

        total_grad_norm = torch.nn.utils.clip_grad_norm_(
            _all_parameters(modules), max_norm=1.0
        )

        if torch.isnan(total_grad_norm) or torch.isinf(total_grad_norm):
            print(f"  [WARN] NaN/Inf gradient at batch {batch_idx}, skipping step")
            continue

        grad_norm = total_grad_norm.item()
        optimizer.step()
        if ema is not None:
            ema.update(modules)

        # Track radiance stats if the experiment exposes last_radiance
        radiance = getattr(experiment, "last_radiance", None)
        if radiance is not None:
            with torch.no_grad():
                rad_min = min(rad_min, radiance.min().item())
                rad_max = max(rad_max, radiance.max().item())
                rad_mean_sum += radiance.mean().item()

        for k, v in components.items():
            comp_sums[k] = comp_sums.get(k, 0.0) + v
        n_batches += 1

        if (batch_idx + 1) % log_interval == 0:
            avg = {k: v / n_batches for k, v in comp_sums.items()}
            mask_pct = batch['mask'].mean().item() * 100
            extra_str = " ".join(f"{k}={v:.5f}" for k, v in avg.items() if k != 'l1')
            print(f"[{_ts()}] [E{epoch+1}] batch {batch_idx+1}/{len(train_loader)}: "
                  f"loss={loss.item():.4f} l1={components['l1']:.4f} "
                  f"{extra_str} gnorm={grad_norm:.4f} "
                  f"rad=[{rad_min:.2f},{rad_max:.2f}] "
                  f"mask={mask_pct:.1f}% avg_l1={avg['l1']:.4f}")

    avg_components = {k: v / max(n_batches, 1) for k, v in comp_sums.items()}
    avg_rad_mean = rad_mean_sum / max(n_batches, 1)
    return avg_components, avg_rad_mean, rad_min, rad_max


# ============================================================================
# Evaluation
# ============================================================================

@torch.no_grad()
def evaluate(experiment, modules, val_loader, criterion, device, epoch=0):
    """Validation metric = pure masked L1 (comparable across experiments).

    Uses the engine's criterion, NOT the experiment's compute_loss, so the
    reported number is the same standard metric regardless of what training
    loss an experiment adds.
    """
    _set_mode(modules, "eval")

    total_l1 = 0.0
    n_batches = 0
    rad_min = float('inf')
    rad_max = float('-inf')
    per_pixel_err_sum = 0.0
    pixel_count = 0

    for batch in val_loader:
        rgb_gt = batch['rgb_gt'].to(device, non_blocking=True)
        mask = batch['mask'].to(device, non_blocking=True)

        pred_color = experiment.forward(batch, modules, device)
        l1_loss = criterion(pred_color, rgb_gt, mask)

        if not (torch.isnan(l1_loss) or torch.isinf(l1_loss)):
            total_l1 += l1_loss.item()
            n_batches += 1

            radiance = getattr(experiment, "last_radiance", None)
            if radiance is not None:
                rad_min = min(rad_min, radiance.min().item())
                rad_max = max(rad_max, radiance.max().item())

            diff = (pred_color - rgb_gt).abs()
            per_pixel_err_sum += (diff * mask).sum().item()
            pixel_count += mask.sum().item()

    val_l1 = total_l1 / max(n_batches, 1)
    avg_pixel_err = per_pixel_err_sum / max(pixel_count, 1)
    return val_l1, avg_pixel_err, rad_min, rad_max


# ============================================================================
# Visualization
# ============================================================================

@torch.no_grad()
def visual_eval_fullres(experiment, modules, device, out_dir, epoch,
                        eval_views, batch_size=512, label=None):
    """
    Full-resolution visual eval on selected views.
    Outputs GT | Pred | Error (10x amplified) side by side.
    """
    from train_lighting.single_view_eval import SingleViewDataset
    from PIL import Image
    from torch.utils.data import DataLoader

    _set_mode(modules, "eval")

    vis_dir = out_dir / (label if label else f"vis_epoch_{epoch+1:03d}")
    vis_dir.mkdir(parents=True, exist_ok=True)

    for vi, view_dir in enumerate(eval_views):
        view_dir = Path(view_dir)
        if not (view_dir / "metadata.json").exists():
            continue

        ds = SingleViewDataset(view_dir, feature_spec=experiment.feature_spec,
                               halo=getattr(experiment, "halo", 0))
        loader = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=0)

        all_pred = []
        for batch in loader:
            pred_color = experiment.forward(batch, modules, device)
            all_pred.append(pred_color.cpu())

        all_pred = torch.cat(all_pred, dim=0)

        # Stitch full-res
        pred_full = ds.stitch('pred', all_pred)  # [3, H, W]
        gt_full = ds.full['rgb_gt']
        mask_full = ds.full['mask']

        # Per-view metric
        diff = (pred_full - gt_full).abs()
        masked_err = (diff * mask_full).sum() / (mask_full.sum() + 1e-8)

        # Save comparison image
        gt_np = gt_full.permute(1, 2, 0).numpy()
        pred_np = pred_full.permute(1, 2, 0).numpy()
        m_np = mask_full[0].numpy()

        gt_vis = (gt_np * m_np[:, :, np.newaxis] * 255).astype(np.uint8)
        pred_vis = (pred_np * m_np[:, :, np.newaxis] * 255).astype(np.uint8)
        err_vis = np.clip(np.abs(gt_np - pred_np) * m_np[:, :, np.newaxis] * 255 * 10,
                          0, 255).astype(np.uint8)

        h, w = gt_vis.shape[:2]
        canvas = np.zeros((h, w * 3 + 4, 3), dtype=np.uint8)
        canvas[:, :w] = gt_vis
        canvas[:, w + 2:w * 2 + 2] = pred_vis
        canvas[:, w * 2 + 4:] = err_vis

        label = f"view{vi}_{view_dir.parent.parent.name}_{view_dir.parent.name}_{view_dir.name}"
        Image.fromarray(canvas).save(str(vis_dir / f"{label}_l1={masked_err:.4f}.png"))

    print(f"  Visual eval saved to {vis_dir} ({len(eval_views)} views)")


# ============================================================================
# Checkpoint (generic over modules dict)
# ============================================================================

def save_checkpoint(path, epoch, modules, optimizer, best_loss):
    state = {
        'epoch': epoch,
        'best_loss': best_loss,
        'optimizer_state_dict': optimizer.state_dict(),
    }
    for name, m in modules.items():
        state[f"{name}_state_dict"] = m.state_dict()
    torch.save(state, path)


def load_checkpoint(path, modules, optimizer, device):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    for name, m in modules.items():
        key = f"{name}_state_dict"
        if key in ckpt:
            m.load_state_dict(ckpt[key])
    if optimizer is not None and 'optimizer_state_dict' in ckpt:
        optimizer.load_state_dict(ckpt['optimizer_state_dict'])
    return ckpt.get('epoch', 0), ckpt.get('best_loss', float('inf'))


# ============================================================================
# Module diagnostics (generic: any module exposing a learnable .grid)
# ============================================================================

def grid_diagnostics(modules) -> dict:
    """Return mean/std for every module that has a learnable .grid (e.g. env maps)."""
    diag = {}
    for name, m in modules.items():
        grid = getattr(m, "grid", None)
        if isinstance(grid, torch.Tensor) and grid.requires_grad is not None:
            g = grid.detach()
            diag[f"{name}/grid_mean"] = g.mean().item()
            diag[f"{name}/grid_std"] = g.std().item()
    return diag


# ============================================================================
# Entry shim — delegates to run.py (kept for backward compatibility)
# ============================================================================

if __name__ == "__main__":
    from train_lighting.run import main
    main()
