"""
Experiment runner — the single entry point for running experiments.

    python -m train_lighting.run --experiment baseline --epochs 100
    python -m train_lighting.run --experiment baseline --tag ch32 --base_ch 32
    python -m train_lighting.run --resume experiments/baseline/<run>/checkpoints/latest.pt --epochs 100

Responsibilities:
  - resolve the Experiment class from the registry and build it from CLI args
  - create a self-describing output directory per run
        experiments/<name>/<timestamp>[_<tag>]/
            config.json     experiment class + all args + feature spec + param counts
            checkpoints/    best.pt, latest.pt, final.pt
            logs/           TensorBoard event files
            vis_eval/       full-resolution GT|Pred|Error images
            train.log       mirrored stdout
  - write config.json so any checkpoint is fully reconstructable
  - drive the generic training engine in train.py

The training loop itself contains no experiment-specific logic.
"""

import argparse
import json
import random
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
from contextlib import nullcontext
from torch.utils.tensorboard import SummaryWriter

from train_lighting.dataset import build_dataloaders, DATASET_DIR
from train_lighting.experiments import get_experiment_class, list_experiments
from train_lighting.train import (
    EMA,
    MaskedL1Loss,
    evaluate,
    grid_diagnostics,
    load_checkpoint,
    save_checkpoint,
    train_one_epoch,
    visual_eval_fullres,
)


# Standard full-res eval views (relative to dataset root). From the ablation study.
DEFAULT_EVAL_VIEWS = [
    "10/variant_00/view_00",
    "34/variant_05/view_10",
    "17/variant_08/view_15",
]


# ============================================================================
# Output: mirror stdout to a log file
# ============================================================================

class _Tee:
    """Write to several streams at once (stdout + file). Captures print() output."""
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for s in self.streams:
            s.write(data)

    def flush(self):
        for s in self.streams:
            try:
                s.flush()
            except Exception:
                pass


# ============================================================================
# Run-directory resolution
# ============================================================================

def resolve_run_dir(args, experiment_name: str) -> Path:
    """Decide where this run's outputs live.

    --resume : infer the run dir from the checkpoint path (continue that run).
    --run_dir: use the given path explicitly.
    otherwise : create experiments/<name>/<timestamp>[_<tag>]/.
    """
    if args.resume:
        p = Path(args.resume).resolve().parent
        while p != p.parent:
            if (p / "config.json").exists():
                return p
            if p.name == "experiments":
                break
            p = p.parent
        return Path(args.resume).resolve().parent.parent  # best-effort fallback

    if args.run_dir:
        return Path(args.run_dir)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    subdir = f"{ts}_{args.tag}" if args.tag else ts
    return Path(args.output_root) / experiment_name / subdir


def write_config(path: Path, experiment_name: str, experiment, modules, args):
    """Dump a zero-dependency JSON describing this run fully."""
    param_counts = {
        name: sum(p.numel() for p in m.parameters()) for name, m in modules.items()
    }
    param_counts["total"] = sum(v for k, v in param_counts.items() if k != "total")
    config = {
        "experiment": experiment_name,
        "experiment_args": experiment.config(),
        "feature_spec": experiment.feature_spec.to_dict(),
        "param_counts": param_counts,
        "args": {k: _jsonable(v) for k, v in vars(args).items()},
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "framework_version": 1,
    }
    path.write_text(json.dumps(config, indent=2, ensure_ascii=False))


def _jsonable(v):
    if isinstance(v, Path):
        return str(v)
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    return v


def pick_random_views(dataset_dir, n=4, seed=42):
    """Pick n random view dirs from the dataset (for final visual eval)."""
    root = Path(dataset_dir)
    views = sorted(root.glob("*/*/view_*"))
    if not views:
        return []
    return random.Random(seed).sample(views, min(n, len(views)))


def resolve_eval_views(args) -> list:
    """Resolve --eval_views (relative to dataset_dir or absolute)."""
    if args.eval_views is None or args.eval_views == []:
        views = list(DEFAULT_EVAL_VIEWS)
    else:
        views = args.eval_views
    ds_root = Path(args.dataset_dir)
    resolved = []
    for v in views:
        p = Path(v)
        if not p.is_absolute():
            p = ds_root / v
        if (p / "metadata.json").exists():
            resolved.append(p)
    return resolved


# ============================================================================
# CLI
# ============================================================================

def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Run a neural radiance experiment.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    # experiment selection / output
    p.add_argument("--experiment", type=str, default="baseline",
                   help=f"experiment name; one of: {list_experiments()}")
    p.add_argument("--output_root", type=str, default="./experiments",
                   help="root dir for run outputs")
    p.add_argument("--tag", type=str, default=None,
                   help="short label appended to the run dir name")
    p.add_argument("--run_dir", type=str, default=None,
                   help="explicit run dir (overrides auto-naming)")
    # data
    p.add_argument("--dataset_dir", type=str, default=str(DATASET_DIR))
    p.add_argument("--batch_size", type=int, default=1024)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--load_workers", type=int, default=8)
    p.add_argument("--data_device", type=str, default="cpu", choices=["cpu", "cuda"],
                   help="keep dataset tiles on cpu (default) or cuda (GPU-resident; small datasets only)")
    p.add_argument("--seed", type=int, default=42)
    # training
    p.add_argument("--epochs", type=int, default=200)
    p.add_argument("--lr_network", type=float, default=3e-4)
    p.add_argument("--lr_env_map", type=float, default=1e-3)
    p.add_argument("--lr_eta_min", type=float, default=1e-6,
                   help="cosine LR floor (raise to keep learning late, e.g. 1e-4)")
    p.add_argument("--lr_warmup_epochs", type=int, default=0,
                   help="linear LR warmup epochs (0=none)")
    p.add_argument("--weight_decay", type=float, default=1e-5)
    p.add_argument("--lambda_smooth", type=float, default=1e-4)
    p.add_argument("--log_interval", type=int, default=50)
    p.add_argument("--resume", type=str, default=None,
                   help="checkpoint path to resume from")
    # experiment hyperparams (baseline; other experiments may ignore these)
    p.add_argument("--env_dim", type=int, default=8)
    p.add_argument("--env_h", type=int, default=64)
    p.add_argument("--env_w", type=int, default=128)
    p.add_argument("--base_ch", type=int, default=16)
    p.add_argument("--bottleneck_blocks", type=int, default=3)
    # training knobs
    p.add_argument("--ema_decay", type=float, default=0.0,
                   help="EMA decay (>0 enables weight EMA; eval/save use EMA weights). 0=off, 0.999 typical")
    p.add_argument("--lambda_grad", type=float, default=0.5,
                   help="weight of the image-gradient (edge) loss (gradloss experiment)")
    # eval
    p.add_argument("--eval_views", type=str, nargs='*', default=None,
                   help="views for full-res visual eval (relative to dataset_dir "
                        "or absolute). Defaults to a standard set.")
    p.add_argument("--no_vis", action="store_true",
                   help="disable full-res visual eval entirely")
    p.add_argument("--augment", action="store_true",
                   help="enable geometrically-consistent horizontal-flip augmentation (train split)")
    # input feature (richfeat): Schlick Fresnel facing-ratio (the only feature that helped in R4)
    p.add_argument("--use_fresnel", action="store_true",
                   help="add Schlick facing-ratio (1-NdotV)^5 as an input feature")
    # raw-geometry input (R4-20: bypass the env-map bottleneck for surface orientation)
    p.add_argument("--use_raw_geom", action="store_true",
                   help="feed raw normal(3)+reflection_dir(3) directly as input (+6 ch), "
                        "bypassing the env-map query bottleneck")
    # physics-factored output head (R4-22: multiplicative albedo·shading + residual)
    p.add_argument("--phys_factored", action="store_true",
                   help="physics-factored head: radiance = albedo*softplus(shading)+residual. "
                        "Multiplicative albedo fusion preserves dynamic range; residual absorbs the rest.")
    # tile positional encoding (tile_pe experiment)
    p.add_argument("--pe_freqs", type=int, default=4,
                   help="number of Fourier frequencies per tile coordinate (tile_pe experiment). "
                        "Total PE channels = 2*(2*pe_freqs+1).")
    # attention bottleneck (attention_bn experiment)
    p.add_argument("--attn_heads", type=int, default=4,
                   help="number of attention heads in the intra-tile bottleneck (attention_bn experiment).")
    p.add_argument("--attn_mlp_ratio", type=float, default=2.0,
                   help="MLP hidden expansion in the intra-tile attention block (attention_bn experiment).")
    p.add_argument("--num_attn_blocks", type=int, default=3,
                   help="number of attention blocks in a mixed bottleneck; remaining blocks are SepConv "
                        "(mixed_attn_bn experiment).")
    # overlap inference (cross-tile context): halo neighbor pixels per tile side
    p.add_argument("--halo", type=int, default=0,
                   help="overlap-inference halo pixels added per tile side. Feature inputs are cut at "
                        "(32+2*halo)^2 with neighbor context (zero-padded at the image border); the "
                        "network output is center-cropped back to 32x32. Restores boundary pixels' "
                        "receptive field (the tile-seam fix). Must be even (0,2,4,6) so the tile stays "
                        "divisible by the U-Net's 2 stride-2 pools. 0 = no overlap.")
    return p


# ============================================================================
# Main
# ============================================================================

def plot_loss_curve(history, save_path, title=""):
    """Save a loss-curve PNG (train_l1, val_l1, LR over epochs) for quick convergence inspection."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    epochs = [h['epoch'] for h in history]
    train = [h['train_l1'] for h in history]
    val = [h['val_l1'] for h in history]
    lr = [h['lr'] for h in history]

    fig, ax1 = plt.subplots(figsize=(10, 5))
    ax1.plot(epochs, train, 'b-', alpha=0.6, label='train_l1')
    ax1.plot(epochs, val, 'r-', linewidth=2, label='val_l1')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Masked L1')
    ax1.legend(loc='upper right')
    ax1.grid(True, alpha=0.3)

    ax2 = ax1.twinx()
    ax2.plot(epochs, lr, 'g--', alpha=0.4, label='LR (net)')
    ax2.set_ylabel('Learning Rate')
    ax2.set_yscale('log')
    ax2.legend(loc='center right')

    best_val = min(val)
    best_ep = epochs[val.index(best_val)]
    ax1.axhline(best_val, color='r', linestyle=':', alpha=0.3)
    plt.title(f'{title} — best val_l1={best_val:.4f} @ ep{best_ep}')
    plt.tight_layout()
    plt.savefig(str(save_path), dpi=150)
    plt.close()
    print(f"  Loss curve saved to {save_path}")


def run_training(experiment, experiment_name, modules, train_loader, val_loader,
                 args, device, run_dir):
    """Drive one experiment's training loop into `run_dir`.

    Sets up per-run logging (Tee to run_dir/train.log), a config snapshot,
    TensorBoard, optional resume, the epoch loop, checkpoints, and visual eval.
    Returns the best val_l1 achieved. Shared by run.py (single run) and sweep.py
    (many runs on one loaded dataset).
    """
    (run_dir / "checkpoints").mkdir(parents=True, exist_ok=True)
    (run_dir / "logs").mkdir(parents=True, exist_ok=True)
    (run_dir / "vis_eval").mkdir(parents=True, exist_ok=True)

    log_file = open(run_dir / "train.log", "a", encoding="utf-8")
    orig_stdout = sys.stdout
    sys.stdout = _Tee(orig_stdout, log_file)

    spec = experiment.feature_spec
    print(f"\n{'=' * 72}")
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] Experiment: {experiment_name}")
    print(f"  Run dir: {run_dir}")
    print(f"  Device:  {device}")
    if torch.cuda.is_available():
        print(f"  GPU:     {torch.cuda.get_device_name(0)}")
        print(f"  VRAM:    {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    print(f"  Feature spec: {[c['name'] for c in spec.to_dict()['base_channels']]}"
          f" + ndotv={spec.compute_ndotv} refl={spec.compute_reflection}")
    print(f"  Experiment args: {experiment.config()}")

    optimizer, scheduler = experiment.build_optimizer(modules, args)
    criterion = MaskedL1Loss()
    ema = EMA(modules, decay=getattr(args, "ema_decay", 0.0)) if getattr(args, "ema_decay", 0.0) > 0 else None
    history = []  # per-epoch metrics for loss-curve plot

    param_counts = {name: sum(p.numel() for p in m.parameters())
                    for name, m in modules.items()}
    print(f"\n=== Model ===")
    for name, n in param_counts.items():
        print(f"  {name}: {n:,} params")
    print(f"  Total: {sum(param_counts.values()):,} params")

    write_config(run_dir / "config.json", experiment_name, experiment, modules, args)
    writer = SummaryWriter(run_dir / "logs")

    start_epoch = 0
    best_loss = float('inf')
    if args.resume and Path(args.resume).exists():
        start_epoch, best_loss = load_checkpoint(args.resume, modules, optimizer, device)
        start_epoch += 1
        print(f"\nResumed from {args.resume}: epoch {start_epoch}, best_loss={best_loss:.6f}")

    eval_views = [] if args.no_vis else resolve_eval_views(args)
    train_loader.dataset.augment = getattr(args, "augment", False)  # val_loader stays unaugmented
    print(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] === Training for {args.epochs} epochs ===")
    print(f"  batch_size={args.batch_size} lr_net={args.lr_network} lr_env={args.lr_env_map}")
    print(f"  lambda_smooth={args.lambda_smooth} eval_views={len(eval_views)}\n")

    try:
        for epoch in range(start_epoch, args.epochs):
            t0 = time.time()

            train_comps, train_rad_mean, train_rad_min, train_rad_max = \
                train_one_epoch(experiment, modules, train_loader, optimizer, device,
                                epoch, log_interval=args.log_interval, ema=ema)
            train_l1 = train_comps.get("l1", 0.0)

            # Evaluate + vis + checkpoint under EMA weights when EMA is on, so val/best reflect the
            # EMA model. scheduler.step + tensorboard only use scalar val_loss (fine outside swap).
            with (ema.swap(modules) if ema is not None else nullcontext()):
                val_loss, val_pixel_err, val_rad_min, val_rad_max = evaluate(
                    experiment, modules, val_loader, criterion, device, epoch)
                do_vis = (epoch < 5) or ((epoch + 1) % 20 == 0) or (epoch == start_epoch)
                if do_vis and eval_views:
                    visual_eval_fullres(experiment, modules, device,
                                        run_dir / "vis_eval", epoch, eval_views)
                improved = ""
                if val_loss < best_loss:
                    best_loss = val_loss
                    save_checkpoint(run_dir / "checkpoints" / "best.pt", epoch,
                                    modules, optimizer, best_loss)
                    improved = " *"
                save_checkpoint(run_dir / "checkpoints" / "latest.pt", epoch,
                                modules, optimizer, best_loss)

            scheduler.step()
            lr_net = optimizer.param_groups[0]["lr"]
            lr_env = optimizer.param_groups[1]["lr"] if len(optimizer.param_groups) > 1 else lr_net
            elapsed = time.time() - t0
            history.append({'epoch': epoch + 1, 'train_l1': train_l1,
                            'val_l1': val_loss, 'lr': lr_net})

            for k, v in train_comps.items():
                writer.add_scalar(f"loss/train_{k}", v, epoch)
            writer.add_scalar("loss/val_l1", val_loss, epoch)
            writer.add_scalar("loss/val_pixel_err", val_pixel_err, epoch)
            writer.add_scalar("lr/network", lr_net, epoch)
            writer.add_scalar("lr/env_map", lr_env, epoch)
            writer.add_scalar("radiance/train_mean", train_rad_mean, epoch)
            writer.add_scalar("radiance/train_min", train_rad_min, epoch)
            writer.add_scalar("radiance/train_max", train_rad_max, epoch)
            for k, v in grid_diagnostics(modules).items():
                writer.add_scalar(f"env/{k}", v, epoch)

            extra_comps = " ".join(f"{k}={v:.5f}" for k, v in train_comps.items() if k != 'l1')
            grid_str = " ".join(f"{k}={v:.4f}" for k, v in grid_diagnostics(modules).items())
            print(f"\n{'=' * 72}")
            print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] [{epoch + 1:3d}/{args.epochs}] "
                  f"train_l1={train_l1:.4f} val_l1={val_loss:.4f} "
                  f"val_pixel={val_pixel_err:.4f} best={best_loss:.4f}{improved}")
            print(f"  lr=[{lr_net:.2e},{lr_env:.2e}] {extra_comps} "
                  f"rad=[{train_rad_min:.2f},{train_rad_max:.2f}] "
                  f"{grid_str} time={elapsed:.1f}s")
            print(f"{'=' * 72}\n")

        save_checkpoint(run_dir / "checkpoints" / "final.pt", args.epochs - 1,
                        modules, optimizer, best_loss)

        # Final full-res visual eval: 4 random views → GT|Pred|Error saved to vis_eval/final/
        final_views = pick_random_views(args.dataset_dir, n=4)
        if final_views:
            print(f"\n[{datetime.now():%H:%M:%S}] Final visual eval ({len(final_views)} random views)...")
            visual_eval_fullres(experiment, modules, device, run_dir / "vis_eval",
                                args.epochs, final_views, label="final")

        if history:
            plot_loss_curve(history, run_dir / "loss_curve.png", experiment_name)

        print(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] Done. Best val loss: {best_loss:.6f}")
        print(f"Outputs in: {run_dir}")
    finally:
        writer.close()
        sys.stdout = orig_stdout
        log_file.close()

    return best_loss


def main(args=None):
    if args is None:
        args = build_argparser().parse_args()

    experiment_name = args.experiment
    experiment_cls = get_experiment_class(experiment_name)

    # --- reproducibility ---
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # --- experiment + data + modules ---
    experiment = experiment_cls.from_args(args)
    print("=== Loading dataset ===")
    train_loader, val_loader = build_dataloaders(
        dataset_dir=args.dataset_dir,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        load_workers=args.load_workers,
        seed=args.seed,
        feature_spec=experiment.feature_spec,
        device=args.data_device,
        halo=args.halo,
    )
    modules = experiment.build_modules(device)
    run_dir = resolve_run_dir(args, experiment_name)
    run_training(experiment, experiment_name, modules, train_loader, val_loader,
                 args, device, run_dir)


if __name__ == "__main__":
    main()
