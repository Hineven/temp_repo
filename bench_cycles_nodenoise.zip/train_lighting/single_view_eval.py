"""
Single-view evaluation: load one view at full resolution, tile it, run inference
through an Experiment, and stitch back into a full-resolution comparison image.

SingleViewDataset shares the data loader (_load_view_raw) with the training
dataset, so eval sees exactly the same channels the experiment was trained on.
"""

import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader

sys.path.insert(0, str(Path(__file__).parent.parent))
from train_lighting.dataset import _load_view_raw
from train_lighting.experiments import get_experiment_class
from train_lighting.experiments.base import FeatureSpec


TILE_SIZE = 32


class SingleViewDataset(Dataset):
    """Load a single view on-the-fly, tile it for batched inference.

    self.full holds full-res [C, H, W] tensors for every channel the experiment's
    FeatureSpec requests (plus the always-provided rgb_gt / mask).
    """

    def __init__(self, view_dir, tile_size=TILE_SIZE, feature_spec: FeatureSpec = None, halo=0):
        if feature_spec is None:
            raise ValueError("feature_spec is required")
        view_dir = Path(view_dir)
        self.tile_size = tile_size
        self.feature_spec = feature_spec
        self.halo = halo

        raw = _load_view_raw(view_dir, feature_spec)  # dict name -> [H,W,C]
        h, w = raw["mask"].shape[:2]

        # Store full-res tensors [C, H, W]
        self.full = {
            name: torch.from_numpy(np.ascontiguousarray(arr.transpose(2, 0, 1)))
            for name, arr in raw.items()
        }
        self.keys = list(self.full.keys())
        self.h, self.w = h, w
        self.ny = h // tile_size
        self.nx = w // tile_size
        self.valid_tiles = []

        # Find valid tiles (any object pixel in the CENTER tile)
        mask_hw = raw["mask"][:, :, 0]  # [H, W]
        for ty in range(self.ny):
            for tx in range(self.nx):
                y0, x0 = ty * tile_size, tx * tile_size
                if mask_hw[y0:y0 + tile_size, x0:x0 + tile_size].sum() > 0:
                    self.valid_tiles.append((ty, tx))

        print(f"SingleView: {view_dir.name} ({h}x{w}), "
              f"{len(self.valid_tiles)} valid tiles / {self.ny * self.nx} total"
              + (f", halo={halo}" if halo else ""))

    def __len__(self):
        return len(self.valid_tiles)

    def _slice_halo(self, v, y0, x0):
        """Slice a [C,H,W] tensor into the (tile+2*halo)² window centered on tile (y0,x0),
        zero-padding at the image border."""
        ts, h = self.tile_size, self.halo
        full = ts + 2 * h
        canvas = v.new_zeros(v.shape[0], full, full)
        sy0, sx0 = y0 - h, x0 - h
        sy1, sx1 = sy0 + full, sx0 + full
        # source region clipped to the image
        cy0, cx0 = max(0, sy0), max(0, sx0)
        cy1, cx1 = min(v.shape[-2], sy1), min(v.shape[-1], sx1)
        if cy0 < cy1 and cx0 < cx1:
            canvas[:, cy0 - sy0:cy1 - sy0, cx0 - sx0:cx1 - sx0] = v[:, cy0:cy1, cx0:cx1]
        return canvas

    def __getitem__(self, idx):
        ty, tx = self.valid_tiles[idx]
        ts = self.tile_size
        y0, x0 = ty * ts, tx * ts
        out = {}
        for k, v in self.full.items():
            if self.halo > 0 and k not in ("rgb_gt", "mask"):
                out[k] = self._slice_halo(v, y0, x0)   # [C, tile+2*halo, tile+2*halo]
            else:
                out[k] = v[:, y0:y0 + ts, x0:x0 + ts]  # [C, tile, tile] (center)
        return out

    def stitch(self, tiles_key, tiles_data):
        """Stitch tile predictions back into full-res image [C, H, W]."""
        C = tiles_data.shape[1]
        canvas = torch.zeros(C, self.h, self.w)
        for idx, (ty, tx) in enumerate(self.valid_tiles):
            y0, x0 = ty * self.tile_size, tx * self.tile_size
            canvas[:, y0:y0 + self.tile_size, x0:x0 + self.tile_size] = tiles_data[idx]
        return canvas


@torch.no_grad()
def eval_single_view(experiment, modules, device, out_path, view_dir, batch_size=512):
    """Run inference on a single view through the experiment and save a comparison image."""
    ds = SingleViewDataset(view_dir, feature_spec=experiment.feature_spec,
                           halo=getattr(experiment, "halo", 0))
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=0)

    for m in modules.values():
        m.eval()

    all_radiance = []
    all_pred = []

    for batch in loader:
        pred_color = experiment.forward(batch, modules, device)
        all_pred.append(pred_color.cpu())
        radiance = getattr(experiment, "last_radiance", None)
        if radiance is not None:
            all_radiance.append(radiance.cpu())

    all_pred = torch.cat(all_pred, dim=0)
    radiance_full = None
    if all_radiance:
        radiance_full = ds.stitch('rad', torch.cat(all_radiance, dim=0))

    # Stitch full-res images
    pred_full = ds.stitch('pred', all_pred)      # [3, H, W]
    gt_full = ds.full['rgb_gt']                   # [3, H, W]
    mask_full = ds.full['mask']                   # [1, H, W]

    # Compute metrics
    diff = (pred_full - gt_full).abs()
    masked_err = (diff * mask_full).sum() / (mask_full.sum() + 1e-8)
    print(f"  Masked L1: {masked_err:.6f}")
    if radiance_full is not None:
        print(f"  Radiance range: [{radiance_full.min():.4f}, {radiance_full.max():.4f}]")
        print(f"  Radiance mean (masked): "
              f"{(radiance_full * mask_full).sum() / mask_full.sum():.4f}")

    # Create comparison: GT | Pred | Error (10x amplified)
    gt_np = gt_full.permute(1, 2, 0).numpy()
    pred_np = pred_full.permute(1, 2, 0).numpy()
    mask_np = mask_full[0].numpy()

    gt_vis = (gt_np * mask_np[:, :, np.newaxis] * 255).astype(np.uint8)
    pred_vis = (pred_np * mask_np[:, :, np.newaxis] * 255).astype(np.uint8)
    err_vis = np.clip(np.abs(gt_np - pred_np) * mask_np[:, :, np.newaxis] * 255 * 10,
                      0, 255).astype(np.uint8)

    h, w = gt_vis.shape[:2]
    canvas = np.zeros((h, w * 3 + 4, 3), dtype=np.uint8)
    canvas[:, :w] = gt_vis
    canvas[:, w + 2:w * 2 + 2] = pred_vis
    canvas[:, w * 2 + 4:] = err_vis

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(canvas).save(str(out_path))
    print(f"  Saved to {out_path}")


def experiment_from_checkpoint(checkpoint_path):
    """Reconstruct an Experiment from the config.json sitting beside a checkpoint.

    Every run writes config.json (class name + constructor args), so a checkpoint
    is fully self-describing. Walks upward from the checkpoint until config.json
    is found.
    """
    from train_lighting.train import load_checkpoint

    ckpt_path = Path(checkpoint_path).resolve()
    run_dir = ckpt_path.parent
    config = None
    while run_dir != run_dir.parent:
        cfg = run_dir / "config.json"
        if cfg.exists():
            with open(cfg) as f:
                config = json.load(f)
            break
        if run_dir.name == "experiments":
            break
        run_dir = run_dir.parent

    if config is None:
        raise FileNotFoundError(
            f"No config.json found near {checkpoint_path}. Cannot reconstruct "
            f"experiment. Re-run eval via: python -m train_lighting.run ... "
            f"(which writes config.json), or pass the experiment explicitly."
        )

    exp_cls = get_experiment_class(config["experiment"])
    experiment = exp_cls(**config.get("experiment_args", {}))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    modules = experiment.build_modules(device)
    load_checkpoint(ckpt_path, modules, None, device)
    print(f"Reconstructed experiment '{config['experiment']}' from {ckpt_path}")
    return experiment, modules, device


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Single-view eval from a checkpoint")
    parser.add_argument("--view_dir", type=str, required=True)
    parser.add_argument("--checkpoint", type=str, required=True,
                        help="Path to a .pt checkpoint (config.json must be beside it)")
    parser.add_argument("--output", type=str, default="eval_output.png")
    parser.add_argument("--batch_size", type=int, default=512)
    args = parser.parse_args()

    experiment, modules, device = experiment_from_checkpoint(args.checkpoint)
    eval_single_view(experiment, modules, device, args.output,
                     args.view_dir, batch_size=args.batch_size)
