#!/usr/bin/env python3
"""
Full-res visual eval tool: pick N views, run inference, save GT|Pred|Error images.

Usage:
    # From a run dir (reads config.json + uses best.pt):
    python -m train_lighting.eval_views --run_dir experiments/richfeat/<run> --num_views 4

    # From a checkpoint explicitly (needs --dataset_dir):
    python -m train_lighting.eval_views --checkpoint <run>/checkpoints/best.pt \
        --dataset_dir dataset_frozen --num_views 8

Outputs go to <run_dir>/vis_eval/manual/ (or --output_dir) as GT|Pred|Error×10 side-by-side PNGs.
"""

import argparse
import json
import random
from pathlib import Path

from train_lighting.single_view_eval import experiment_from_checkpoint
from train_lighting.train import visual_eval_fullres


def pick_random_views(dataset_dir, n=4, seed=42):
    """Pick n random view dirs from the dataset."""
    root = Path(dataset_dir)
    views = sorted(root.glob("*/*/view_*"))
    if not views:
        return []
    return random.Random(seed).sample(views, min(n, len(views)))


def main():
    parser = argparse.ArgumentParser(
        description="Full-res visual eval: pick N views, save GT|Pred|Error images.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--run_dir", type=str, default=None,
                        help="experiment run dir (reads config.json + uses best.pt)")
    parser.add_argument("--checkpoint", type=str, default=None,
                        help="explicit checkpoint path (overrides run_dir/best.pt)")
    parser.add_argument("--dataset_dir", type=str, default=None,
                        help="dataset dir (default: inferred from run config)")
    parser.add_argument("--num_views", type=int, default=4)
    parser.add_argument("--output_dir", type=str, default=None,
                        help="output dir (default: <run_dir>/vis_eval/manual)")
    parser.add_argument("--seed", type=int, default=42, help="random seed for view selection")
    args = parser.parse_args()

    # Resolve checkpoint
    if args.checkpoint:
        ckpt = args.checkpoint
    elif args.run_dir:
        ckpt = str(Path(args.run_dir) / "checkpoints" / "best.pt")
    else:
        parser.error("provide --run_dir or --checkpoint")

    # Reconstruct experiment + modules from config.json beside the checkpoint
    experiment, modules, device = experiment_from_checkpoint(ckpt)

    # Resolve dataset_dir
    if args.dataset_dir:
        ds_dir = args.dataset_dir
    elif args.run_dir:
        cfg = json.loads((Path(args.run_dir) / "config.json").read_text())
        ds_dir = cfg.get("args", {}).get("dataset_dir", "dataset")
    else:
        ds_dir = "dataset"

    # Pick views
    views = pick_random_views(ds_dir, n=args.num_views, seed=args.seed)
    print(f"Picked {len(views)} random views from {ds_dir}:")
    for v in views:
        print(f"  {v.relative_to(ds_dir) if Path(ds_dir) in v.parents else v}")

    # Output dir
    out = args.output_dir or str(Path(ckpt).parent.parent / "vis_eval")
    Path(out).mkdir(parents=True, exist_ok=True)

    visual_eval_fullres(experiment, modules, device, Path(out), 0, views, label="manual")
    print(f"\nSaved to {out}/manual/")


if __name__ == "__main__":
    main()
