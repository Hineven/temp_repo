"""
Sweep harness — load the dataset ONCE, run several experiments back-to-back.

The ~5 min dataset load is amortized across the whole sweep, so a batch of
experiments costs (load + sum of training times) instead of N×(load + train).
Each config reuses run.run_training, so it gets the exact same self-describing
output dir as a single run (config.json / checkpoints / logs / vis_eval / train.log).

Constraint: every config in a sweep MUST share the same FeatureSpec (the same
dataset channel keys), because the dataset is loaded once. sweep.py verifies
this and skips incompatible configs. All width / env_dim / loss experiments use
the baseline spec, so they sweep together.

Usage:
    python -m train_lighting.sweep --epochs 50 \\
        --config baseline:base_ch=24 \\
        --config baseline:base_ch=48 \\
        --config baseline:base_ch=32,env_dim=16

Each --config is "<experiment_name>:<k=v,k=v,...>". A comparison table
(best val_l1, ascending) is printed at the end.
"""

import argparse
import copy
import random
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

from train_lighting.dataset import build_dataloaders
from train_lighting.experiments import get_experiment_class
from train_lighting.run import build_argparser, run_training


def _coerce(v):
    if str(v).lower() in ("true", "false"):
        return str(v).lower() == "true"
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v


def parse_config(s):
    """'<name>:k=v,k=v' -> (name, {k: v})."""
    name, _, rest = s.partition(":")
    overrides = {}
    if rest:
        for kv in rest.split(","):
            k, _, v = kv.partition("=")
            overrides[k.strip()] = _coerce(v.strip())
    return name.strip(), overrides


def _reseed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)


def main():
    parser = build_argparser()
    parser.add_argument("--config", action="append", default=[], dest="configs",
                        help="experiment config '<name>:<k=v,k=v,...>' (repeatable)")
    args = parser.parse_args()
    if not args.configs:
        parser.error("provide at least one --config")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    configs = [parse_config(c) for c in args.configs]

    # --- verify all configs share one FeatureSpec, then load dataset once ---
    specs = {}
    for name, _ in configs:
        specs[name] = get_experiment_class(name).from_args(args).feature_spec
    reference = list(specs.values())[0]
    ref_dict = reference.to_dict()
    for name, spec in specs.items():
        if spec.to_dict() != ref_dict:
            parser.error(
                f"config '{name}' has a different FeatureSpec than '{configs[0][0]}'. "
                f"sweep requires all configs to share one dataset. Split into separate sweeps."
            )

    print(f"=== Loading dataset ONCE for {len(configs)}-config sweep "
          f"(spec: {[c['name'] for c in ref_dict['base_channels']]}) ===")
    _reseed(args.seed)
    train_loader, val_loader = build_dataloaders(
        dataset_dir=args.dataset_dir,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        load_workers=args.load_workers,
        seed=args.seed,
        feature_spec=reference,
        device=args.data_device,
        halo=args.halo,
    )

    # --- run each config ---
    results = []
    for name, overrides in configs:
        if "halo" in overrides:
            parser.error(
                f"config '{name}' sets halo per-config, but the dataset is loaded ONCE per sweep "
                f"with the global --halo. Move halo to the sweep-level --halo flag, or split halo "
                f"values into separate sweeps."
            )
        cfg_args = copy.copy(args)
        for k, v in overrides.items():
            setattr(cfg_args, k, v)
        cfg_args.resume = None  # every config trains fresh

        _reseed(args.seed)  # reproducible module init per config
        exp_cls = get_experiment_class(name)
        experiment = exp_cls.from_args(cfg_args)
        modules = experiment.build_modules(device)

        tag = "_".join(f"{k}{v}" for k, v in overrides.items()) or "default"
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_dir = Path(args.output_root) / name / f"{ts}_{tag}"

        best = run_training(experiment, name, modules, train_loader, val_loader,
                            cfg_args, device, run_dir)
        results.append((name, overrides, best))

    # --- comparison table (best val_l1 first) ---
    print(f"\n{'=' * 72}\nSWEEP RESULTS (val_l1, best first)\n{'=' * 72}")
    for name, ov, best in sorted(results, key=lambda r: r[2]):
        ov_str = " ".join(f"{k}={v}" for k, v in ov.items())
        print(f"  {best:.4f}   {name}  {ov_str}")
    print(f"{'=' * 72}")


if __name__ == "__main__":
    main()
