"""
Frozen single-scene dataset.

A deliberately simple dataset: ONE object (71.glb) in ONE pose with ONE fixed
material (procedural coat/sss + Principled BSDF, same variant code as the main
dataset), rendered from ~300 camera viewpoints. Static lighting, static material,
static object+pose — only the camera moves. This is novel-view synthesis of a
single fixed scene.

Purpose: diagnostic. If the network can fit this one scene to a much lower val_l1
than the ~0.093 multi-scene floor, then the floor on the main dataset is driven by
dataset complexity (object/material/pose variety), not by a network bug. If it
*can't* fit one scene, something deeper is wrong.

On-disk layout (produced by render_pipeline with --model 71 --variant 0
--dataset_dir dataset_frozen):

    dataset_frozen/<model>/variant_00/view_NNN/
        rgb.png  albedo.png  metallic_roughness.png  normal.png
        sss_weight.png  coat_weight.png  coat_tint.png  radiance.exr
        metadata.json  (mask.png after postprocess_edges)

This is byte-for-byte the same per-view format as the main dataset, so the
frozen class reuses the same loaders + in-memory tiling machinery — it only
specializes the default root and documents the single-scene semantics. Train/val
split is by view (90/10), which is the correct split for novel-view synthesis.
"""

from pathlib import Path

from train_lighting.dataset import (
    DATASET_DIR,
    InMemoryTileDataset,
    build_dataloaders as _build_dataloaders,
)

# Frozen dataset root (sibling of the main dataset dir).
FROZEN_DIR = DATASET_DIR.parent / "dataset_frozen"


class FrozenTileDataset(InMemoryTileDataset):
    """In-memory tile dataset rooted at dataset_frozen (single fixed scene).

    Identical loader to InMemoryTileDataset — the frozen scene uses the exact
    same per-view G-Buffer format. This subclass only fixes the default root and
    signals the single-scene / novel-view-split semantics. See module docstring.
    """

    def __init__(self, dataset_dir=None, split='train', load_workers=8, seed=42,
                 feature_spec=None):
        super().__init__(
            dataset_dir or FROZEN_DIR,
            split=split,
            load_workers=load_workers,
            seed=seed,
            feature_spec=feature_spec,
        )


def build_frozen_dataloaders(dataset_dir=None, feature_spec=None, batch_size=1024,
                             num_workers=4, load_workers=8, seed=42):
    """Build train/val DataLoaders for the frozen single-scene dataset.

    Thin wrapper over dataset.build_dataloaders, defaulting the root to
    dataset_frozen. Pass the experiment's feature_spec (same channels as the
    main dataset).
    """
    return _build_dataloaders(
        dataset_dir=dataset_dir or FROZEN_DIR,
        batch_size=batch_size,
        num_workers=num_workers,
        load_workers=load_workers,
        seed=seed,
        feature_spec=feature_spec,
    )
