"""
Neural Radiance Prediction Network.

Components:
    NeuralEnvMap:     Learnable spherical feature grid (equirectangular)
    SepConvBlock:     Depthwise separable conv block
    UNetRadiance:     3-level U-Net predicting per-tile HDR radiance

Structural variants are now separate concerns, not flags: the output head has two modes
(plain linear, or physics-factored albedo⊙shading+residual) selected by `phys_factored`.
Falsified switches from the R4 campaign (SE / dropout / detail / split-heads / fresnel-gate /
ConvTranspose2d-upsample) have been removed. New structures should be new classes, not new flags.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def _gn_groups(ch):
    for g in [8, 4, 2, 1]:
        if ch % g == 0:
            return g
    return 1


# ============================================================================
# NeuralEnvMap: Spherical Equirectangular Feature Grid
# ============================================================================

class NeuralEnvMap(nn.Module):
    """
    Learnable spherical feature map stored in equirectangular projection.
    Query by world-space direction vector.
    """
    def __init__(self, feature_dim=8, h=64, w=128):
        super().__init__()
        self.feature_dim = feature_dim
        self.h = h
        self.w = w
        # Initialize with small random values
        self.grid = nn.Parameter(torch.randn(1, feature_dim, h, w) * 0.01)

    def query(self, directions):
        """
        Args:
            directions: [B, H, W, 3] unit vectors in world space
        Returns:
            features: [B, feature_dim, H, W]
        """
        # directions → spherical coords (θ, φ)
        theta = torch.atan2(directions[..., 1], directions[..., 0])  # [-π, π]
        phi = torch.acos(torch.clamp(directions[..., 2], -1.0, 1.0))  # [0, π]

        # Map to [0, 1]
        u = theta / (2.0 * math.pi) + 0.5
        v = phi / math.pi

        # grid_sample expects [-1, 1]
        uv = torch.stack([u, v], dim=-1) * 2.0 - 1.0  # [B, H, W, 2]

        # grid_sample: [B, C, H, W], [B, H, W, 2] → [B, C, H, W]
        features = F.grid_sample(
            self.grid.expand(directions.size(0), -1, -1, -1),
            uv,
            mode='bilinear',
            padding_mode='border',
            align_corners=False,
        )
        return features


# ============================================================================
# SepConvBlock: Depthwise Separable Convolution
# ============================================================================

class SepConvBlock(nn.Module):
    """
    Depthwise separable conv block:
      DepthwiseConv3x3 → GroupNorm → act
      PointwiseConv1x1 → GroupNorm → act
    """
    def __init__(self, in_ch, out_ch, act=nn.LeakyReLU(0.1, inplace=True)):
        super().__init__()
        self.block = nn.Sequential(
            # Depthwise
            nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=False),
            nn.GroupNorm(_gn_groups(in_ch), in_ch),
            act,
            # Pointwise
            nn.Conv2d(in_ch, out_ch, 1, bias=False),
            nn.GroupNorm(_gn_groups(out_ch), out_ch),
            act,
        )

    def forward(self, x):
        return self.block(x)


# ============================================================================
# UNetRadiance: Per-Tile HDR Radiance Prediction
# ============================================================================

class UNetRadiance(nn.Module):
    """
    3-level encoder-bottleneck-decoder U-Net for per-tile (32×32) radiance prediction.

    Decoder upsamples via Upsample(nearest)+Conv (anti-checkerboard; the
    ConvTranspose2d alternative caused 2×2 speckle and was removed).

    Output head (selected by `phys_factored`):
      False : radiance = head(fused)                                   [plain linear]
      True  : radiance = albedo ⊙ softplus(shading) + residual         [physics-factored]
              Multiplicative albedo fusion preserves dynamic range; the residual
              absorbs specular/coat/sss/errors so the prior is a safe superset.
    """
    def __init__(self, in_channels, base_ch=16, bottleneck_blocks=3,
                 phys_factored=False):
        super().__init__()
        c1 = base_ch
        c2 = base_ch * 2
        bn_ch = base_ch * 4
        self.phys_factored = phys_factored

        # Encoder
        self.enc1 = SepConvBlock(in_channels, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)   # 32→16

        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)   # 16→8

        # Bottleneck: configurable depth, Mish activation
        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2, bn_ch, act=mish)]
        for _ in range(bottleneck_blocks - 1):
            bn_blocks.append(SepConvBlock(bn_ch, bn_ch, act=mish))
        self.bottleneck = nn.Sequential(*bn_blocks)

        # Decoder upsampling: Upsample+Conv (anti-checkerboard)
        self.up2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(bn_ch, c2, 3, padding=1, bias=False),
        )
        self.up1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(c2, c1, 3, padding=1, bias=False),
        )

        self.dec2 = SepConvBlock(c2 * 2, c2)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        # Fusing: concat with albedo(3) + coat_tint(3) = 6 extra channels
        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )

        # Output head
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)  # nonneg diffuse shading (via softplus)
            self.head_res = nn.Conv2d(c1, 3, 1)    # residual: specular/coat/sss/errors (unbounded)
        else:
            self.head = nn.Conv2d(c1, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        # Small init on output heads so initial radiance ≈ 0
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        # phys_factored: bias shading head negative so softplus→small (≈0.05) at init, keeping
        # initial radiance ≈ albedo·0.05 ≈ dark (stable start); residual stays ~0 via the loop above.
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        """
        Args:
            x:        [B, in_channels, H, W]  network input (features + env features)
            albedo:   [B, 3, H, W]            from G-Buffer
            coat_tint:[B, 3, H, W]            from G-Buffer
        Returns:
            radiance: [B, 3, H, W]            predicted HDR radiance
        """
        # Encoder
        e1 = self.enc1(x)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)

        # Bottleneck
        b = self.bottleneck(p2)

        # Decoder
        d2 = self.dec2(torch.cat([self.up2(b), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))

        # Fusing with albedo and coat_tint
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))

        # Output head
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))          # [3,H,W] nonneg diffuse shading
            radiance = albedo * shading + self.head_res(fused)    # albedo-modulated diffuse + residual
        else:
            radiance = self.head(fused)

        return radiance


# ============================================================================
# LightUNetRadiance: FLOP-reduced variant (separable upsample) for 1080p budget
# ============================================================================

class SepUpsample(nn.Module):
    """Upsample(nearest) + depthwise 3×3 (spatial blend) + pointwise 1×1 (channel proj).

    Replaces UNetRadiance's Upsample+full-3×3-Conv. Same anti-checkerboard spatial
    blending (the depthwise 3×3 keeps it), but ~9× cheaper because the channel
    reduction moves to a 1×1 pointwise. The full 3×3 `up1`/`up2` were 70% of
    UNetRadiance's FLOPs (they run at the two highest resolutions), so this is the
    highest-leverage cut for a 1080p compute budget. Dec SepConvBlocks still provide
    3×3 spatial mixing after the concat, so no spatial information is dropped.
    """
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode='nearest')
        self.dw = nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=False)
        self.pw = nn.Conv2d(in_ch, out_ch, 1, bias=False)

    def forward(self, x):
        return self.pw(self.dw(self.up(x)))


class LightUNetRadiance(nn.Module):
    """
    FLOP-reduced per-tile radiance U-Net. Identical topology to UNetRadiance
    (3-level enc/bottleneck/dec, same channel widths, same phys_factored head)
    EXCEPT the two upsample blocks use SepUpsample (depthwise 3×3 + pointwise 1×1)
    instead of Upsample+full-3×3-Conv.

    Cost at base_ch=16, bn=3, phys_factored, in=29: ~0.013 GFLOPs/tile → ~27 GFLOPs
    for a 1920×1080 frame (vs UNetRadiance's ~59). Params ~27K (vs ~46K).

    This is a distinct class, not a flag on UNetRadiance — see the network-structure
    convention (new structure = new class). Output head and init mirror UNetRadiance.
    """
    def __init__(self, in_channels, base_ch=16, bottleneck_blocks=3,
                 phys_factored=False):
        super().__init__()
        c1 = base_ch
        c2 = base_ch * 2
        bn_ch = base_ch * 4
        self.phys_factored = phys_factored

        # Encoder (identical to UNetRadiance)
        self.enc1 = SepConvBlock(in_channels, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)   # 32→16
        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)   # 16→8

        # Bottleneck (identical)
        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2, bn_ch, act=mish)]
        for _ in range(bottleneck_blocks - 1):
            bn_blocks.append(SepConvBlock(bn_ch, bn_ch, act=mish))
        self.bottleneck = nn.Sequential(*bn_blocks)

        # Decoder upsampling: SEPARABLE (the only structural difference)
        self.up2 = SepUpsample(bn_ch, c2)
        self.up1 = SepUpsample(c2, c1)

        self.dec2 = SepConvBlock(c2 * 2, c2)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        # Fusing + output head (identical to UNetRadiance)
        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        e1 = self.enc1(x)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(p2)
        d2 = self.dec2(torch.cat([self.up2(b), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


# ============================================================================
# Intra-tile self-attention bottleneck variant
# ============================================================================

class IntraTileSelfAttention(nn.Module):
    """
    Spatial self-attention that operates strictly inside a single tile.

    The 2-D feature map is reshaped into HW tokens; attention mixes tokens
    within the tile only, so it preserves the "one tile = one independent
    inference" constraint.  At the 8×8 bottleneck of a 32×32 tile there are
    only 64 tokens, making this very cheap.

    Uses GroupNorm (matches the rest of the U-Net) and a 1×1 MLP.
    """

    def __init__(self, channels, num_heads=4, mlp_ratio=2.0):
        super().__init__()
        assert channels % num_heads == 0, "channels must be divisible by num_heads"
        self.channels = channels
        self.num_heads = num_heads
        self.head_dim = channels // num_heads

        self.norm1 = nn.GroupNorm(_gn_groups(channels), channels)
        self.qkv = nn.Conv2d(channels, channels * 3, 1, bias=False)
        self.proj = nn.Conv2d(channels, channels, 1, bias=False)

        self.norm2 = nn.GroupNorm(_gn_groups(channels), channels)
        hidden = int(channels * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.Mish(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=False),
        )

    def forward(self, x):
        B, C, H, W = x.shape
        N = H * W

        # --- attention branch ---
        shortcut = x
        x = self.norm1(x)
        qkv = self.qkv(x)  # [B, 3*C, H, W]
        qkv = qkv.view(B, 3, self.num_heads, self.head_dim, N).permute(1, 0, 2, 4, 3)
        q, k, v = qkv[0], qkv[1], qkv[2]  # each [B, heads, N, head_dim]

        attn = (q @ k.transpose(-2, -1)) * (self.head_dim ** -0.5)
        attn = attn.softmax(dim=-1)
        out = (attn @ v)  # [B, heads, N, head_dim]
        out = out.transpose(1, 2).reshape(B, N, C).permute(0, 2, 1).reshape(B, C, H, W)
        out = self.proj(out)
        x = shortcut + out

        # --- FFN branch ---
        x = x + self.mlp(self.norm2(x))
        return x


class AttentionBottleneckUNetRadiance(nn.Module):
    """
    UNetRadiance with the bottleneck blocks replaced by intra-tile self-attention.

    Encoder, decoder, fusion and output head are identical to UNetRadiance;
    only the lowest-resolution bottleneck mixes spatial information via
    global-within-tile attention instead of 3×3 separable convolutions.

    Intended to mitigate tile-boundary errors by giving boundary pixels access
    to the whole tile's context (while still not crossing tile boundaries).
    """

    def __init__(self, in_channels, base_ch=16, bottleneck_blocks=3,
                 phys_factored=False, attn_heads=4, attn_mlp_ratio=2.0):
        super().__init__()
        c1 = base_ch
        c2 = base_ch * 2
        bn_ch = base_ch * 4
        self.phys_factored = phys_factored

        # Encoder (identical to UNetRadiance)
        self.enc1 = SepConvBlock(in_channels, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)   # 32→16
        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)   # 16→8

        # Bottleneck: one conv projection + (blocks-1) self-attention layers
        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2, bn_ch, act=mish)]
        for _ in range(bottleneck_blocks - 1):
            bn_blocks.append(IntraTileSelfAttention(bn_ch, num_heads=attn_heads,
                                                    mlp_ratio=attn_mlp_ratio))
        self.bottleneck = nn.Sequential(*bn_blocks)

        # Decoder (identical to UNetRadiance)
        self.up2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(bn_ch, c2, 3, padding=1, bias=False),
        )
        self.up1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(c2, c1, 3, padding=1, bias=False),
        )
        self.dec2 = SepConvBlock(c2 * 2, c2)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )

        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        e1 = self.enc1(x)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(p2)
        d2 = self.dec2(torch.cat([self.up2(b), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


# ============================================================================
# Mixed bottleneck: conv blocks + a subset of intra-tile self-attention blocks
# ============================================================================

class MixedAttentionBottleneckUNetRadiance(nn.Module):
    """
    UNetRadiance with a mixed bottleneck: some blocks are SepConv, the rest are
    IntraTileSelfAttention.

    The first bottleneck block is always a SepConv projection (c2 -> bn_ch).
    The remaining (bottleneck_blocks - 1) blocks are split:
      - the first (blocks - 1 - num_attn_blocks) are SepConvBlock
      - the last num_attn_blocks are IntraTileSelfAttention

    This tests whether attention is needed in every bottleneck block, or whether
    a few attention blocks placed at the end of the bottleneck are sufficient.
    """

    def __init__(self, in_channels, base_ch=16, bottleneck_blocks=3,
                 phys_factored=False, attn_heads=4, attn_mlp_ratio=2.0,
                 num_attn_blocks=3):
        super().__init__()
        c1 = base_ch
        c2 = base_ch * 2
        bn_ch = base_ch * 4
        self.phys_factored = phys_factored

        # Encoder (identical to UNetRadiance)
        self.enc1 = SepConvBlock(in_channels, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)   # 32->16
        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)   # 16->8

        # Mixed bottleneck
        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2, bn_ch, act=mish)]
        n_post = bottleneck_blocks - 1
        n_conv_post = max(n_post - num_attn_blocks, 0)
        for i in range(n_post):
            if i < n_conv_post:
                bn_blocks.append(SepConvBlock(bn_ch, bn_ch, act=mish))
            else:
                bn_blocks.append(IntraTileSelfAttention(bn_ch, num_heads=attn_heads,
                                                        mlp_ratio=attn_mlp_ratio))
        self.bottleneck = nn.Sequential(*bn_blocks)

        # Decoder (identical to UNetRadiance)
        self.up2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(bn_ch, c2, 3, padding=1, bias=False),
        )
        self.up1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(c2, c1, 3, padding=1, bias=False),
        )
        self.dec2 = SepConvBlock(c2 * 2, c2)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )

        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        e1 = self.enc1(x)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(p2)
        d2 = self.dec2(torch.cat([self.up2(b), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance
