"""
TileDistanceExperiment — add a single distance-to-tile-edge channel to the input.

Motivation: boundary pixels have incomplete receptive field because the convolutional
kernel sees implicit zero-padding outside the tile. A position encoding that explicitly
codes "how far from the nearest tile edge" gives the network a direct cue for boundary
proximity without the high-frequency artifacts of sinusoidal PE.

This is the single-channel analog of the "Peripheral Distance Encoding" used in
whole-slide image tiling (arXiv:2605.02660).
"""

import torch

from train_lighting.experiments.richfeat import RichFeatureExperiment


class TileDistanceExperiment(RichFeatureExperiment):
    NAME = "tile_dist"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @classmethod
    def from_args(cls, args):
        return cls(
            use_fresnel=getattr(args, "use_fresnel", False),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
        )

    def _in_channels(self):
        return super()._in_channels() + 1  # one distance channel

    def _make_distance(self, x):
        """Build normalized distance-to-edge map with the same H, W as x."""
        B, _, H, W = x.shape
        device = x.device
        yy, xx = torch.meshgrid(
            torch.arange(H, device=device, dtype=torch.float32),
            torch.arange(W, device=device, dtype=torch.float32),
            indexing="ij",
        )
        # distance to nearest edge
        dy = torch.min(yy + 0.5, (H - 1) - yy + 0.5)
        dx = torch.min(xx + 0.5, (W - 1) - xx + 0.5)
        dist = torch.min(dy, dx)  # [H, W]
        # normalize to [0, 1] (max distance = half tile size)
        max_dist = min(H, W) / 2.0
        dist = dist / max_dist
        return dist.unsqueeze(0).unsqueeze(0).expand(B, 1, H, W)

    def _assemble_network_input(self, batch, device, modules):
        x, albedo, coat_tint = super()._assemble_network_input(batch, device, modules)
        d = self._make_distance(x)
        x = torch.cat([x, d], dim=1)
        return x, albedo, coat_tint
