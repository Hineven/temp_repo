"""
AttentionBottleneckExperiment — use AttentionBottleneckUNetRadiance as the backbone.

Only the network class changes (bottleneck blocks become intra-tile self-attention).
Input assembly, output decoder, loss and optimizer are inherited from RichFeatureExperiment.
"""

from train_lighting.experiments.richfeat import RichFeatureExperiment
from train_lighting.network import NeuralEnvMap, AttentionBottleneckUNetRadiance


class AttentionBottleneckExperiment(RichFeatureExperiment):
    NAME = "attention_bn"

    def __init__(self, attn_heads=4, attn_mlp_ratio=2.0, **kwargs):
        super().__init__(**kwargs)
        self.attn_heads = attn_heads
        self.attn_mlp_ratio = attn_mlp_ratio

    @classmethod
    def from_args(cls, args):
        return cls(
            attn_heads=getattr(args, "attn_heads", 4),
            attn_mlp_ratio=getattr(args, "attn_mlp_ratio", 2.0),
            use_fresnel=getattr(args, "use_fresnel", False),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
        )

    def build_modules(self, device):
        network = AttentionBottleneckUNetRadiance(
            in_channels=self._in_channels(),
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            phys_factored=self.phys_factored,
            attn_heads=self.attn_heads,
            attn_mlp_ratio=self.attn_mlp_ratio,
        ).to(device)
        env_map = NeuralEnvMap(
            feature_dim=self.env_dim, h=self.env_h, w=self.env_w
        ).to(device)
        env_ref_map = NeuralEnvMap(
            feature_dim=self.env_dim, h=self.env_h, w=self.env_w
        ).to(device)
        return {
            "network": network,
            "env_map": env_map,
            "env_ref_map": env_ref_map,
        }

    def config(self):
        return {
            **super().config(),
            "attn_heads": self.attn_heads,
            "attn_mlp_ratio": self.attn_mlp_ratio,
        }
