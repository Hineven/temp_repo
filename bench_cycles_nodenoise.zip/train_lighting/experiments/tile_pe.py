"""
TilePEExperiment — add tile-relative positional encoding to the network input.

Motivation: per-tile convolution has no position identity, so boundary/corner
pixels are indistinguishable from interior pixels. Adding normalized tile
coordinates + sinusoidal PE lets the network learn position-dependent
compensation (e.g. "I am at a corner with only 1/4 receptive field").

This is a positional-input change only; the network backbone is unchanged.
"""

import math

import torch

from train_lighting.experiments.richfeat import RichFeatureExperiment


def _positional_encoding_2d(coords, num_freqs):
    """
    Args:
        coords: [B, 2, H, W], assumed in [-1, 1]
        num_freqs: number of Fourier frequencies per coordinate
    Returns:
        [B, 2*(2*num_freqs+1), H, W]
    """
    features = [coords]
    for i in range(num_freqs):
        freq = math.pi * (2.0 ** i)
        features.append(torch.sin(freq * coords))
        features.append(torch.cos(freq * coords))
    return torch.cat(features, dim=1)


class TilePEExperiment(RichFeatureExperiment):
    NAME = "tile_pe"

    def __init__(self, pe_freqs=4, **kwargs):
        super().__init__(**kwargs)
        self.pe_freqs = pe_freqs

    @classmethod
    def from_args(cls, args):
        return cls(
            pe_freqs=getattr(args, "pe_freqs", 4),
            use_fresnel=getattr(args, "use_fresnel", False),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
        )

    def _pe_channels(self):
        return 2 * (2 * self.pe_freqs + 1)

    def _in_channels(self):
        return super()._in_channels() + self._pe_channels()

    def _make_pe(self, x):
        """Build tile-relative PE with the same H, W as x."""
        B, _, H, W = x.shape
        device = x.device
        # tile-relative coordinates in [-1, 1]; (0,0) at top-left corner, (1,1) at bottom-right
        y = torch.linspace(-1.0, 1.0, H, device=device)
        x_coord = torch.linspace(-1.0, 1.0, W, device=device)
        yy, xx = torch.meshgrid(y, x_coord, indexing="ij")
        coords = torch.stack([xx, yy], dim=0).unsqueeze(0).expand(B, -1, -1, -1)
        return _positional_encoding_2d(coords, self.pe_freqs)

    def _assemble_network_input(self, batch, device, modules):
        x, albedo, coat_tint = super()._assemble_network_input(batch, device, modules)
        pe = self._make_pe(x)
        x = torch.cat([x, pe], dim=1)
        return x, albedo, coat_tint

    def config(self):
        return {**super().config(), "pe_freqs": self.pe_freqs}
