"""
LightExperiment — RichFeatureExperiment with the FLOP-reduced LightUNetRadiance.

The only difference from richfeat is the network class: build_modules instantiates
LightUNetRadiance (separable upsample, ~9× cheaper upsample blocks) instead of
UNetRadiance. Everything else — input assembly (incl. Fresnel feature + raw geometry),
phys_factored head, masked-L1 loss, optimizer — is inherited unchanged so the
comparison isolates the structural cut.

Motivation: a 1920×1080 frame budget. UNetRadiance@ch16 spends ~70% of its FLOPs on
the two full-3×3 upsample convs (they run at the two highest resolutions). LightUNetRadiance
makes those separable (depthwise 3×3 + pointwise 1×1) — same spatial blending, far cheaper.
"""

from train_lighting.experiments.richfeat import RichFeatureExperiment
from train_lighting.network import LightUNetRadiance, NeuralEnvMap


class LightExperiment(RichFeatureExperiment):
    NAME = "light"

    def build_modules(self, device):
        network = LightUNetRadiance(
            in_channels=self._in_channels(),
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            phys_factored=self.phys_factored,
        ).to(device)
        env_map = NeuralEnvMap(
            feature_dim=self.env_dim, h=self.env_h, w=self.env_w
        ).to(device)
        env_ref_map = NeuralEnvMap(
            feature_dim=self.env_dim, h=self.env_h, w=self.env_w
        ).to(device)
        return {
            "network": network,
            "env_map": env_map,
            "env_ref_map": env_ref_map,
        }

    def config(self):
        return {**super().config(), "network": "LightUNetRadiance"}
