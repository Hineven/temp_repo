"""
RichFeatureExperiment — baseline + the Schlick Fresnel facing-ratio input feature.

Of the BRDF-relevant features trialed in R4 (fresnel / metal_fresnel / curvature / fourier-ndotv),
only plain Fresnel helped (the others were noise / no-effect and were removed). Computed in
forward() from channels the dataset already provides (ndotv) — NO dataset/FeatureSpec change.

Cost: 1 extra input channel → only the first conv widens; FLOPs ≈ unchanged.
"""

import torch

from train_lighting.experiments.baseline import BaselineExperiment


class RichFeatureExperiment(BaselineExperiment):
    NAME = "richfeat"

    def __init__(self, use_fresnel=False, **kwargs):
        # **kwargs (incl. deprecated use_metal_fresnel/use_curvature/fourier_ndotv) flows to the
        # baseline constructor, which ignores unknowns so old config.json checkpoints reconstruct.
        super().__init__(**kwargs)
        self.use_fresnel = use_fresnel

    @classmethod
    def from_args(cls, args):
        return cls(
            use_fresnel=getattr(args, "use_fresnel", False),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
        )

    def _n_extra(self):
        return 1 if self.use_fresnel else 0

    def _in_channels(self):
        return super()._in_channels() + self._n_extra()

    def _extra_features(self, batch, device):
        if not self.use_fresnel:
            return []
        ndotv = batch["ndotv"].to(device, non_blocking=True)
        facing = (1.0 - ndotv).clamp(min=0).pow(5)  # Schlick facing-ratio [B,1,H,W]
        return [facing]

    def _assemble_network_input(self, batch, device, modules):
        x, albedo, coat_tint = super()._assemble_network_input(batch, device, modules)
        extra = self._extra_features(batch, device)
        if extra:
            # x = [base | (geom) | env | env_ref]; insert extras before the env tail
            n_env = 2 * self.env_dim
            base_part, env_part = x[:, :-n_env], x[:, -n_env:]
            x = torch.cat([base_part] + extra + [env_part], dim=1)
        return x, albedo, coat_tint

    def config(self):
        return {**super().config(), "use_fresnel": self.use_fresnel}
