"""
Experiment framework core.

Two abstractions:

FeatureSpec
    Declares which raw G-Buffer channels an experiment wants the dataset to
    provide, plus whether the geometry-derived primitives (ndotv, reflection_dir)
    should be computed. This is the SINGLE SOURCE OF TRUTH for "what data does
    this experiment need". Owned by the experiment (network side), executed by
    the dataset (data side).

Experiment (ABC)
    Wraps one runnable experiment. Its responsibilities map directly to the three
    stages the user asked for:
      - input assembly : which features, how to extract/combine them  (in forward)
      - network        : the backbone modules                         (build_modules)
      - output decoder : how raw network output becomes sRGB          (decode_output)
    The dataset stays a pure data layer: it loads raw G-Buffer + computes the
    geometric primitives that need camera intrinsics, and hands the experiment a
    flat dict of named channels. Feature SELECTION and ASSEMBLY happen inside the
    experiment's forward(), not in the dataset.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import torch
import torch.nn as nn

from train_lighting.losses import MaskedL1Loss
from train_lighting.tonemap import linear_to_srgb


# ============================================================================
# FeatureSpec — declares what channels the dataset must provide
# ============================================================================

@dataclass
class GBufferChannel:
    """One scalar channel extracted from a G-Buffer PNG.

    file:   PNG filename stem, e.g. "ao", "metallic_roughness", "coat_weight"
    channel: index within the PNG (0=R, 1=G, 2=B)
    name:   unique key under which the channel appears in the batch dict
    """
    file: str
    channel: int
    name: str


@dataclass
class FeatureSpec:
    """Declares the channels an experiment needs from the dataset.

    base_channels:   scalar G-Buffer channels to load; each becomes its own
                     key in the batch dict (e.g. batch['metallic']). The
                     experiment's forward() decides how to assemble them.
    compute_ndotv:   if True, dataset provides a 'ndotv' primitive ([B,1,H,W])
    compute_reflection: if True, dataset provides a 'reflection_dir' primitive ([B,3,H,W])
    compute_view_dir: if True, dataset provides the per-pixel 'view_dir' vector ([B,3,H,W]).
                     Needed by experiments that query a bakeable table by view direction (prt_light).

    Always provided (need no declaration — required by loss / mask / fusion):
        'normal', 'albedo', 'coat_tint', 'rgb_gt', 'mask'
    """
    base_channels: list[GBufferChannel] = field(default_factory=list)
    compute_ndotv: bool = True
    compute_reflection: bool = True
    compute_view_dir: bool = False

    def channel_names(self) -> list[str]:
        """All keys this spec asks the dataset to produce (excluding always-provided)."""
        names = [c.name for c in self.base_channels]
        if self.compute_ndotv:
            names.append("ndotv")
        if self.compute_reflection:
            names.append("reflection_dir")
        if self.compute_view_dir:
            names.append("view_dir")
        return names

    def to_dict(self) -> dict:
        return {
            "base_channels": [
                {"file": c.file, "channel": c.channel, "name": c.name}
                for c in self.base_channels
            ],
            "compute_ndotv": self.compute_ndotv,
            "compute_reflection": self.compute_reflection,
            "compute_view_dir": self.compute_view_dir,
        }


# Always-provided keys (not part of FeatureSpec — universal).
ALWAYS_PROVIDED = ["normal", "albedo", "coat_tint", "rgb_gt", "mask"]


# ============================================================================
# Experiment ABC
# ============================================================================

class Experiment(ABC):
    """Base class for one experiment.

    A concrete experiment declares its FeatureSpec, builds its modules, and
    implements forward() which turns a batch of raw channels into a predicted
    sRGB image. The generic training engine in train.py drives it.
    """

    # Subclasses may set this in forward() to expose raw-radiance diagnostics
    # to the engine (per-batch HDR range tracking). Optional.
    last_radiance: torch.Tensor = None

    def __init__(self):
        # Stateless criterion reused across batches.
        self._criterion = MaskedL1Loss()

    @property
    @abstractmethod
    def feature_spec(self) -> FeatureSpec:
        """What data does this experiment need?"""

    @abstractmethod
    def build_modules(self, device) -> "dict[str, nn.Module]":
        """Construct and return all learnable modules on `device`.

        Returns a name->module dict so the engine can iterate generically
        (train/eval, param collection, checkpoint save/load). forward() indexes
        into this dict by name.
        """

    @abstractmethod
    def forward(self, batch, modules, device) -> torch.Tensor:
        """input assembly + network + decode.

        Args:
            batch:   dict of named channel tensors from the dataset (CPU).
                     Always includes normal, albedo, coat_tint, rgb_gt, mask,
                     plus every channel declared in feature_spec.
            modules: the dict returned by build_modules().
            device:  target device.

        Returns:
            pred_color: [B, 3, H, W] sRGB in [0, 1] (used directly by the loss).
        """

    # ------------------------------------------------------------------
    # Optional hooks with sensible defaults
    # ------------------------------------------------------------------

    def decode_output(self, raw: torch.Tensor) -> torch.Tensor:
        """Default output decoder: linear HDR -> sRGB, clamped to [0, 1]."""
        return torch.clamp(linear_to_srgb(raw), 0, 1)

    def compute_loss(self, pred, batch, modules, device):
        """Total training loss + named components for logging.

        Owning the loss here lets an experiment swap in image-space losses
        (gradient/SSIM, etc.) without touching the engine. The engine backprops
        the returned total; the components dict is averaged and logged.

        Default: masked L1 only. The component named 'l1' is also what evaluate()
        reports, keeping the val metric comparable across experiments.

        Returns:
            (total_loss: Tensor, components: dict[str, float])
        """
        rgb_gt = batch["rgb_gt"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)
        l1 = self._criterion(pred, rgb_gt, mask)
        return l1, {"l1": l1.item()}

    def build_optimizer(self, modules, args):
        """Default: single param group, cosine schedule. Override per experiment."""
        params = [p for m in modules.values() for p in m.parameters()]
        optimizer = torch.optim.AdamW(
            params, lr=args.lr_network, weight_decay=args.weight_decay
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=args.epochs, eta_min=1e-6
        )
        return optimizer, scheduler

    def config(self) -> dict:
        """Experiment-specific config to dump into config.json. Override to add."""
        return {}

    @classmethod
    def from_args(cls, args):
        """Construct an instance from the CLI arg namespace. Override per experiment.

        The default returns cls() with no args — for experiments with no
        constructor hyperparameters.
        """
        return cls()
