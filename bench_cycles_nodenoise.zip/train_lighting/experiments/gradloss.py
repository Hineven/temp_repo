"""
GradientLossExperiment — baseline + image-gradient (edge) loss.

Hypothesis (from analyzing Exp1 ch=32 error maps):
  Plain masked-L1 over-smooths the prediction — specular highlights come out
  muted/under-bright and high-frequency edges (seams, silhouette details,
  grazing-angle rims) come out blurred. This is the classic L1-median bias.
  Adding an L1 term on image gradients (a first-order edge/sharpness penalty)
  pushes the network to preserve high-frequency detail without changing the
  architecture or inference cost.

  val metric stays pure masked L1 (see train.evaluate), so results are directly
  comparable to the baseline.
"""

import torch

from train_lighting.losses import masked_grad_l1_loss
from train_lighting.experiments.baseline import BaselineExperiment


class GradientLossExperiment(BaselineExperiment):
    """Baseline pipeline + gradient (edge) loss term."""

    NAME = "gradloss"

    def __init__(self, lambda_grad=0.5, **kwargs):
        super().__init__(**kwargs)
        self.lambda_grad = lambda_grad

    @classmethod
    def from_args(cls, args):
        return cls(
            lambda_grad=args.lambda_grad,
            env_dim=args.env_dim,
            env_h=args.env_h,
            env_w=args.env_w,
            base_ch=args.base_ch,
            bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
        )

    def compute_loss(self, pred, batch, modules, device):
        rgb_gt = batch["rgb_gt"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)

        l1 = self._criterion(pred, rgb_gt, mask)
        grad = masked_grad_l1_loss(pred, rgb_gt, mask)

        total = l1 + self.lambda_grad * grad
        return total, {"l1": l1.item(), "grad": grad.item()}

    def config(self):
        cfg = super().config()
        cfg["lambda_grad"] = self.lambda_grad
        return cfg
