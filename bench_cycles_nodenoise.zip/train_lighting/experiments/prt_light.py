"""
PRTLightExperiment — tiny U-Net refiner + bakeable directional tables (~10 GFLOPs @ 1080p).

Exploits the fixed-object / fixed-lighting regime: per-pixel outgoing radiance is a fixed shared
function f(G-buffer, view), so the capacity can live in bakeable lookup tables (parameter-heavy,
FLOP-light) instead of convs. The U-Net is shrunk to a refiner that combines the baked cues.

Bakeable tables (all 2D equirect NeuralEnvMap grids, each queried by ONE direction — roughness stays
a U-Net input, not a table dim, per the agreed design):
    env_map      (by normal)       — irradiance / diffuse lighting       (inherited)
    env_ref_map  (by reflection)   — prefiltered specular lighting       (inherited)
    env_view_map (by view_dir)     — view-dependent modulation (NEW)     — needs `view_dir`

The tiny backbone is LightUNetRadiance (3-level U-Net + SepUpsample) at base_ch≈8-10. Input =
[G-buffer scalars + raw geom + Fresnel + 3 env feature sets]; phys_factored head. Net params ~8-12K;
~all capacity is in the tables. FLOPs ≈ 7 (ch8) / 11 (ch10) GFLOPs @ 1080p.

This is a new experiment (a structural input/modules change), reusing LightUNetRadiance as-is.
"""

from dataclasses import replace

import torch

from train_lighting.network import LightUNetRadiance, NeuralEnvMap
from train_lighting.experiments.baseline import BASELINE_SPEC
from train_lighting.experiments.richfeat import RichFeatureExperiment


class PRTLightExperiment(RichFeatureExperiment):
    NAME = "prt_light"

    @property
    def feature_spec(self):
        # Ask the dataset for the per-pixel view direction (the 3rd directional-table key).
        return replace(BASELINE_SPEC, compute_view_dir=True)

    def _in_channels(self):
        # super() = base scalars + ndotv + (raw geom) + Fresnel + 2*env_dim (normal, reflection).
        # +env_dim for the view-direction env query.
        return super()._in_channels() + self.env_dim

    def build_modules(self, device):
        network = LightUNetRadiance(
            in_channels=self._in_channels(),
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            phys_factored=self.phys_factored,
        ).to(device)
        env_map = NeuralEnvMap(feature_dim=self.env_dim, h=self.env_h, w=self.env_w).to(device)
        env_ref_map = NeuralEnvMap(feature_dim=self.env_dim, h=self.env_h, w=self.env_w).to(device)
        env_view_map = NeuralEnvMap(feature_dim=self.env_dim, h=self.env_h, w=self.env_w).to(device)
        return {
            "network": network,
            "env_map": env_map,
            "env_ref_map": env_ref_map,
            "env_view_map": env_view_map,
        }

    def _assemble_network_input(self, batch, device, modules):
        # Inherited assembly: x = [base | (geom) | Fresnel | env(normal) | env(reflection)].
        x, albedo, coat_tint = super()._assemble_network_input(batch, device, modules)
        view_dir = batch["view_dir"].to(device, non_blocking=True)
        env_view_feat = modules["env_view_map"].query(view_dir.permute(0, 2, 3, 1))
        x = torch.cat([x, env_view_feat], dim=1)  # append the view-direction env features
        return x, albedo, coat_tint

    def compute_loss(self, pred, batch, modules, device):
        rgb_gt = batch["rgb_gt"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)
        l1 = self._criterion(pred, rgb_gt, mask)
        # smoothness on all three directional tables
        from train_lighting.experiments.baseline import _env_map_smoothness_loss
        smooth = (
            _env_map_smoothness_loss(modules["env_map"])
            + _env_map_smoothness_loss(modules["env_ref_map"])
            + _env_map_smoothness_loss(modules["env_view_map"])
        )
        total = l1 + self.lambda_smooth * smooth
        return total, {"l1": l1.item(), "smooth": smooth.item()}

    def build_optimizer(self, modules, args):
        # Separate LR group for the three env maps (as the baseline does for its two), so the
        # bakeable tables can learn faster than the tiny U-Net.
        network = modules["network"]
        env_params = (
            list(modules["env_map"].parameters())
            + list(modules["env_ref_map"].parameters())
            + list(modules["env_view_map"].parameters())
        )
        optimizer = torch.optim.AdamW(
            [
                {"params": network.parameters(), "lr": args.lr_network,
                 "weight_decay": args.weight_decay},
                {"params": env_params, "lr": args.lr_env_map, "weight_decay": 0},
            ]
        )
        eta_min = getattr(args, "lr_eta_min", 1e-6)
        warmup = getattr(args, "lr_warmup_epochs", 0)
        cosine = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(args.epochs - warmup, 1), eta_min=eta_min
        )
        if warmup > 0:
            warm = torch.optim.lr_scheduler.LinearLR(optimizer, start_factor=0.1,
                                                     total_iters=warmup)
            scheduler = torch.optim.lr_scheduler.SequentialLR(
                optimizer, [warm, cosine], milestones=[warmup])
        else:
            scheduler = cosine
        return optimizer, scheduler

    def config(self):
        return {
            **super().config(),
            "network": "LightUNetRadiance",
            "directional_tables": 3,  # env_map (normal) + env_ref_map (reflection) + env_view_map (view)
        }
