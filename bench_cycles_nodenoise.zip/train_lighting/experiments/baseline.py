"""
BaselineExperiment — the reference per-tile radiance pipeline.

    input assembly : 6 base channels (ao, coat_w, metallic, roughness, sss, ndotv)
                     (+ optional raw normal/reflection via use_raw_geom)
                     + 2x NeuralEnvMap features (queried by normal / reflection_dir)
    network        : UNetRadiance(in = base + geom + 2*env_dim, base_ch, bottleneck_blocks,
                                  phys_factored=...)
    output decoder : linear -> sRGB -> clamp (Blender-matched)
    loss           : masked L1 (sRGB) + env-map grid smoothness

This is the reference experiment. A new experiment typically subclasses or mirrors it and changes
one thing (feature set, network class, decoder, ...). Structural switches that were falsified in the
R4 campaign (SE/dropout/detail/split-heads/loss-space/fresnel-gate) have been removed; deprecated
kwargs are still accepted (and ignored) so old config.json checkpoints reconstruct.
"""

import torch

from train_lighting.network import NeuralEnvMap, UNetRadiance
from train_lighting.tonemap import linear_to_srgb
from train_lighting.experiments.base import (
    Experiment,
    FeatureSpec,
    GBufferChannel,
)


# The baseline's feature declaration. The 5 scalar channels are loaded from
# G-Buffer PNGs; ndotv and reflection_dir are geometric primitives computed by
# the dataset (compute_ndotv / compute_reflection). forward() assembles all of
# them into the network input, so feature assembly stays on the experiment side.
BASELINE_SPEC = FeatureSpec(
    base_channels=[
        GBufferChannel("ao", 0, "ao"),
        GBufferChannel("coat_weight", 0, "coat_weight"),
        GBufferChannel("metallic_roughness", 0, "metallic"),
        GBufferChannel("metallic_roughness", 1, "roughness"),
        GBufferChannel("sss_weight", 0, "sss"),
    ],
    compute_ndotv=True,        # dataset provides batch['ndotv']
    compute_reflection=True,   # dataset provides batch['reflection_dir']
)


def _env_map_smoothness_loss(env_map):
    """Encourage smoothness in a NeuralEnvMap grid."""
    grid = env_map.grid  # [1, C, H, W]
    dh = (grid[:, :, 1:, :] - grid[:, :, :-1, :]).pow(2).mean()
    dw = (grid[:, :, :, 1:] - grid[:, :, :, :-1]).pow(2).mean()
    return dh + dw


class BaselineExperiment(Experiment):
    """The original pipeline, wrapped as an Experiment."""

    NAME = "baseline"

    def __init__(self, env_dim=8, env_h=64, env_w=128, base_ch=16,
                 bottleneck_blocks=3, lambda_smooth=1e-4,
                 use_raw_geom=False, phys_factored=False, halo=0, **kwargs):
        # **kwargs absorbs deprecated switches (use_se/dropout/use_detail/split_heads/
        # loss_space/phys_fresnel_gate/upsample_conv) so old config.json checkpoints
        # still reconstruct. They are ignored.
        super().__init__()
        self.env_dim = env_dim
        self.env_h = env_h
        self.env_w = env_w
        self.base_ch = base_ch
        self.bottleneck_blocks = bottleneck_blocks
        self.lambda_smooth = lambda_smooth
        self.use_raw_geom = use_raw_geom
        self.phys_factored = phys_factored
        # overlap-inference halo: feature inputs are cut at (tile+2*halo)^2 with neighbor
        # context; the network output is center-cropped back to tile^2 for the loss/metric.
        # 0 = no overlap (the network sees only the tile, as before).
        self.halo = halo

    @classmethod
    def from_args(cls, args):
        return cls(
            env_dim=args.env_dim,
            env_h=args.env_h,
            env_w=args.env_w,
            base_ch=args.base_ch,
            bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
        )

    # ------------------------------------------------------------------
    # Experiment interface
    # ------------------------------------------------------------------

    @property
    def feature_spec(self) -> FeatureSpec:
        return BASELINE_SPEC

    def _in_channels(self):
        """Network input width = base scalar channels + ndotv + (raw geom) + 2*env_dim. Override to add features."""
        n_base = len(BASELINE_SPEC.base_channels) + 1  # +ndotv
        n_geom = 6 if self.use_raw_geom else 0  # raw normal(3) + reflection_dir(3)
        return n_base + n_geom + 2 * self.env_dim

    def build_modules(self, device):
        network = UNetRadiance(
            in_channels=self._in_channels(),
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            phys_factored=self.phys_factored,
        ).to(device)
        env_map = NeuralEnvMap(
            feature_dim=self.env_dim, h=self.env_h, w=self.env_w
        ).to(device)
        env_ref_map = NeuralEnvMap(
            feature_dim=self.env_dim, h=self.env_h, w=self.env_w
        ).to(device)
        return {
            "network": network,
            "env_map": env_map,
            "env_ref_map": env_ref_map,
        }

    def _assemble_network_input(self, batch, device, modules):
        """Build the network input tensor (+ albedo, coat_tint for fusion). Override to add features."""
        base_tensors = [
            batch[name].to(device, non_blocking=True)
            for name in [c.name for c in BASELINE_SPEC.base_channels]
        ]
        base_tensors.append(batch["ndotv"].to(device, non_blocking=True))
        base_feat = torch.cat(base_tensors, dim=1)

        normal = batch["normal"].to(device, non_blocking=True)
        reflection_dir = batch["reflection_dir"].to(device, non_blocking=True)
        albedo = batch["albedo"].to(device, non_blocking=True)
        coat_tint = batch["coat_tint"].to(device, non_blocking=True)

        env_feat = modules["env_map"].query(normal.permute(0, 2, 3, 1))
        env_ref_feat = modules["env_ref_map"].query(reflection_dir.permute(0, 2, 3, 1))

        parts = [base_feat]
        if self.use_raw_geom:
            # Raw geometry bypasses the 64x128x8 env-map bottleneck: feed the full normal and
            # reflection vectors directly so the net sees orientation the env query compresses away.
            parts += [normal, reflection_dir]
        parts += [env_feat, env_ref_feat]
        x = torch.cat(parts, dim=1)
        return x, albedo, coat_tint

    def forward(self, batch, modules, device):
        x, albedo, coat_tint = self._assemble_network_input(batch, device, modules)
        radiance = modules["network"](x, albedo, coat_tint)
        if self.halo > 0:
            # overlap inference: the net ran on a (tile+2*halo) window; keep only the center
            # tile^2 so the loss / val metric / stitching align with the (center-only) rgb_gt.
            ts = batch["rgb_gt"].shape[-1]          # logical tile size (GT is center-only)
            h = self.halo
            radiance = radiance[..., h:h + ts, h:h + ts]
        self.last_radiance = radiance.detach()  # engine-level HDR diagnostics
        return self.decode_output(radiance)

    def compute_loss(self, pred, batch, modules, device):
        rgb_gt = batch["rgb_gt"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)
        l1 = self._criterion(pred, rgb_gt, mask)
        smooth = (_env_map_smoothness_loss(modules["env_map"])
                  + _env_map_smoothness_loss(modules["env_ref_map"]))
        total = l1 + self.lambda_smooth * smooth
        return total, {"l1": l1.item(), "smooth": smooth.item()}

    def build_optimizer(self, modules, args):
        network = modules["network"]
        env_map = modules["env_map"]
        env_ref_map = modules["env_ref_map"]
        optimizer = torch.optim.AdamW(
            [
                {"params": network.parameters(), "lr": args.lr_network,
                 "weight_decay": args.weight_decay},
                {"params": env_map.parameters(), "lr": args.lr_env_map,
                 "weight_decay": 0},
                {"params": env_ref_map.parameters(), "lr": args.lr_env_map,
                 "weight_decay": 0},
            ]
        )
        eta_min = getattr(args, "lr_eta_min", 1e-6)
        warmup = getattr(args, "lr_warmup_epochs", 0)
        cosine = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(args.epochs - warmup, 1), eta_min=eta_min
        )
        if warmup > 0:
            warm = torch.optim.lr_scheduler.LinearLR(optimizer, start_factor=0.1,
                                                     total_iters=warmup)
            scheduler = torch.optim.lr_scheduler.SequentialLR(
                optimizer, [warm, cosine], milestones=[warmup])
        else:
            scheduler = cosine
        return optimizer, scheduler

    def config(self):
        return {
            "env_dim": self.env_dim,
            "env_h": self.env_h,
            "env_w": self.env_w,
            "base_ch": self.base_ch,
            "bottleneck_blocks": self.bottleneck_blocks,
            "use_raw_geom": self.use_raw_geom,
            "phys_factored": self.phys_factored,
            "halo": self.halo,
        }
