"""
TileDistAttentionExperiment — combine intra-tile attention bottleneck with a
single distance-to-tile-edge input channel.

Hypothesis: distance-to-edge alone is useless because a plain conv net cannot
exploit the boundary cue; but with global within-tile attention, the network can
use position-aware aggregation to compensate for missing neighbor-tile context.
"""

import torch

from train_lighting.experiments.attention_bn import AttentionBottleneckExperiment


class TileDistAttentionExperiment(AttentionBottleneckExperiment):
    NAME = "tile_dist_attn"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @classmethod
    def from_args(cls, args):
        return cls(
            attn_heads=getattr(args, "attn_heads", 4),
            attn_mlp_ratio=getattr(args, "attn_mlp_ratio", 2.0),
            use_fresnel=getattr(args, "use_fresnel", False),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
        )

    def _in_channels(self):
        # richfeat input + 1 distance channel
        return super()._in_channels() + 1

    def _make_distance(self, x):
        """Normalized distance-to-nearest-tile-edge."""
        B, _, H, W = x.shape
        device = x.device
        yy, xx = torch.meshgrid(
            torch.arange(H, device=device, dtype=torch.float32),
            torch.arange(W, device=device, dtype=torch.float32),
            indexing="ij",
        )
        dy = torch.min(yy + 0.5, (H - 1) - yy + 0.5)
        dx = torch.min(xx + 0.5, (W - 1) - xx + 0.5)
        dist = torch.min(dy, dx)
        max_dist = min(H, W) / 2.0
        dist = dist / max_dist
        return dist.unsqueeze(0).unsqueeze(0).expand(B, 1, H, W)

    def _assemble_network_input(self, batch, device, modules):
        x, albedo, coat_tint = super()._assemble_network_input(batch, device, modules)
        # x is already the richfeat input; insert distance before env tail or just concat
        d = self._make_distance(x)
        x = torch.cat([x, d], dim=1)
        return x, albedo, coat_tint
