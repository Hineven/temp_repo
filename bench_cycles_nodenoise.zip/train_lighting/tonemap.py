"""
Tone mapping utilities matching Blender's Standard pipeline.
Blender: Standard (identity) → sRGB display device → clip → 8-bit
"""

import torch


def linear_to_srgb(x):
    """Convert linear HDR to sRGB (OETF). Matches Blender's display output."""
    # Clamp to safe range to prevent gradient explosion from pow()
    x = torch.clamp(x, min=0.0, max=100.0)
    return torch.where(
        x <= 0.0031308,
        x * 12.92,
        1.055 * torch.pow(x, 1.0 / 2.4) - 0.055
    )


def srgb_to_linear(x):
    """Convert sRGB to linear (EOTF)."""
    x = torch.clamp(x, min=0.0)
    return torch.where(
        x <= 0.04045,
        x / 12.92,
        torch.pow((x + 0.055) / 1.055, 2.4)
    )
