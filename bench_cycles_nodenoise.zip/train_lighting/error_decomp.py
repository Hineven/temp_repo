#!/usr/bin/env python3
"""
Error decomposition diagnostic.

Loads a trained checkpoint, runs the val split ONCE, and decomposes the masked
L1 error along several axes (GT brightness, metallic, roughness, ndotv, mask-edge
proximity, within-tile spatial position). Reveals WHERE the residual lives so we
can pick the right ceiling-raising lever instead of guessing from a scalar.

Error definition matches evaluate() exactly: |decode(pred) - rgb_gt| in sRGB
[0,1], masked to foreground, mean over channels.

Usage:
    python -m train_lighting.error_decomp --run_dir experiments/richfeat/<run>
    python -m train_lighting.error_decomp --checkpoint <run>/checkpoints/best.pt

Outputs -> <run_dir>/error_decomp/: summary.txt + per-axis PNGs + tile heatmap.
"""

import argparse
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from train_lighting.dataset import build_dataloaders


TILE = 32

# Left-closed bucket edges [lo, hi). Final edge set slightly above the data max
# so every foreground pixel lands in a bucket (no out-of-range masking needed).
BRIGHTNESS_EDGES = [0.0, 0.03, 0.06, 0.10, 0.15, 0.25, 0.40, 0.60, 0.80, 1.0001]
METALLIC_EDGES   = [0.0, 0.01, 0.30, 0.70, 1.0001]
ROUGHNESS_EDGES  = [0.0, 0.05, 0.10, 0.20, 0.35, 0.55, 1.0001]
NDOTV_EDGES      = [0.0, 0.10, 0.25, 0.45, 0.70, 1.0001]

BRIGHTNESS_LABELS = ["<.03", ".03-.06", ".06-.10", ".10-.15", ".15-.25",
                     ".25-.40", ".40-.60", ".60-.80", ".80-1.0"]
METALLIC_LABELS   = ["diel<.01", ".01-.30", ".30-.70", "metal>.70"]
ROUGHNESS_LABELS  = ["<.05", ".05-.10", ".10-.20", ".20-.35", ".35-.55", ">.55"]
NDOTV_LABELS      = ["<.10", ".10-.25", ".25-.45", ".45-.70", ".70-1.0"]


def luminance(rgb):  # [B,3,H,W] -> [B,1,H,W]  (Rec 709)
    return 0.2126 * rgb[:, 0:1] + 0.7152 * rgb[:, 1:2] + 0.0722 * rgb[:, 2:3]


class BucketAccum:
    """Accumulate mean abs error, signed error, and pixel count per value bucket."""
    def __init__(self, edges, device):
        self.n = len(edges) - 1
        self.interior = torch.tensor(edges[1:-1], device=device)  # n-1 boundaries
        self.sum_abs = torch.zeros(self.n, device=device)
        self.sum_signed = torch.zeros(self.n, device=device)
        self.count = torch.zeros(self.n, device=device)

    @torch.no_grad()
    def add(self, values, err_abs, err_signed):
        idx = torch.bucketize(values, self.interior, right=True).clamp(0, self.n - 1)
        self.count.scatter_add_(0, idx, torch.ones_like(values))
        self.sum_abs.scatter_add_(0, idx, err_abs)
        self.sum_signed.scatter_add_(0, idx, err_signed)

    def results(self, total_abs):
        cnt = self.count.clamp(min=1)
        mean = (self.sum_abs / cnt).cpu().numpy()
        signed = (self.sum_signed / cnt).cpu().numpy()
        count = self.count.cpu().numpy()
        share = (self.sum_abs / max(total_abs, 1e-8)).cpu().numpy()
        return mean, signed, count, share


def _erode(m, k):
    """Binary erosion (Chebyshev radius k) via max-pool of the complement. m:[B,1,H,W]."""
    return 1.0 - F.max_pool2d(1.0 - m, kernel_size=2 * k + 1, stride=1, padding=k)


@torch.no_grad()
def decompose(experiment, modules, device, val_loader):
    """One pass over val; returns a dict of all decomposed statistics."""
    for m in modules.values():
        m.eval()

    bright = BucketAccum(BRIGHTNESS_EDGES, device)
    metal  = BucketAccum(METALLIC_EDGES, device)
    rough  = BucketAccum(ROUGHNESS_EDGES, device)
    ndv    = BucketAccum(NDOTV_EDGES, device)

    spatial_sum = torch.zeros(TILE, TILE, device=device)  # within-tile position
    spatial_cnt = torch.zeros(TILE, TILE, device=device)

    edge_sum = {"edge<=2px": 0.0, "2-4px": 0.0, "interior>4px": 0.0}
    edge_cnt = {"edge<=2px": 0, "2-4px": 0, "interior>4px": 0}

    clamp_cnt = clamp_abs = clamp_signed = 0.0
    total_abs = total_signed = 0.0
    total_cnt = 0
    n_batches = 0

    has_mat = True  # metallic/roughness present? (richfeat spec yes; guard anyway)

    for batch in val_loader:
        pred = experiment.forward(batch, modules, device)             # [B,3,H,W] sRGB
        gt   = batch['rgb_gt'].to(device, non_blocking=True)
        mask = batch['mask'].to(device, non_blocking=True)
        fg   = (mask > 0.5).squeeze(1)                                # [B,H,W] bool

        # overlap-inference: feature channels (ndotv/metallic/roughness) are cut at halo size,
        # but pred/gt/mask/fg are the center tile. Crop feature channels to the center so the
        # per-bucket indexing by `fg` aligns.
        halo = getattr(experiment, "halo", 0)
        def _center(t):
            if halo > 0 and t.shape[-1] != mask.shape[-1]:
                h, ts = halo, mask.shape[-1]
                return t[..., h:h + ts, h:h + ts]
            return t

        diff = pred - gt
        err_abs = diff.abs().mean(dim=1)                             # [B,H,W]
        err_signed = diff.mean(dim=1)                                # [B,H,W]
        gt_lum = luminance(gt).squeeze(1)                            # [B,H,W]

        a   = err_abs[fg]                                            # [N] per-fg-pixel
        s   = err_signed[fg]
        lum = gt_lum[fg]
        nd  = _center(batch['ndotv'].to(device)).squeeze(1)[fg]

        bright.add(lum, a, s)
        ndv.add(nd, a, s)
        if has_mat and 'metallic' in batch and 'roughness' in batch:
            met = _center(batch['metallic'].to(device)).squeeze(1)[fg]
            rgh = _center(batch['roughness'].to(device)).squeeze(1)[fg]
            metal.add(met, a, s)
            rough.add(rgh, a, s)

        # within-tile spatial accumulation (reveals tile-boundary / seam concentration)
        spatial_sum += (err_abs * fg.float()).sum(0)
        spatial_cnt += fg.float().sum(0)

        # mask-silhouette edge bands (err_abs/err_signed are [B,H,W]; masks are [B,H,W])
        m4 = fg.unsqueeze(1).float()
        e2 = _erode(m4, 2).squeeze(1) >= 0.5     # >=2px from silhouette edge
        e4 = _erode(m4, 4).squeeze(1) >= 0.5     # >=4px from silhouette edge
        bands = {"edge<=2px": fg & ~e2, "2-4px": e2 & ~e4, "interior>4px": e4}
        for name, bsel in bands.items():
            edge_sum[name] += err_abs[bsel].sum().item()
            edge_cnt[name] += int(bsel.sum().item())

        # specular-saturation analysis: GT clamped near white
        clamp_sel = (gt_lum > 0.95) & fg
        clamp_cnt  += int(clamp_sel.sum().item())
        clamp_abs   += err_abs[clamp_sel].sum().item()
        clamp_signed+= err_signed[clamp_sel].sum().item()

        total_abs    += a.sum().item()
        total_signed += s.sum().item()
        total_cnt    += a.numel()
        n_batches    += 1

    overall_abs = total_abs / max(total_cnt, 1)
    overall_signed = total_signed / max(total_cnt, 1)

    return {
        "bright": bright.results(total_abs),
        "metal":  metal.results(total_abs) if has_mat else None,
        "rough":  rough.results(total_abs) if has_mat else None,
        "ndv":    ndv.results(total_abs),
        "spatial_mean": (spatial_sum / spatial_cnt.clamp(min=1)).cpu().numpy(),
        "spatial_cnt":  spatial_cnt.cpu().numpy(),
        "edge_sum": edge_sum, "edge_cnt": edge_cnt,
        "clamp_cnt": clamp_cnt, "clamp_abs": clamp_abs, "clamp_signed": clamp_signed,
        "total_abs": total_abs, "total_cnt": total_cnt,
        "overall_abs": overall_abs, "overall_signed": overall_signed,
        "n_batches": n_batches,
    }


# ----------------------------------------------------------------------------
# Reporting
# ----------------------------------------------------------------------------

def _fmt_table(title, labels, mean, signed, count, share, lines):
    lines.append(f"\n=== {title} ===")
    lines.append(f"  {'bucket':<14} {'mean_abs':>9} {'signed':>9} {'share':>7} {'count':>10}")
    lines.append("  " + "-" * 54)
    for i, lab in enumerate(labels):
        cnt = int(count[i])
        cstr = f"{cnt/1e3:.0f}k" if cnt >= 1000 else str(cnt)
        lines.append(f"  {lab:<14} {mean[i]:>9.4f} {signed[i]:>+9.4f} {share[i]*100:>6.1f}% {cstr:>10}")
    tot = count.sum()
    lines.append(f"  {'(total pix)':<14} {'':>9} {'':>9} {'':>7} {int(tot)/1e6:.2f}M".rstrip())


def write_summary(out_path, r, run_dir):
    mean_b, sig_b, cnt_b, shr_b = r["bright"]
    mean_m, sig_m, cnt_m, shr_m = r["metal"]
    mean_r, sig_r, cnt_r, shr_r = r["rough"]
    mean_n, sig_n, cnt_n, shr_n = r["ndv"]

    lines = []
    lines.append(f"Error decomposition — {run_dir}")
    lines.append(f"val pixels analysed: {r['total_cnt']/1e6:.2f}M over {r['n_batches']} batches")
    lines.append(f"OVERALL mean|err| = {r['overall_abs']:.4f}  (signed {r['overall_signed']:+.4f})")
    lines.append("  -> signed <0 means the model UNDER-predicts (pred < GT) on average.")

    _fmt_table("BRIGHTNESS (GT sRGB luminance)", BRIGHTNESS_LABELS, mean_b, sig_b, cnt_b, shr_b, lines)
    _fmt_table("METALLIC", METALLIC_LABELS, mean_m, sig_m, cnt_m, shr_m, lines)
    _fmt_table("ROUGHNESS", ROUGHNESS_LABELS, mean_r, sig_r, cnt_r, shr_r, lines)
    _fmt_table("NDOTV (view grazing angle)", NDOTV_LABELS, mean_n, sig_n, cnt_n, shr_n, lines)

    # silhouette edge bands
    lines.append("\n=== MASK-SILHOUETTE EDGE PROXIMITY ===")
    lines.append(f"  {'band':<14} {'mean_abs':>9} {'count':>10}")
    lines.append("  " + "-" * 36)
    for name in ["edge<=2px", "2-4px", "interior>4px"]:
        c = r["edge_cnt"][name]
        m = r["edge_sum"][name] / max(c, 1)
        cstr = f"{c/1e3:.0f}k" if c >= 1000 else str(c)
        lines.append(f"  {name:<14} {m:>9.4f} {cstr:>10}")

    # specular clamp
    lines.append("\n=== SPECULAR SATURATION (GT luminance > 0.95) ===")
    cc = r["clamp_cnt"]
    lines.append(f"  clamped pixels: {cc/1e3:.0f}k ({cc/max(r['total_cnt'],1)*100:.1f}% of foreground)")
    if cc > 0:
        lines.append(f"  their mean|err| = {r['clamp_abs']/cc:.4f}  "
                     f"(signed {r['clamp_signed']/cc:+.4f})")
        lines.append(f"  vs overall mean|err| = {r['overall_abs']:.4f}")

    # within-tile boundary (seam) analysis
    sp = r["spatial_mean"]
    sc = r["spatial_cnt"]
    valid = sc > 0
    boundary_mask = np.zeros((TILE, TILE), dtype=bool)
    boundary_mask[0, :] = boundary_mask[-1, :] = True
    boundary_mask[:, 0] = boundary_mask[:, -1] = True
    bvals = sp[boundary_mask & valid]
    ivals = sp[(~boundary_mask) & valid]
    lines.append("\n=== WITHIN-TILE BOUNDARY (seam indicator) ===")
    lines.append(f"  tile-boundary pixels (row/col 0 & 31): mean|err| = {bvals.mean():.4f}")
    lines.append(f"  tile-interior pixels (rows/cols 1-30):  mean|err| = {ivals.mean():.4f}")
    lines.append(f"  boundary/interior ratio = {bvals.mean()/max(ivals.mean(),1e-8):.2f}x  "
                 f"(1.0x = no seam artifact)")

    out_path.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    return lines


def _plot_axis(path, title, xlabel, labels, mean, signed, share):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 6), sharex=True,
                                   gridspec_kw={'height_ratios': [2, 1]})
    x = np.arange(len(labels))
    ax1.bar(x, mean, color='steelblue')
    for i, v in enumerate(mean):
        ax1.text(i, v, f"{share[i]*100:.0f}%", ha='center', va='bottom', fontsize=8)
    ax1.set_ylabel('mean |err| (sRGB L1)')
    ax1.set_title(title)
    ax1.grid(axis='y', alpha=0.3)
    ax2.bar(x, signed, color=['crimson' if v < 0 else 'seagreen' for v in signed])
    ax2.axhline(0, color='k', lw=0.5)
    ax2.set_ylabel('signed err (− = under-pred)')
    ax2.set_xticks(x); ax2.set_xticklabels(labels, rotation=30, ha='right', fontsize=8)
    ax2.set_xlabel(xlabel)
    ax2.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(str(path), dpi=140); plt.close()


def plot_all(out_dir, r):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    mb, sb, cb, hb = r["bright"]
    _plot_axis(out_dir / "brightness.png", "Error vs GT brightness",
               "GT sRGB luminance bucket", BRIGHTNESS_LABELS, mb, sb, hb)
    if r["metal"] is not None:
        mm, sm, cm, hm = r["metal"]
        _plot_axis(out_dir / "metallic.png", "Error vs metallic",
                   "metallic bucket", METALLIC_LABELS, mm, sm, hm)
        mr, sr, cr, hr = r["rough"]
        _plot_axis(out_dir / "roughness.png", "Error vs roughness",
                   "roughness bucket", ROUGHNESS_LABELS, mr, sr, hr)
    mn, sn, cn, hn = r["ndv"]
    _plot_axis(out_dir / "ndotv.png", "Error vs NdotV (grazing angle)",
               "ndotv bucket", NDOTV_LABELS, mn, sn, hn)

    # within-tile spatial heatmap
    sp = r["spatial_mean"]
    fig, ax = plt.subplots(figsize=(6, 5.5))
    im = ax.imshow(sp, cmap='magma', aspect='auto')
    ax.set_title("Mean |err| by within-tile position (32x32)\n"
                 "bright row/col 0 & 31 = tile boundary (seam indicator)")
    ax.set_xlabel("tile x"); ax.set_ylabel("tile y")
    fig.colorbar(im, ax=ax, fraction=0.046)
    # annotate edge-vs-interior ratio
    edge_cols = np.concatenate([sp[:, 0], sp[:, -1], sp[0, :], sp[-1, :]])
    interior = np.concatenate([sp[1:-1, 1:-1].flatten()])
    ax.set_xlabel(f"tile x   (edge mean={edge_cols.mean():.4f}, "
                  f"interior mean={interior.mean():.4f})")
    plt.tight_layout(); plt.savefig(str(out_dir / "tile_spatial.png"), dpi=140); plt.close()

    print(f"\nPlots saved to {out_dir}/")


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Decompose masked-L1 error by pixel attributes.")
    p.add_argument("--run_dir", type=str, default=None)
    p.add_argument("--checkpoint", type=str, default=None,
                   help="explicit checkpoint (default <run_dir>/checkpoints/best.pt)")
    p.add_argument("--dataset_dir", type=str, default=None,
                   help="dataset dir (default: from run config.json)")
    p.add_argument("--batch_size", type=int, default=1024)
    args = p.parse_args()

    if args.checkpoint:
        ckpt = args.checkpoint
    elif args.run_dir:
        ckpt = str(Path(args.run_dir) / "checkpoints" / "best.pt")
    else:
        p.error("provide --run_dir or --checkpoint")

    from train_lighting.single_view_eval import experiment_from_checkpoint
    experiment, modules, device = experiment_from_checkpoint(ckpt)

    # dataset dir + seed from the run config so the val split matches training exactly
    run_dir = Path(ckpt).resolve().parent.parent
    cfg_path = run_dir / "config.json"
    cfg = json.loads(cfg_path.read_text()) if cfg_path.exists() else {}
    cfg_args = cfg.get("args", {})
    ds_dir = args.dataset_dir or cfg_args.get("dataset_dir", "dataset_frozen")
    seed = cfg_args.get("seed", 42)
    data_device = cfg_args.get("data_device", "cpu")
    print(f"dataset_dir={ds_dir} seed={seed} data_device={data_device}")

    print("Loading dataset (val split must match training)...")
    _, val_loader = build_dataloaders(
        dataset_dir=ds_dir, batch_size=args.batch_size, num_workers=4,
        load_workers=8, seed=seed, feature_spec=experiment.feature_spec,
        device=data_device, halo=getattr(experiment, "halo", 0),
    )

    out_dir = run_dir / "error_decomp"
    out_dir.mkdir(parents=True, exist_ok=True)

    print("Running decomposition over val set...")
    r = decompose(experiment, modules, device, val_loader)
    write_summary(out_dir / "summary.txt", r, run_dir)
    plot_all(out_dir, r)
    print(f"\nDone. Outputs in {out_dir}")


if __name__ == "__main__":
    main()
