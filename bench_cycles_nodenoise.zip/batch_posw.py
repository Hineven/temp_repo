#!/usr/bin/env python3
"""
World Position (posW) 补全脚本
为每个 view 渲染 world-space position pass，保存为 posW.exr

Position pass 是 deterministic 的，1 sample 即可精确。
用法:
    blender scene.blend --background --python batch_posw.py
"""

import bpy
import json
import os
import sys
from pathlib import Path
from mathutils import Vector, Euler

# ============================================================================
# CONFIG
# ============================================================================

SCRIPT_DIR = Path(__file__).parent.resolve()
DATASET_DIR = SCRIPT_DIR / "dataset"
ITEMS_DIR = SCRIPT_DIR / "Items"

RESOLUTION = 1024
POSW_SAMPLES = 1  # Position pass 是几何计算，1 sample 足够

# ============================================================================
# UTILITIES (from batch_ao.py)
# ============================================================================

def get_mesh_obj(obj):
    if obj.type == 'MESH':
        return obj
    meshes = [c for c in obj.children_recursive if c.type == 'MESH']
    return meshes[0] if meshes else obj


def clear_scene_model():
    if "Model" in bpy.data.objects:
        obj = bpy.data.objects["Model"]
        data = obj.data
        bpy.data.objects.remove(obj)
        if data and data.users == 0:
            if data.__class__.__name__ == 'Mesh':
                bpy.data.meshes.remove(data)


def import_glb(filepath):
    existing = set(bpy.context.scene.objects)
    bpy.ops.import_scene.gltf(filepath=str(filepath))
    new_objs = [o for o in bpy.context.scene.objects if o not in existing]
    root_meshes = [o for o in new_objs if o.type == 'MESH' and o.parent is None]
    if root_meshes:
        root = root_meshes[0]
    else:
        meshes = [o for o in new_objs if o.type == 'MESH']
        root = meshes[0] if meshes else new_objs[0]
    root.name = "Model"
    return root


def setup_camera():
    scene = bpy.context.scene
    if "Camera" in bpy.data.objects and bpy.data.objects["Camera"].type == 'CAMERA':
        return bpy.data.objects["Camera"]
    cam_data = bpy.data.cameras.new("Camera")
    cam_obj = bpy.data.objects.new("Camera", cam_data)
    scene.collection.objects.link(cam_obj)
    scene.camera = cam_obj
    return cam_obj


# ============================================================================
# POSITION PASS RENDERING
# ============================================================================

def setup_position_pass():
    """
    启用 View Layer 的 Position pass，配置 Compositor 输出到 EXR。
    """
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    cycles = scene.cycles
    cycles.samples = POSW_SAMPLES
    cycles.device = 'GPU'
    cycles.use_denoising = False
    scene.render.resolution_x = RESOLUTION
    scene.render.resolution_y = RESOLUTION
    scene.render.resolution_percentage = 100
    scene.render.use_compositing = True
    scene.use_nodes = True

    # GPU 设置
    prefs = bpy.context.preferences
    cpref = prefs.addons['cycles'].preferences
    cpref.get_devices()
    for device in cpref.devices:
        device.use = True

    # 启用 Position pass
    vl = bpy.context.view_layer
    vl.use_pass_position = True

    # 配置 Compositor: RenderLayers.Position → File Output (EXR)
    tree = scene.node_tree
    nodes = tree.nodes
    links = tree.links

    # 清理旧节点
    for node in list(nodes):
        nodes.remove(node)

    # Render Layers
    rl = nodes.new(type='CompositorNodeRLayers')
    rl.location = (0, 0)

    # File Output (EXR)
    file_out = nodes.new(type='CompositorNodeOutputFile')
    file_out.location = (400, 0)
    file_out.format.file_format = 'OPEN_EXR'
    file_out.format.color_mode = 'RGB'
    file_out.format.color_depth = '32'
    file_out.format.exr_codec = 'ZIP'

    # 连接 Position pass
    if 'Position' in rl.outputs:
        links.new(rl.outputs['Position'], file_out.inputs[0])
    else:
        print("  ERROR: Position pass not available in Render Layers!")
        return None

    return file_out


def render_posw_view(obj, camera_pos, camera_rot, output_path):
    """
    从指定相机位置渲染 world position pass。
    如果 output_path 已存在，跳过。
    """
    output_path = Path(output_path)
    if output_path.exists():
        return True

    camera = setup_camera()
    camera.location = Vector(camera_pos)
    camera.rotation_euler = Euler(camera_rot)

    file_out = setup_position_pass()
    if file_out is None:
        return False

    # 设置输出路径
    file_out.base_path = str(output_path.parent)
    file_out.file_slots[0].path = output_path.stem

    # 渲染
    bpy.ops.render.render()

    # Blender File Output 会添加帧后缀，需要重命名
    # 格式: posw0001.exr → posw.exr
    frame = bpy.context.scene.frame_current
    frame_suffix = f"{frame:04d}"
    actual_file = output_path.parent / f"{output_path.stem}{frame_suffix}.exr"
    if actual_file.exists():
        if output_path.exists():
            os.remove(output_path)
        os.rename(actual_file, output_path)

    return True


# ============================================================================
# MAIN
# ============================================================================

def main():
    print("=" * 60)
    print("World Position Pass Batch Render")
    print("=" * 60)

    models = sorted([p.stem for p in ITEMS_DIR.glob("*.glb")])
    print(f"Models: {models}")
    print(f"Total models: {len(models)}")

    total_views = 0
    completed = 0
    skipped = 0
    errors = 0

    for model_name in models:
        print(f"\n{'='*60}")
        print(f"Model: {model_name}")
        print(f"{'='*60}")

        glb_path = ITEMS_DIR / f"{model_name}.glb"

        clear_scene_model()
        obj = import_glb(str(glb_path))

        model_dir = DATASET_DIR / model_name
        if not model_dir.exists():
            print(f"  No dataset found for {model_name}, skipping")
            continue

        for variant_dir in sorted(model_dir.glob("variant_*")):
            variant_name = variant_dir.name
            print(f"  {variant_name}")

            # 读取第一个 view 的 metadata 获取模型旋转
            first_view_dir = sorted(variant_dir.glob("view_*"))[0]
            meta_path = first_view_dir / "metadata.json"
            with open(meta_path) as f:
                meta = json.load(f)
            model_rot = Euler(meta['model_transform']['rotation_euler'])

            # 应用旋转
            obj.location = Vector((0, 0, 0))
            obj.rotation_euler = model_rot
            obj.scale = Vector((1, 1, 1))

            for view_dir in sorted(variant_dir.glob("view_*")):
                total_views += 1
                posw_output = view_dir / "posW.exr"

                if posw_output.exists():
                    skipped += 1
                    continue

                # 读取 metadata 获取相机参数
                meta_path = view_dir / "metadata.json"
                with open(meta_path) as f:
                    meta = json.load(f)

                cam_pos = meta['camera']['location']
                cam_rot = meta['camera']['rotation_euler']

                ok = render_posw_view(obj, cam_pos, cam_rot, str(posw_output))
                if ok:
                    completed += 1
                else:
                    errors += 1

                if (completed + errors) % 50 == 0:
                    print(f"    Progress: {completed} rendered, {skipped} skipped, {errors} errors")

    print(f"\n{'='*60}")
    print("Position Pass Batch Complete!")
    print(f"  Total views: {total_views}")
    print(f"  Rendered: {completed}")
    print(f"  Skipped: {skipped}")
    print(f"  Errors: {errors}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
