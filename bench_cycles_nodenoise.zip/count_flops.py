"""FLOP counter for both networks, run at their native inference resolution.

Convention: FLOPs = 2 * MACs (multiply + add counted as 2 ops). Conv2d FLOPs =
H_out*W_out * (C_in/groups) * K_h*K_w * C_out * 2. ConvTranspose2d same but at upsampled
output resolution. grid_sample ~ 5 ops/pixel/channel (bilinear). Reported in GFLOps.
"""
import sys
from pathlib import Path
import torch
import torch.nn as nn

# ---- Part 2 (current experiments) ----
sys.path.insert(0, str(Path(__file__).resolve().parent))
from train_lighting.network import UNetRadiance, NeuralEnvMap, AttentionBottleneckUNetRadiance, MixedAttentionBottleneckUNetRadiance, LightUNetRadiance, IntraTileSelfAttention

# ---- Part 1 (pre_experiment) ----
sys.path.insert(0, r"F:\CLionProjects\Falcor-VRS\scripts\pre_experiment\network")
from network import UNetV14


def conv2d_flops(mod, x, y):
    # y is output [B, C_out, H, W]; x input [B, C_in, ...]
    out_h, out_w = y.shape[-2], y.shape[-1]
    c_out = mod.out_channels
    c_in_per_g = mod.in_channels // mod.groups
    kh, kw = mod.kernel_size
    macs = out_h * out_w * c_out * c_in_per_g * kh * kw
    return 2 * macs


def convtranspose_flops(mod, x, y):
    # Transposed conv: count MACs at INPUT resolution (H_in), not the upsampled output.
    # Each input pixel broadcasts kernel^2 contributions; total MACs = H_in*W_in * C_in * C_out * K^2 / groups.
    # (Counting at H_out — the naive mistake — overcounts by stride^2. Validated vs fvcore.)
    in_h, in_w = x.shape[-2], x.shape[-1]
    c_in = mod.in_channels
    c_out = mod.out_channels
    kh, kw = mod.kernel_size
    macs = in_h * in_w * c_in * c_out * kh * kw / mod.groups
    return 2 * macs


def attention_flops(mod, x, y):
    """Count Q@K.T and attn@V matmuls in IntraTileSelfAttention."""
    # x[0] is [B, C, H, W]; after qkv conv -> [B, 3C, H, W]
    B, C, H, W = y.shape
    N = H * W
    # each of Q@K.T and attn@V costs B * heads * N * N * head_dim MACs
    # = B * N * N * C MACs total across heads
    macs = 2 * B * N * N * C
    return 2 * macs


def count_model(net, example_inputs, label):
    total = 0.0
    breakdown = {}
    hooks = []

    def make_hook(name, fn):
        def hook(m, inp, out):
            nonlocal total
            if isinstance(out, torch.Tensor):
                f = fn(m, inp[0] if isinstance(inp, tuple) else inp, out)
                breakdown[name] = breakdown.get(name, 0.0) + f
                total += f
        return hook

    for name, m in net.named_modules():
        if isinstance(m, nn.ConvTranspose2d):
            hooks.append(m.register_forward_hook(make_hook(name + "[ConvT]", convtranspose_flops)))
        elif isinstance(m, nn.Conv2d):
            hooks.append(m.register_forward_hook(make_hook(name + "[Conv]", conv2d_flops)))
        elif isinstance(m, IntraTileSelfAttention):
            hooks.append(m.register_forward_hook(make_hook(name + "[Attn]", attention_flops)))

    with torch.no_grad():
        net(*example_inputs)
    for h in hooks:
        h.remove()
    params = sum(p.numel() for p in net.parameters())
    print(f"\n=== {label} ===")
    print(f"  params: {params:,}")
    print(f"  total FLOPs (per forward): {total:,.0f} = {total/1e9:.4f} GFLOPs")
    # group by layer type
    print(f"  per-layer GFLOPs:")
    for k, v in sorted(breakdown.items(), key=lambda kv: -kv[1]):
        if v / 1e9 > 1e-4:
            print(f"    {v/1e9:8.4f}  {k}")
    return total


print("################ PART 1: UNetV14 (point-light, full-frame) ################")
net1 = UNetV14(in_channels=14, encoder_out=32, feat_channels=2, base_ch=32, bottleneck_ch=128)
net1.eval()
x1 = torch.randn(1, 14, 512, 512)  # native train/inference resolution
f1 = count_model(net1, [x1], "Part1 UNetV14 @ 512x512 (per frame)")

print("\n################ PART 2: UNetRadiance (per-tile) ################")
# best config: richfeat --use_fresnel --base_ch 32 --bottleneck_blocks 6 --phys_factored --use_raw_geom
# in_channels = 6 base + 1 ndotv + 6 raw_geom + 1 fresnel + 2*8 env = 22
IN_CH = 29
net2 = UNetRadiance(in_channels=IN_CH, base_ch=32, bottleneck_blocks=6, phys_factored=True)
net2.eval()
env = NeuralEnvMap(feature_dim=8, h=64, w=128)
env_ref = NeuralEnvMap(feature_dim=8, h=64, w=128)
x2 = torch.randn(1, IN_CH, 32, 32)        # per tile
albedo = torch.rand(1, 3, 32, 32)
coat_tint = torch.rand(1, 3, 32, 32)
# env map query cost (grid_sample): 2 queries x 8 ch x 32x32 x ~5 ops
env_flops = 2 * (8 * 32 * 32 * 5)
f2 = count_model(net2, [x2, albedo, coat_tint], "Part2 UNetRadiance @ 32x32 (per tile)")
print(f"  + NeuralEnvMap query (2x grid_sample): {env_flops:,.0f} = {env_flops/1e9:.6f} GFLOPs/tile (negligible)")
f2_total = f2 + env_flops
print(f"  tile total: {f2_total/1e9:.4f} GFLOPs/tile")
# Full 1024x1024 frame = (1024/32)^2 = 1024 tiles
frame = f2_total * 1024
print(f"  full 1024x1024 frame (1024 tiles): {frame/1e9:.3f} GFLOPs")
# Full 512x512 frame (match Part1 res) = (512/32)^2 = 256 tiles
frame512 = f2_total * 256
print(f"  full 512x512 frame (256 tiles):    {frame512/1e9:.3f} GFLOPs")

print("\n################ COMPARISON (both at 512x512-equivalent frame) ################")
print(f"  Part1 UNetV14 @ 512x512:        {f1/1e9:8.3f} GFLOPs/frame")
print(f"  Part2 per-tile  @ 512x512 equiv: {frame512/1e9:8.3f} GFLOPs/frame")

print("\n################ PART 2b: AttentionBottleneckUNetRadiance (per-tile) ################")
net3 = AttentionBottleneckUNetRadiance(in_channels=IN_CH, base_ch=32, bottleneck_blocks=6,
                                        phys_factored=True, attn_heads=4, attn_mlp_ratio=2.0)
net3.eval()
f3 = count_model(net3, [x2, albedo, coat_tint], "Part2b AttentionBottleneckUNetRadiance @ 32x32 (per tile)")
print(f"  + NeuralEnvMap query (2x grid_sample): {env_flops:,.0f} = {env_flops/1e9:.6f} GFLOPs/tile (negligible)")
f3_total = f3 + env_flops
print(f"  tile total: {f3_total/1e9:.4f} GFLOPs/tile")
frame3_1024 = f3_total * 1024
frame3_1080 = f3_total * 2040  # 1920x1080 = 60x34 tiles (ceil) = 2040 tiles
print(f"  full 1024x1024 frame (1024 tiles): {frame3_1024/1e9:.3f} GFLOPs")
print(f"  full 1920x1080 frame (2040 tiles): {frame3_1080/1e9:.3f} GFLOPs")

print("\n################ PART 2 COMPARISON ################")
print(f"  UNetRadiance        @ 1024²: {frame/1e9:8.3f} GFLOPs/frame  ({sum(p.numel() for p in net2.parameters())/1e3:.1f}K params)")
print(f"  AttentionBottleneck @ 1024²: {frame3_1024/1e9:8.3f} GFLOPs/frame  ({sum(p.numel() for p in net3.parameters())/1e3:.1f}K params)")

print("\n################ PART 2c: MixedAttentionBottleneckUNetRadiance (per-tile) ################")
for num_attn in [1, 2, 3]:
    net_mixed = MixedAttentionBottleneckUNetRadiance(in_channels=IN_CH, base_ch=32, bottleneck_blocks=6,
                                                     phys_factored=True, num_attn_blocks=num_attn,
                                                     attn_heads=4, attn_mlp_ratio=2.0)
    net_mixed.eval()
    f_mixed = count_model(net_mixed, [x2, albedo, coat_tint], f"Part2c MixedAttention ({num_attn}/6 attn) @ 32x32")
    f_mixed_total = f_mixed + env_flops
    frame_mixed_1024 = f_mixed_total * 1024
    print(f"  full 1024x1024 frame (1024 tiles): {frame_mixed_1024/1e9:.3f} GFLOPs  ({sum(p.numel() for p in net_mixed.parameters())/1e3:.1f}K net params)")

print("\n################ PART 2d: PRTLight (LightUNetRadiance + 3 directional env maps) ################")
# prt_light input = 6 base + 6 raw_geom + 1 fresnel + 3*8 env(normal,reflection,view) = 37
PRT_IN = 37
env_per_tile = 3 * (8 * 32 * 32 * 5)  # 3 grid_samples @ 8 ch (negligible vs the net)
for prt_ch in [6, 8, 10, 12]:
    net_prt = LightUNetRadiance(in_channels=PRT_IN, base_ch=prt_ch, bottleneck_blocks=3,
                                phys_factored=True)
    net_prt.eval()
    x_prt = torch.randn(1, PRT_IN, 32, 32)
    f_prt = count_model(net_prt, [x_prt, albedo, coat_tint], f"Part2d prt_light ch={prt_ch} @ 32x32")
    f_prt_total = f_prt + env_per_tile
    frame_prt_1024 = f_prt_total * 1024
    frame_prt_1080 = f_prt_total * 2040  # 1920x1080
    net_p = sum(p.numel() for p in net_prt.parameters())
    env_p = 3 * (8 * 64 * 128)  # 3 env maps @ feature_dim=8, 64x128
    print(f"  ch={prt_ch:2d}: {frame_prt_1024/1e9:6.2f} GFLOPs@1024²  {frame_prt_1080/1e9:6.2f} GFLOPs@1080p"
          f"  | net {net_p/1e3:5.1f}K + 3 env maps {env_p/1e3:5.1f}K = {(net_p+env_p)/1e3:5.1f}K params")

