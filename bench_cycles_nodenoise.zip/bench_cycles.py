#!/usr/bin/env python3
"""
Cycles 性能/质量基准 —— 16spp + 降噪 vs 1024spp GT。

复用 render_pipeline 的场景构建逻辑，从 dataset_frozen/<model>/<variant>/<view>/metadata.json
精确重建该视角（模型旋转、变体纹理、相机位姿均来自 metadata + 已保存纹理），然后以
不同 spp 渲染并测量单帧耗时、相对 GT(radiance.exr) 的 MSE / sRGB-L1。

用法:
  blender scene.blend --background --python bench_cycles.py -- \
      --views 71/variant_00/view_00,71/variant_00/view_05 \
      --out benchmark_cycles.json
"""

import bpy
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np

# render_pipeline 与本脚本同目录
SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
import render_pipeline as RP

DATASET_DIR = SCRIPT_DIR / "dataset_frozen"
ITEMS_DIR = SCRIPT_DIR / "Items"
TEXTURES_DIR = SCRIPT_DIR / "textures"

DEFAULT_VIEWS = [
    "71/variant_00/view_00",
    "71/variant_00/view_05",
    "71/variant_00/view_10",
]

# (name, samples, denoise, n_warmup, n_timed)
RENDER_CONFIGS = [
    ("cycles_16spp_denoise", 16, True, 1, 3),
    ("cycles_1024spp_denoise_gt", 1024, True, 0, 1),
]

RENDER_DEVICE = "GPU"
RESOLUTION = 1024


# ============================================================================
# ARG PARSING
# ============================================================================

def parse_args():
    argv = sys.argv
    argv = argv[argv.index("--") + 1:] if "--" in argv else []
    views = list(DEFAULT_VIEWS)
    out = "benchmark_cycles.json"
    i = 0
    while i < len(argv):
        if argv[i] == "--views":
            views = argv[i + 1].split(",")
            i += 2
        elif argv[i] == "--out":
            out = argv[i + 1]
            i += 2
        else:
            i += 1
    return views, out


# ============================================================================
# RENDER SETTINGS
# ============================================================================

def configure_render(samples, denoise):
    scene = bpy.context.scene
    render = scene.render
    render.engine = 'CYCLES'
    render.resolution_x = RESOLUTION
    render.resolution_y = RESOLUTION
    render.resolution_percentage = 100
    cycles = scene.cycles
    cycles.samples = samples
    cycles.use_denoising = denoise
    if RENDER_DEVICE == "GPU":
        cycles.device = 'GPU'
        try:
            prefs = bpy.context.preferences
            cpref = prefs.addons['cycles'].preferences
            cpref.get_devices()
            for d in cpref.devices:
                d.use = True
        except Exception:
            cycles.device = 'CPU'
    else:
        cycles.device = 'CPU'
    scene.view_settings.view_transform = 'Standard'
    scene.view_settings.look = 'None'
    render.image_settings.file_format = 'OPEN_EXR'
    render.image_settings.color_depth = '32'
    render.film_transparent = True


# ============================================================================
# VIEW RECONSTRUCTION
# ============================================================================

def load_variant_textures(model_name, variant_id):
    """Load the pre-generated variant textures (same ones the dataset used)."""
    vdir = TEXTURES_DIR / model_name / f"variant_{variant_id:02d}"
    textures = {}
    for tex_name in ("sss_weight", "coat_weight", "coat_tint"):
        p = vdir / f"{tex_name}.png"
        if p.exists():
            img = bpy.data.images.load(str(p))
            img.name = f"{model_name}_v{variant_id:02d}_{tex_name}"
            textures[tex_name] = img
    return textures


def reconstruct_view(view_dir):
    """Rebuild the scene exactly as render_pipeline produced this view."""
    meta = json.loads((view_dir / "metadata.json").read_text())
    model_name = meta["model_name"]
    variant_id = meta["variant_id"]

    # Import the GLB (replacing scene.blend's placeholder Model)
    RP.clear_default_model()
    model_obj = RP.import_glb(str(ITEMS_DIR / f"{model_name}.glb"))

    # Apply the EXACT model rotation recorded in metadata (not re-sampled)
    tinfo = meta["model_transform"]
    model_obj.rotation_euler = tinfo["rotation_euler"]
    model_obj.location = tinfo["location"]
    bpy.context.view_layer.update()

    # Apply the variant material (textures already saved by the pipeline)
    textures = load_variant_textures(model_name, variant_id)
    mat = meta["material"]
    sssw_range = tuple(mat["sss_weight_range"])
    coatw_range = tuple(mat["coat_weight_range"])
    RP.setup_all_materials(model_obj, textures, sssw_range, coatw_range)

    # Camera placement from metadata
    cinfo = meta["camera"]
    camera = RP.setup_camera()
    camera.location = cinfo["location"]
    camera.rotation_euler = cinfo["rotation_euler"]
    camera.data.angle = math.radians(cinfo["fov"])
    bpy.context.scene.camera = camera
    bpy.context.view_layer.update()


# ============================================================================
# RENDER + TIMING
# ============================================================================

def render_to_exr(out_path):
    scene = bpy.context.scene
    scene.render.filepath = str(out_path)
    t0 = time.perf_counter()
    bpy.ops.render.render(write_still=True)
    return time.perf_counter() - t0


def load_exr_rgb(path):
    img = bpy.data.images.load(str(path))
    w, h = img.size
    px = np.zeros(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    bpy.data.images.remove(img)
    px = px.reshape(h, w, 4)[:, :, :3]
    return np.ascontiguousarray(px[::-1, :, :])


def load_mask(view_dir):
    img = bpy.data.images.load(str(view_dir / "mask.png"))
    w, h = img.size
    px = np.zeros(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    bpy.data.images.remove(img)
    alpha = px.reshape(h, w, 4)[::-1, :, 3]
    return (alpha > 0.5).astype(np.float32)


# ============================================================================
# METRICS (match training conventions: sRGB L1 = 3× per-channel mean)
# ============================================================================

def linear_to_srgb(x):
    a = 0.055
    return np.where(x <= 0.0031308, 12.92 * x,
                    (1 + a) * np.power(np.clip(x, 0, None), 1 / 2.4) - a)


def masked_metrics(pred_lin, gt_lin, mask):
    m = mask.astype(bool)
    p = linear_to_srgb(np.clip(pred_lin, 0, 1))[m]
    g = linear_to_srgb(np.clip(gt_lin, 0, 1))[m]
    return {
        "srgb_l1": float(np.mean(np.abs(p - g))) * 3.0,
        "srgb_mse": float(np.mean((p - g) ** 2)),
        "linear_mse": float(np.mean((pred_lin[m] - gt_lin[m]) ** 2)),
        "linear_l1": float(np.mean(np.abs(pred_lin[m] - gt_lin[m]))),
        "n_pixels": int(m.sum()),
    }


# ============================================================================
# MAIN
# ============================================================================

def main():
    views, out_path = parse_args()
    print(f"[bench] views={views}")
    print(f"[bench] device={RENDER_DEVICE}")
    results = {"device": RENDER_DEVICE, "resolution": RESOLUTION, "views": {}}

    for view in views:
        view_dir = (DATASET_DIR / view).resolve()
        if not (view_dir / "metadata.json").exists():
            print(f"[bench] SKIP {view} (no metadata)")
            continue

        reconstruct_view(view_dir)
        mask = load_mask(view_dir)
        gt = load_exr_rgb(view_dir / "radiance.exr")

        results["views"][view] = {}
        for name, samples, denoise, n_warmup, n_timed in RENDER_CONFIGS:
            configure_render(samples, denoise)
            print(f"[bench] {view} :: {name} (spp={samples}, denoise={denoise})")

            tmp = view_dir / f"_bench_{name}.exr"
            for _ in range(n_warmup):
                render_to_exr(tmp)

            times = [render_to_exr(tmp) for _ in range(n_timed)]
            pred = load_exr_rgb(tmp)
            try:
                os.remove(tmp)
            except OSError:
                pass

            metrics = masked_metrics(pred, gt, mask)
            entry = {
                "samples": samples,
                "denoise": denoise,
                "time_per_frame_ms": float(np.mean(times) * 1000.0),
                "time_std_ms": float(np.std(times) * 1000.0) if len(times) > 1 else 0.0,
                "n_timed": n_timed,
                **metrics,
            }
            results["views"][view][name] = entry
            print(f"   -> {entry['time_per_frame_ms']:.1f}±{entry['time_std_ms']:.1f} ms/frame  "
                  f"srgb_l1={entry['srgb_l1']:.4f}  srgb_mse={entry['srgb_mse']:.6f}  "
                  f"linear_mse={entry['linear_mse']:.6f}")

    Path(out_path).write_text(json.dumps(results, indent=2))
    print(f"\n[bench] wrote {out_path}")
    print("\n=== SUMMARY (mean over views) ===")
    print(f"{'config':<32} {'ms/frame':>10} {'srgb_l1':>9} {'srgb_mse':>11} {'lin_mse':>11}")
    for name, *_ in RENDER_CONFIGS:
        ts, l1s, mses, lmses = [], [], [], []
        for v in results["views"].values():
            if name in v:
                e = v[name]
                ts.append(e["time_per_frame_ms"])
                l1s.append(e["srgb_l1"])
                mses.append(e["srgb_mse"])
                lmses.append(e["linear_mse"])
        if ts:
            print(f"{name:<32} {np.mean(ts):>10.1f} {np.mean(l1s):>9.4f} "
                  f"{np.mean(mses):>11.6f} {np.mean(lmses):>11.6f}")


if __name__ == "__main__":
    main()
