#!/usr/bin/env python3
"""
Build a HW_DATASET-format dataset from the frozen single-object 71 set.

HW_DATASET.md format (per data directory):
    images/00xx_0001.png   tonemapped LDR render
    mesh.ply               mesh, vertices carry xyz + st (uv)
    transforms_{all,train,test,val}.json
        { "camera_angle_x": radians, "frames": [
            {"file_path": "images/00xx_0001", "transform_matrix": 4x4 cam2world, "time": 0}, ... ] }

Inputs (already on disk):
    Items/71.glb                                 geometry + vertex UV
    dataset_frozen/71/variant_00/view_NNNN/      per-view metadata.json (camera) + rgb.png (LDR)

The view split mirrors the legacy frozen loader's exact shuffle (sorted glob, seed 42) so that
HW `val` == legacy frozen `val` (same 180 views) and val_l1 stays directly comparable. We additionally
carve a `test` split off the front of the train portion.

    test  = shuffle[   0 :  180]
    train = shuffle[ 180 : 1620]
    val   = shuffle[1620 : 1800]   (== legacy val)
    all   = every view (in sorted order)
"""
import argparse
import json
import math
import random
import shutil
from pathlib import Path

import numpy as np
import trimesh
from plyfile import PlyData, PlyElement

SCRIPT_DIR = Path(__file__).resolve().parent


def _gltf_node_rotation(glb_path):
    """Read the glTF scene-graph rotation(s) along the path to the mesh and return the composed 3x3.
    glb stores node rotations as quaternions [x,y,z,w]. Returns None if no rotation."""
    import json
    import struct

    data = open(glb_path, "rb").read()
    assert data[:4] == b"glTF", "not a glb"
    off = 12
    chunks = []
    while off + 8 <= len(data):
        clen = struct.unpack("<I", data[off:off + 4])[0]
        ctype = data[off + 4:off + 8]
        chunks.append((ctype, data[off + 8:off + 8 + clen]))
        off += 8 + clen
    g = json.loads(chunks[0][1])

    def quat_to_mat(q):
        x, y, z, w = q
        return np.array([
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ], dtype=np.float64)

    R = np.eye(3, dtype=np.float64)
    for node in g.get("nodes", []):
        if "rotation" in node:
            R = quat_to_mat(node["rotation"]) @ R
    return None if np.allclose(R, np.eye(3)) else R


def euler_xyz_to_matrix(rx, ry, rz):
    """Blender Euler-XYZ rotation matrix R = Rz @ Ry @ Rx (matches utils.compute_view_direction_map)."""
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    return np.array([
        [cy * cz,   sx * sy * cz - sz * cx,   cx * sy * cz + sz * sx],
        [cy * sz,   sx * sy * sz + cz * cx,   cx * sy * sz - cz * sx],
        [-sy,       sx * cy,                  cx * cy],
    ], dtype=np.float64)


def cam2world_from_metadata(cam):
    """4x4 camera-to-world from Blender camera location + rotation_euler (XYZ, -Z forward, +Y up)."""
    loc = np.array(cam["location"], dtype=np.float64)
    rx, ry, rz = cam["rotation_euler"]
    R = euler_xyz_to_matrix(rx, ry, rz)
    M = np.eye(4, dtype=np.float64)
    M[:3, :3] = R
    M[:3, 3] = loc
    return M


def write_mesh_ply(path, verts, faces, uvs):
    """Write mesh.ply: vertices with x y z s t, and triangle faces (vertex_indices)."""
    N = verts.shape[0]
    vdata = np.empty(N, dtype=[("x", "f4"), ("y", "f4"), ("z", "f4"),
                               ("s", "f4"), ("t", "f4")])
    vdata["x"] = verts[:, 0].astype(np.float32)
    vdata["y"] = verts[:, 1].astype(np.float32)
    vdata["z"] = verts[:, 2].astype(np.float32)
    vdata["s"] = uvs[:, 0].astype(np.float32)
    vdata["t"] = uvs[:, 1].astype(np.float32)

    F = faces.shape[0]
    fdata = np.empty(F, dtype=[("vertex_indices", "i4", (3,))])
    fdata["vertex_indices"] = faces.astype(np.int32)

    el_v = PlyElement.describe(vdata, "vertex")
    el_f = PlyElement.describe(fdata, "face")
    PlyData([el_v, el_f], text=False).write(str(path))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--glb", default=str(SCRIPT_DIR / "Items" / "71.glb"))
    ap.add_argument("--frozen", default=str(SCRIPT_DIR / "dataset_frozen"))
    ap.add_argument("--out", default=str(SCRIPT_DIR / "dataset_hw_71"))
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    glb_path = Path(args.glb)
    frozen = Path(args.frozen)
    out = Path(args.out)
    (out / "images").mkdir(parents=True, exist_ok=True)

    # ---- mesh.ply ----
    # Load the glb and BAKE the glTF scene-graph node transform into the vertices, so mesh.ply is
    # in the same frame Blender's glTF importer produces (the "imported"/as-rendered local frame).
    # glTF is Y-up with node rotations; Blender applies them on import. trimesh leaves vertices in
    # glTF-local space, so without this the rasterized silhouette is rotated vs the renders.
    print(f"[mesh] loading {glb_path.name} ...")
    m = trimesh.load(str(glb_path), force="mesh")
    verts = np.asarray(m.vertices, dtype=np.float64)
    faces = np.asarray(m.faces, dtype=np.int64)
    uvs = np.asarray(m.visual.uv, dtype=np.float64)
    assert uvs is not None and uvs.shape == (verts.shape[0], 2), "mesh has no per-vertex UV"
    node_rot = _gltf_node_rotation(glb_path)
    if node_rot is not None:
        verts = verts @ node_rot.T  # apply rigid node rotation (UV unchanged)
        print(f"[mesh] applied glTF node rotation (baked into vertices)")
    print(f"[mesh] V={verts.shape[0]} F={faces.shape[0]} uv∈[{uvs.min():.3f},{uvs.max():.3f}]")
    write_mesh_ply(out / "mesh.ply", verts, faces, uvs)
    print(f"[mesh] wrote {out/'mesh.ply'}")

    # ---- views (exact legacy sort + shuffle so val matches) ----
    views = sorted(frozen.glob("*/*/view_*"))
    print(f"[views] {len(views)} frozen views")
    order = views[:]
    random.Random(args.seed).shuffle(order)
    # index every view by its position in the SORTED list (stable image filename)
    sorted_index = {v: i for i, v in enumerate(views)}

    # Dynamic 10/80/10 split so the same script works for the full 1800-view dataset
    # and for reduced half-size datasets (~900 views) while keeping val non-empty.
    n = len(order)
    n_test = max(1, round(n * 0.1))
    n_val = max(1, round(n * 0.1))
    n_train = n - n_test - n_val
    splits = {
        "test":  order[0:n_test],
        "train": order[n_test:n_test + n_train],
        "val":   order[n_test + n_train:],
        "all":   views,
    }
    assert len(splits["train"]) + len(splits["val"]) + len(splits["test"]) == len(views)

    fov_deg = 45.0  # square 1024 sensor -> x-fov == y-fov; all frozen views use 45
    camera_angle_x = math.radians(fov_deg)

    # build per-view record: copy LDR image + camera transform. Done once per view.
    per_view = {}
    for v in views:
        meta = json.load(open(v / "metadata.json"))
        cam = meta["camera"]
        i = sorted_index[v]
        img_dst = out / "images" / f"{i:04d}_0001.png"
        if not img_dst.exists():
            shutil.copy2(v / "rgb.png", img_dst)
        per_view[v] = {
            "file_path": f"images/{i:04d}_0001",
            "transform_matrix": cam2world_from_metadata(cam).tolist(),
            "time": 0.0,
        }
    print(f"[images] copied {len(per_view)} LDR renders -> {out/'images'}")

    for split_name, split_views in splits.items():
        frames = [per_view[v] for v in split_views]
        # sort frames by file_path index for deterministic, human-readable ordering
        frames.sort(key=lambda f: f["file_path"])
        doc = {"camera_angle_x": camera_angle_x, "frames": frames}
        (out / f"transforms_{split_name}.json").write_text(json.dumps(doc, indent=2))
        print(f"[split] {split_name:5s}: {len(frames)} frames -> transforms_{split_name}.json")

    print(f"\nDone. HW dataset at {out}")


if __name__ == "__main__":
    main()
