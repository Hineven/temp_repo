# Per-Tile Neural Radiance Prediction — 训练方案

> 基于数据集：`d:\TestScene\FixedLighting1ItemTemplate\dataset\`
> 规模：11 模型 × 10 变体 × 20 视角 = 2200 views

---

## 1. 数据集现状分析

### 1.1 每 view 已有文件

```
rgb.png                 # uint8 [0,255], LDR color (sRGB encoded)
radiance.exr            # float32, linear HDR radiance (RGBA, alpha=1)
albedo.png              # uint8 [0,255], base color
metallic_roughness.png  # uint8 [0,255], R=metallic, G=roughness, B=0
normal.png              # uint8 [0,255], world-space normal encoded: (N+1)/2
sss_weight.png          # uint8 [0,255], 1-chan
 coat_weight.png         # uint8 [0,255], 1-chan
coat_tint.png           # uint8 [0,255], RGB
ao.png                  # uint8 [0,255], ambient occlusion
metadata.json           # camera, model_transform, material params
```

### 1.2 缺失 & 待补

| 缺失项 | 用途 | 补法 |
|--------|------|------|
| **hit world position** (`posW.exr`) | 计算 view_dir、depth、linear depth、ray-marching 等 | Blender 补渲染 Position pass |
| **object mask** | 排除背景 pixel，避免训练 env map 背景 | 可从 albedo=0 推断，或从 posW valid 推断 |

### 1.3 Mask 推断（当前可行）

- `albedo.sum(axis=2) > 0` → object pixel
- 覆盖率：~5%–10%（物体在画面中占比较小）
- 背景 pixel 的 G-Buffer 值：albedo=0, normal=(0,0,0), metallic=0, roughness=0

> ⚠️ 注意：roughness AOV 理论值 = 0.75，但 PNG 输出实测约 126/255 ≈ 0.49，疑为 Blender Compositor Value pass 的颜色管理导致。不影响训练一致性，但需知。

---

## 2. Blender Tone Mapping 分析（关键结论）

### 2.1 Blender Pipeline

```
Scene Linear (Cycles render)
    → View Transform: Standard (identity, no curve)
    → Display Device: sRGB (default)
    → Quantize to 8-bit → PNG
```

### 2.2 数值验证

| 比较 | Mean Error | 结论 |
|------|-----------|------|
| `rgb/255` vs `sRGB_OETF(radiance)` | 0.0012 | **精确匹配** |
| `rgb/255` vs `sRGB_OETF(radiance * scale)` | 0.0128 (best scale=1.09) | 无 exposure scaling |
| `rgb/255` vs `gamma2.2(radiance)` | 0.0100 | 不如 sRGB 精确 |

**结论**：`rgb.png/255 ≈ clip(sRGB_OETF(radiance.exr), 0, 1)`

即：Blender Standard = linear pass-through，PNG 输出时应用 **sRGB OETF**（IEC 61966-2-1），然后 clip 到 [0,1] 再量化到 8-bit。

### 2.3 PyTorch 复现

```python
def linear_to_srgb(x):
    x = torch.clamp(x, min=0.0)
    return torch.where(
        x <= 0.0031308,
        x * 12.92,
        1.055 * torch.pow(x, 1.0 / 2.4) - 0.055
    )

# Forward
def forward(...):
    radiance = network(...)           # [B, 3, H, W], unbounded HDR
    color = linear_to_srgb(radiance)  # sRGB encoded
    color = torch.clamp(color, 0, 1)  # clip (Blender also clips)
    return color

# Loss
loss = F.l1_loss(pred_color, gt_rgb / 255.0)
```

---

## 3. Neural Feature Map（env_map / env_ref_map）

### 3.1 设计：Spherical Equirectangular Feature Grid

```python
class NeuralEnvMap(nn.Module):
    """
    可学习的球面 feature map，equirectangular 投影存储。
    """
    def __init__(self, feature_dim=8, h=64, w=128):
        super().__init__()
        # 可学习参数: [feature_dim, H, W]
        self.grid = nn.Parameter(torch.randn(feature_dim, h, w) * 0.01)
        self.feature_dim = feature_dim

    def query(self, directions):
        """
        directions: [B, H, W, 3], 单位向量（world-space）
        returns:    [B, feature_dim, H, W]
        """
        # 球坐标 → UV
        theta = torch.atan2(directions[..., 1], directions[..., 0])  # [-π, π]
        phi   = torch.acos(torch.clamp(directions[..., 2], -1, 1))   # [0, π]
        u = theta / (2 * math.pi) + 0.5   # [0, 1]
        v = phi / math.pi                  # [0, 1]
        uv = torch.stack([u, v], dim=-1) * 2 - 1  # [B, H, W, 2] in [-1, 1]
        # grid_sample 期望 [B, C, H, W] 和 [B, H, W, 2]
        grid = self.grid.unsqueeze(0).expand(directions.size(0), -1, -1, -1)
        features = F.grid_sample(grid, uv, mode='bilinear', padding_mode='border')
        return features
```

### 3.2 Query 来源

| Map | Query 方向 | 计算方式 |
|-----|-----------|---------|
| `env_map` | **normal** (world-space) | 直接来自 G-Buffer |
| `env_ref_map` | **reflection_dir** | `R = 2 * NDotV * N - V` |

### 3.3 待确认

- **共享方式**：11 模型共享同一套 env_map（环境贴图相同）？还是 per-scene / per-variant 独立？
 - 答：共享一套env_map。
- **Feature dim**：8？16？
 - 答：8
- **Grid resolution**：64×32？128×64？
 - 答：64x32
- **是否需要 smoothness regularization** 防止过拟合？
 - 答：需要，但开很小lambda即可。

---

## 4. 网络架构：UNetRadiance

### 4.1 输入 Feature（per-pixel）

```
基础 encoding (6 ch):
  [ao, coat_weight, metallic, roughness, sss_weight, NDotV]

Neural feature (2F ch):
  env_feature     = env_map.query(normal)          # F ch
  env_ref_feature = env_ref_map.query(reflection_dir)  # F ch

总输入: [B, 6 + 2F, 16, 16]
```

### 4.2 U-Net 结构

```
Input: [B, 6+2F, 16, 16]

Encoder (LeakyReLU, 1 SepConvBlock per level):
  L0: SepConv(in→16)   → ConvPool(16→16, stride=2)   [B,16,8,8]
  L1: SepConv(16→32)   → ConvPool(32→32, stride=2)   [B,32,4,4]
  L2: SepConv(32→64)   → ConvPool(64→64, stride=2)   [B,64,2,2]

Bottleneck (Mish, 3× SepConvBlock):
  SepConv(64→64) → Mish
  SepConv(64→64) → Mish
  SepConv(64→64) → Mish

Decoder (LeakyReLU, 1 SepConvBlock per level):
  Up2: ConvTranspose(64→32) + skip(L2) → SepConv(64→32)  [B,32,4,4]
  Up1: ConvTranspose(32→16) + skip(L1) → SepConv(32→16)  [B,16,8,8]
  Up0: ConvTranspose(16→16) + skip(L0) → SepConv(32→16)  [B,16,16,16]

Fusing (bottleneck 后):
  concat([decoder_out, albedo, coat_tint]) → 1×1 Conv → [B,16,16,16]

Head: Conv(16 → 3) → radiance [B,3,16,16]
```

### 4.3 SepConvBlock

```python
class SepConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        # Depthwise
        self.dw = nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=False)
        self.gn1 = nn.GroupNorm(_gn_groups(in_ch), in_ch)
        self.act1 = nn.LeakyReLU(0.1, inplace=True)
        # Pointwise
        self.pw = nn.Conv2d(in_ch, out_ch, 1, bias=False)
        self.gn2 = nn.GroupNorm(_gn_groups(out_ch), out_ch)
        self.act2 = nn.LeakyReLU(0.1, inplace=True)

    def forward(self, x):
        x = self.act1(self.gn1(self.dw(x)))
        x = self.act2(self.gn2(self.pw(x)))
        return x
```

### 4.4 待确认

- **"MLP Pooling（Conv）"**：是指用 `Conv2d(stride=2)` 代替 MaxPool？还是某种 MLP-based pooling（如 ConvMLP）？
 - 答：没错就是Conv2d(stride=2)
- **"其它地方卷一次"**：encoder/decoder 每层仅 1 个 SepConvBlock，bottleneck 3 个 SepConvBlock 串联 — 对吗？
 - 答：对
- **Fusing 位置**："U-Net 在 bottleneck 后" 是指 decoder 最末端（16×16 分辨率），在 head 之前？
 - 答：对
- **albedo / coat_tint 参与 fusing**：是从原始 G-Buffer 取值，还是网络内部传递？
 - 答：从原始G-Buffer取值和网络内部传递应该没区别吧
---

## 5. 数据加载 & Tile 采样

### 5.1 实时计算（Dataset 内部，float32，无量化）

不生成额外 `.npy` 文件。每个 worker 进程按需加载 view，在 **float32** 中实时计算：

| Feature | 计算方式 |
|---------|---------|
| `view_dir` | camera pos + rotation + pixel 坐标（vectorized numpy） |
| `ndotv` | `clamp(dot(normal, view_dir), 0, 1)` |
| `reflection_dir` | `2*NDotV*normal - view_dir`，normalize |
| `mask` | `albedo.sum(axis=2) > 0` |

> ⚠️ **全程 float32**，PNG 加载后 `/255.0` 即进入 float32，不再转回 uint8。

### 5.2 Tile 采样策略

```
全图 1024×1024 → 64×64 = 4096 个 16×16 tiles

训练时：
  1. 随机选 N_views 张图
  2. 每张图随机采样 K_tiles 个 16×16 tile（优先含物体的 tile）
  3. Batch = N_views × K_tiles tiles

Mask 处理：
  - 方案 A：只采样含物体的 tile（mask 覆盖率 > threshold）
  - 方案 B：采样所有 tile，loss 时 masked（background pixel loss = 0）
```

### 5.3 待确认

- 每图采样多少 tile？（如 64 或 128）
 - 答：按分辨率预切。同时，忽略没有物体的tile。在dataset加载时可以进行预切。
- Batch size 多大？
 - 答：1024 tile
- 是否对 background tile 也采样？
 - 答：不采样
---

## 6. Loss & Training

### 6.1 Loss

```python
def forward_and_loss(pred_radiance, gt_rgb_png, mask):
    # Tone mapping (matching Blender)
    pred_color = linear_to_sRGB(pred_radiance)
    pred_color = torch.clamp(pred_color, 0, 1)

    gt_color = gt_rgb_png.float() / 255.0  # [B, 3, 16, 16]

    # Masked L1
    diff = (pred_color - gt_color).abs()
    loss = (diff * mask).sum() / (mask.sum() + 1e-8)
    return loss
```

### 6.2 优化器

```python
# 分组优化：env_map 可以用更大 lr
optimizer = torch.optim.AdamW([
    {"params": network.parameters(), "lr": 3e-4, "weight_decay": 1e-5},
    {"params": env_map.parameters(), "lr": 1e-3, "weight_decay": 0},
    {"params": env_ref_map.parameters(), "lr": 1e-3, "weight_decay": 0},
])

scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-6)
```

### 6.3 可选正则化

```python
# env_map smoothness: 鼓励相邻方向 feature 相似
env_smooth_loss = (
    (env_map.grid[:, :, 1:] - env_map.grid[:, :, :-1]).pow(2).mean() +
    (env_map.grid[:, 1:, :] - env_map.grid[:, :-1, :]).pow(2).mean()
)
total_loss = l1_loss + lambda_smooth * env_smooth_loss
```

---

## 7. 代码结构

```
train_lighting/
├── __init__.py         # package marker
├── network.py          # NeuralEnvMap + SepConvBlock + UNetRadiance
├── dataset.py          # TileDataset (per-worker LRU view cache, on-the-fly compute)
├── train.py            # 训练循环, checkpoint, eval, visualization
├── tonemap.py          # linear_to_sRGB, sRGB_to_linear
└── utils.py            # view direction 计算, normal decode, mask
```

---

## 8. 关键待确认问题汇总

| # | 问题 | 已确认答案 |
|---|------|-----------|
| ① | **env_map 共享方式** | 全局共享（11模型共用同一套 env_map + env_ref_map） |
| ② | **MLP Pooling + 卷积次数** | Downsample = `Conv2d(stride=2)`；Encoder/Decoder 各 1 SepConvBlock，Bottleneck 3 SepConvBlock 串联 |
| ③ | **Loss 空间** | sRGB 空间 L1（`linear_to_sRGB(pred)` vs `rgb.png/255`，masked） |
| ④ | **训练目标** | Cross-scene generalization |
| ⑤ | **Tile 采样策略** | 只采样含物体 tile（background tile 不采样），16×16 |
| ⑥ | **env_map feature_dim / resolution** | 8 dim / 64×32 equirectangular grid |
| ⑦ | **Fusing 细节** | Decoder 最末端（16×16），concat(decoder_out, albedo, coat_tint) → 1×1 Conv |
| ⑧ | **Batch size / cache** | Batch=1024 tiles；per-worker LRU cache 10 views；persistent_workers |
| ⑨ | **Smoothness regularization** | 启用，λ=1e-4（很小） |
| ⑩ | **数据精度** | 全程 float32，PNG `/255.0` 后不再量化 |
