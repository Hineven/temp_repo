#!/usr/bin/env python3
"""Smoke test: HW-format dataloader + one forward/backward pass for an experiment."""
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from train_lighting.dataset_hw import build_dataloaders_hw
from train_lighting.experiments import get_experiment_class
from train_lighting.train import MaskedL1Loss


def smoke(experiment_name="neural_tex_mlp", dataset_dir="dataset_hw_71", convention="opengl"):
    print(f"=== Smoke test: {experiment_name} on HW dataset ({dataset_dir}, convention={convention}) ===")

    # Build args-like namespace manually
    class Args:
        neural_tex_dim = 16
        neural_tex_res = 256
        env_dim = 8
        env_h = 64
        env_w = 128
        base_ch = 16
        bottleneck_blocks = 3
        lambda_smooth = 1e-4
        use_raw_geom = False
        phys_factored = True
        halo = 0
        hidden_dim = 64
        num_hidden_layers = 3
        aux_full = 8
        aux_half = 4
        aux_quarter = 4
        num_transformer_blocks = 1
        attn_heads = 4
        attn_mlp_ratio = 2.0
        lr_network = 3e-4
        lr_env_map = 1e-3
        weight_decay = 1e-5
        epochs = 1
        lr_eta_min = 1e-6
        lr_warmup_epochs = 0

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    exp_cls = get_experiment_class(experiment_name)
    experiment = exp_cls.from_args(Args())
    modules = experiment.build_modules(device)

    train_loader, val_loader = build_dataloaders_hw(
        dataset_dir=dataset_dir,
        batch_size=128,
        num_workers=0,
        load_workers=2,
        seed=42,
        feature_spec=experiment.feature_spec,
        device="cpu",
        halo=0,
        convention=convention,
    )

    optimizer, _ = experiment.build_optimizer(modules, Args())
    criterion = MaskedL1Loss()

    for i, batch in enumerate(train_loader):
        pred = experiment.forward(batch, modules, device)
        loss, _ = experiment.compute_loss(pred, batch, modules, device)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        print(f"  batch {i}: loss={loss.item():.4f}  pred range=[{pred.min():.3f},{pred.max():.3f}]")
        if i >= 1:
            break

    # val forward
    batch = next(iter(val_loader))
    with torch.no_grad():
        pred = experiment.forward(batch, modules, device)
        val_loss = criterion(pred, batch["rgb_gt"].to(device), batch["mask"].to(device))
    print(f"  val batch: loss={val_loss.item():.4f}")
    print("  Smoke test PASSED")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--experiment", default="neural_tex_mlp")
    ap.add_argument("--dataset_dir", default="dataset_hw_71")
    ap.add_argument("--cam_convention", default="opengl",
                    choices=["opengl", "blender", "colmap", "unity", "directx"],
                    help="how to interpret transform_matrix")
    args = ap.parse_args()
    smoke(args.experiment, args.dataset_dir, args.cam_convention)
