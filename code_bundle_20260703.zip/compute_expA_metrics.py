#!/usr/bin/env python3
"""Compute masked LDR L1 for Experiment A models and make tiny-U-Net quality figure."""
import sys
from pathlib import Path

PRE_EXP_NET = Path(r"F:\CLionProjects\Falcor-VRS\scripts\pre_experiment\network")
sys.path.insert(0, str(PRE_EXP_NET))

import numpy as np
import torch
from PIL import Image
from dataset import create_data_buffers
from network import ShadingNetBase


METRIC_EXPOSURE = 1.0
DISPLAY_EXPOSURE = 3.0
DISPLAY_SIZE = 512


def tonemap_reinhard(hdr, exposure=METRIC_EXPOSURE):
    x = hdr * exposure
    return x / (1.0 + x)


def masked_ldr_l1(pred_hdr, tgt_hdr):
    pred_ldr = tonemap_reinhard(pred_hdr)
    tgt_ldr = tonemap_reinhard(tgt_hdr)
    err = np.abs(pred_ldr - tgt_ldr).sum(axis=2)
    mask = tgt_hdr.sum(axis=2) > 1e-4
    if mask.sum() == 0:
        return float('nan'), float(err.mean())
    return float(err[mask].mean()) / 3.0, float(err.mean()) / 3.0


def evaluate_model(ckpt_path, data_dir, target_size=1024, max_views=0, seed=42):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = ShadingNetBase.load_any(str(ckpt_path), device=device)
    model.eval()

    train_buf, eval_buf = create_data_buffers(
        str(data_dir), batch_size=1, eval_ratio=0.1,
        target_size=target_size, max_views=max_views, seed=seed,
    )

    masked_vals = []
    full_vals = []
    records = []
    for i, sample in enumerate(eval_buf.samples):
        gbuf, albedo_t, meta_t, target_t, inten_t, inv_r2_t, _ = sample
        with torch.no_grad():
            comp, _, _ = model.predict(
                gbuf.unsqueeze(0).to(device),
                albedo_t.unsqueeze(0).clamp(0, 1).to(device),
            )
        pred_shading = comp[0].cpu().numpy().transpose(1, 2, 0)
        inv_r2 = inv_r2_t[0].cpu().numpy()[:, :, np.newaxis]
        intensity = inten_t.cpu().numpy()

        pred_hdr = pred_shading * inv_r2 * intensity
        tgt_hdr = target_t.cpu().numpy().transpose(1, 2, 0) * intensity

        m, f = masked_ldr_l1(pred_hdr, tgt_hdr)
        masked_vals.append(m)
        full_vals.append(f)
        records.append((m, i, sample, pred_hdr, tgt_hdr))

    mean_masked = float(np.nanmean(masked_vals))
    mean_full = float(np.nanmean(full_vals))
    return mean_masked, mean_full, records, model


def save_tiny_unet_figure(records, out_path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    try:
        import matplotlib.font_manager as fm
        fonts = [f.name for f in fm.fontManager.ttflist]
        for cn in ['Microsoft YaHei', 'SimHei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC']:
            if cn in fonts:
                plt.rcParams['font.family'] = cn
                plt.rcParams['axes.unicode_minus'] = False
                break
    except Exception:
        pass

    records_sorted = sorted(records, key=lambda x: x[0], reverse=True)
    l1, idx, sample, pred_hdr, tgt_hdr = records_sorted[0]

    # Metric LDR for the error map / reported number; display LDR brighter for visibility
    tgt_ldr_metric = np.clip(tonemap_reinhard(tgt_hdr, METRIC_EXPOSURE), 0, 1)
    pred_ldr_metric = np.clip(tonemap_reinhard(pred_hdr, METRIC_EXPOSURE), 0, 1)
    tgt_ldr_disp = np.clip(tonemap_reinhard(tgt_hdr, DISPLAY_EXPOSURE), 0, 1)
    pred_ldr_disp = np.clip(tonemap_reinhard(pred_hdr, DISPLAY_EXPOSURE), 0, 1)

    err = np.abs(pred_ldr_metric - tgt_ldr_metric).sum(axis=2)
    err_vis = np.clip(err / (err.max() + 1e-8), 0, 1)

    def resize(arr):
        img = Image.fromarray((np.clip(arr, 0, 1) * 255).astype(np.uint8))
        return np.array(img.resize((DISPLAY_SIZE, DISPLAY_SIZE), Image.LANCZOS)) / 255.0

    fig, axes = plt.subplots(1, 3, figsize=(9, 3.2), dpi=150)
    axes[0].imshow(resize(tgt_ldr_disp))
    axes[0].set_title('GT', fontsize=10)
    axes[1].imshow(resize(pred_ldr_disp))
    axes[1].set_title(f'极小 U-Net\nmasked LDR L1={l1:.4f}', fontsize=10)
    axes[2].imshow(resize(err_vis), cmap='hot')
    axes[2].set_title('绝对误差图', fontsize=10)
    for ax in axes:
        ax.axis('off')
    fig.suptitle('极小 U-Net（9.94 GFLOPs）与 GT 的单视角对比（display exposure=3.0）', fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out_path, dpi=150, bbox_inches='tight', pad_inches=0.05)
    plt.close(fig)
    print(f"Saved tiny U-Net quality figure: {out_path}")


def main():
    data_dir = Path(r"D:\pre_experiment_output_v3_mixed")
    base = data_dir
    models = {
        "UNetV14": base / "checkpoints_v17" / "best_model.pt",
        "MLP 2x64": base / "checkpoints_mlp_2x64_real" / "best_model.pt",
        "MLP 4x64": base / "checkpoints_mlp_4x64" / "best_model.pt",
        "MLP 4x128": base / "checkpoints_mlp_4x128" / "best_model.pt",
        "Tiny U-Net": base / "tiny_unet_10g" / "best_model.pt",
    }

    results = {}
    tiny_records = None
    for name, ckpt in models.items():
        print(f"\n=== {name} ===")
        if not ckpt.exists():
            print(f"Missing checkpoint: {ckpt}")
            continue
        mean_masked, mean_full, records, model = evaluate_model(
            ckpt, data_dir, target_size=1024, max_views=300, seed=42
        )
        results[name] = (mean_masked, mean_full)
        print(f"  masked LDR L1 = {mean_masked:.4f}, full = {mean_full:.4f}")
        if name == "Tiny U-Net":
            tiny_records = records

    print("\n=== Summary (masked LDR L1) ===")
    for name, (m, f) in results.items():
        print(f"{name:20s} {m:.4f}  (full {f:.4f})")

    if tiny_records is not None:
        out_fig = Path(r"d:\TestScene\FixedLighting1ItemTemplate\figures\hcx\expA_tiny_unet_quality.png")
        out_fig.parent.mkdir(parents=True, exist_ok=True)
        save_tiny_unet_figure(tiny_records, out_fig)


if __name__ == "__main__":
    main()
