#!/usr/bin/env python3
"""Draw schematic network architecture diagrams for the report."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import ConnectionPatch
from pathlib import Path

OUT_DIR = Path(r'd:\TestScene\FixedLighting1ItemTemplate\figures\hcx')
OUT_DIR.mkdir(parents=True, exist_ok=True)


def set_font():
    try:
        import matplotlib.font_manager as fm
        names = [f.name for f in fm.fontManager.ttflist]
        for cn in ['Microsoft YaHei', 'SimHei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC']:
            if cn in names:
                plt.rcParams['font.family'] = cn
                plt.rcParams['axes.unicode_minus'] = False
                return
    except Exception:
        pass


set_font()


class Box:
    def __init__(self, x, y, w, h, rect, text):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.rect = rect
        self.text = text

    def left(self):
        return self.x - self.w / 2

    def right(self):
        return self.x + self.w / 2

    def top(self):
        return self.y + self.h / 2

    def bottom(self):
        return self.y - self.h / 2


def _measure_text(fig, ax, text, fontsize):
    """Measure text size in data coordinates under the current axis limits."""
    temp = ax.text(0, 0, text, ha='center', va='center', fontsize=fontsize,
                   color='black', alpha=0)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bbox_disp = temp.get_window_extent(renderer=renderer)
    bbox_data = bbox_disp.transformed(ax.transData.inverted())
    temp.remove()
    return bbox_data.width, bbox_data.height


def _estimate_size(ax, text, fontsize, min_w, min_h, pad):
    tw, th = _measure_text(ax.figure, ax, text, fontsize)
    w = max(min_w, tw + 2 * pad)
    h = max(min_h, th + 2 * pad)
    return w, h


def draw_box(ax, x, y, text, color='lightblue', fontsize=8, text_color='black',
             min_w=0.5, min_h=0.45, pad=0.13, w=None, h=None):
    """Draw a box. If w/h not given, size it to fit the text."""
    if w is None or h is None:
        tw, th = _measure_text(ax.figure, ax, text, fontsize)
        if w is None:
            w = max(min_w, tw + 2 * pad)
        if h is None:
            h = max(min_h, th + 2 * pad)
    rect = patches.FancyBboxPatch((x - w / 2, y - h / 2), w, h,
                                  boxstyle="round,pad=0.02,rounding_size=0.03",
                                  facecolor=color, edgecolor='black', linewidth=1.2)
    ax.add_patch(rect)
    txt = ax.text(x, y, text, ha='center', va='center', fontsize=fontsize,
                  color=text_color, linespacing=1.0)
    return Box(x, y, w, h, rect, txt)


def draw_arrow(ax, b1, b2, color='black', style='->', rad=0.0, linestyle='-'):
    """Arrow between box edges; patchA/B make it stop at the rectangles."""
    con = ConnectionPatch((b1.x, b1.y), (b2.x, b2.y),
                          coordsA='data', coordsB='data',
                          arrowstyle=style, color=color, linewidth=1.2,
                          linestyle=linestyle, connectionstyle=f'arc3,rad={rad}',
                          patchA=b1.rect, patchB=b2.rect)
    ax.add_patch(con)


def draw_skip(ax, b1, b2, color='gray', rad=0.25):
    draw_arrow(ax, b1, b2, color=color, style='->', rad=rad, linestyle='--')


def chain_left(ax, y, start_x, gap, items, fontsize=8, min_w=0.5, min_h=0.45, pad=0.13):
    """Place boxes left-to-right, returning them in the same order."""
    boxes = []
    x = start_x
    for it in items:
        w, h = _estimate_size(ax, it['text'], fontsize, min_w, min_h, pad)
        cx = x + w / 2
        box = draw_box(ax, cx, y, it['text'], color=it['color'], fontsize=fontsize, w=w, h=h)
        boxes.append(box)
        x = cx + w / 2 + gap
    return boxes


def chain_right(ax, y, right_edge, gap, items, fontsize=8, min_w=0.5, min_h=0.45, pad=0.13):
    """Place boxes right-to-left, returning them in the order given (rightmost first)."""
    boxes = []
    edge = right_edge
    for it in items:
        w, h = _estimate_size(ax, it['text'], fontsize, min_w, min_h, pad)
        cx = edge - w / 2
        box = draw_box(ax, cx, y, it['text'], color=it['color'], fontsize=fontsize, w=w, h=h)
        boxes.append(box)
        edge = cx - w / 2 - gap
    return boxes


def set_xlim_from_boxes(ax, boxes, margin=0.35):
    """Tight horizontal limits that include all boxes; vertical limits stay generous."""
    min_x = min(b.left() for b in boxes) - margin
    max_x = max(b.right() for b in boxes) + margin
    ax.set_xlim(min_x, max_x)


def save(fig, name):
    out = OUT_DIR / name
    fig.savefig(out, dpi=200, bbox_inches='tight', pad_inches=0.08)
    plt.close(fig)
    print(f'Saved {out}')


# =============================================================================
# 1. Experiment A U-NetV14
# =============================================================================
def draw_expA_unet():
    fig, ax = plt.subplots(figsize=(12, 5.2))
    ax.set_xlim(0, 25)
    ax.set_ylim(-0.5, 6)
    ax.axis('off')

    y_enc = 3.5
    y_dec = 1.5

    # Top row: downsampling path, ends at bottleneck (the bend of the U)
    enc_items = [
        {'text': 'G-Buffer\n14 ch', 'color': '#ffe4b5'},
        {'text': 'PBR hints\n(F/G1/Ndot*)\n→ 14 ch', 'color': '#ffdead'},
        {'text': '1×1 Conv\nGN + Mish\n32 ch', 'color': '#add8e6'},
        {'text': 'enc1\nSepConv\n32→32', 'color': '#98fb98'},
        {'text': 'pool\n32²→16²', 'color': '#d3d3d3'},
        {'text': 'enc2\nSepConv\n64', 'color': '#98fb98'},
        {'text': 'pool\n16²→8²', 'color': '#d3d3d3'},
        {'text': 'bottleneck\nSepConv\n128', 'color': '#98fb98'},
    ]
    enc = chain_left(ax, y_enc, 0.5, 0.25, enc_items)

    # Bottom row: upsampling path, starts at bottleneck and goes left
    dec_items = [
        {'text': 'up2\n8²→16²', 'color': '#d3d3d3'},
        {'text': 'dec2\nSepConv\n64', 'color': '#dda0dd'},
        {'text': 'up1\n16²→32²', 'color': '#d3d3d3'},
        {'text': 'dec1\nSepConv\n32', 'color': '#dda0dd'},
        {'text': 'fuse\n+ albedo\n1×1', 'color': '#f08080'},
        {'text': 'head\n2 ch', 'color': '#f08080'},
        {'text': 'softplus(s_d)·albedo\n+ softplus(s_s)·F0\n= composite', 'color': '#ffb6c1'},
        {'text': '× I / r²\nradiance', 'color': '#ffd700'},
    ]
    dec = chain_right(ax, y_dec, enc[-1].right(), 0.25, dec_items)

    # Forward arrows in the top row
    for i in range(len(enc) - 1):
        draw_arrow(ax, enc[i], enc[i + 1])

    # Arrow from bottleneck down to up2 (first decoder block)
    draw_arrow(ax, enc[-1], dec[0])

    # Forward arrows in the bottom row (leftward)
    for i in range(len(dec) - 1):
        draw_arrow(ax, dec[i], dec[i + 1])

    # Skip connections: route them around the outside of the U to avoid overlapping blocks
    draw_skip(ax, enc[5], dec[1], rad=0.40)   # enc2 -> dec2
    draw_skip(ax, enc[3], dec[3], rad=-0.35)  # enc1 -> dec1

    all_boxes = enc + dec
    set_xlim_from_boxes(ax, all_boxes)
    save(fig, 'schematic_expA_unet.png')


# =============================================================================
# 2. Experiment B Shallow CNN
# =============================================================================
def draw_expB_shallow_cnn():
    fig, ax = plt.subplots(figsize=(12.5, 4.8))
    ax.set_xlim(0, 25)
    ax.set_ylim(-0.5, 5.5)
    ax.axis('off')

    items = [
        {'text': 'x_full\ngeom + aux_full\n@32²', 'color': '#ffe4b5'},
        {'text': 'enc1\nSepConv\nc1', 'color': '#add8e6'},
        {'text': 'pool\n32²→16²', 'color': '#d3d3d3'},
        {'text': 'enc2\nSepConv\nc2\n+ aux_h + aux_q↑', 'color': '#98fb98'},
        {'text': 'SepUpsample\n16²→32²', 'color': '#d3d3d3'},
        {'text': 'fuse\nup + e1 + albedo + coat\n1×1 + LReLU', 'color': '#f08080'},
        {'text': 'phys_factored head\nalbedo⊙softplus(shade) + res\n→ radiance', 'color': '#ffb6c1'},
    ]
    boxes = chain_left(ax, 2.4, 0.5, 0.3, items)

    enc1 = boxes[1]
    enc2 = boxes[3]
    fuse = boxes[5]

    for i in range(len(boxes) - 1):
        draw_arrow(ax, boxes[i], boxes[i + 1])

    aux_h = draw_box(ax, enc2.x, 4.1, 'aux_half\n@16²', color='#fffacd', fontsize=8)
    aux_q = draw_box(ax, enc2.x, 0.7, 'aux_quarter\n@8² → ↑', color='#fffacd', fontsize=8)
    draw_arrow(ax, aux_h, enc2, rad=0.12)
    draw_arrow(ax, aux_q, enc2, rad=-0.12)

    draw_skip(ax, enc1, fuse, rad=-0.28)

    all_boxes = boxes + [aux_h, aux_q]
    set_xlim_from_boxes(ax, all_boxes)
    save(fig, 'schematic_expB_shallow_cnn.png')


# =============================================================================
# 3. Experiment B mrt_nonorm
# =============================================================================
def draw_expB_mrt_nonorm():
    fig, ax = plt.subplots(figsize=(13, 5.6))
    ax.set_xlim(0, 25)
    ax.set_ylim(-0.8, 6.5)
    ax.axis('off')

    y_top = 4.0
    y_bot = 1.4

    enc_items = [
        {'text': 'x_full\ngeom + aux_full\n@32²', 'color': '#ffe4b5'},
        {'text': 'enc1\nSepConv\nc1', 'color': '#add8e6'},
        {'text': 'pool\n32²→16²', 'color': '#d3d3d3'},
        {'text': 'enc2\nSepConv\nc2', 'color': '#add8e6'},
        {'text': 'pool\n16²→8²', 'color': '#d3d3d3'},
        {'text': 'bottleneck @8²\nc2 + aux_q → bn_ch\n+ IntraTile Attn', 'color': '#98fb98'},
    ]
    enc = chain_left(ax, y_top, 0.5, 0.25, enc_items)

    dec_items = [
        {'text': 'SepUpsample\n8²→16²', 'color': '#d3d3d3'},
        {'text': 'dec2\nup + e2 + aux_h\nSepConv', 'color': '#dda0dd'},
        {'text': 'SepUpsample\n16²→32²', 'color': '#d3d3d3'},
        {'text': 'dec1\nup + e1\nSepConv', 'color': '#dda0dd'},
        {'text': 'fuse\n+ albedo + coat_tint\n1×1 + LReLU', 'color': '#f08080'},
    ]
    dec = chain_right(ax, y_bot, enc[-1].right(), 0.25, dec_items)

    for i in range(len(enc) - 1):
        draw_arrow(ax, enc[i], enc[i + 1])
    draw_arrow(ax, enc[-1], dec[0])  # bn -> upsample2
    for i in range(len(dec) - 1):
        draw_arrow(ax, dec[i], dec[i + 1])

    # Output head below fuse
    head = draw_box(ax, dec[-1].x, -0.4, 'phys_factored head\n→ radiance', color='#ffb6c1', fontsize=8)
    draw_arrow(ax, dec[-1], head)

    aux_q = draw_box(ax, enc[-1].x, 5.4, 'aux_quarter\n@8²', color='#fffacd', fontsize=8)
    draw_arrow(ax, aux_q, enc[-1], rad=0.1)

    dec2 = dec[1]
    aux_h = draw_box(ax, dec2.x + 1.1, 2.7, 'aux_half\n@16²', color='#fffacd', fontsize=8)
    draw_arrow(ax, aux_h, dec2, rad=-0.1)

    # Skip connections
    draw_skip(ax, enc[3], dec2, rad=0.18)   # enc2 -> dec2
    draw_skip(ax, enc[1], dec[3], rad=-0.20)  # enc1 -> dec1

    all_boxes = enc + dec + [head, aux_q, aux_h]
    set_xlim_from_boxes(ax, all_boxes)
    save(fig, 'schematic_expB_mrt_nonorm.png')


# =============================================================================
# 4. Experiment B MLP
# =============================================================================
def draw_expB_mlp():
    fig, ax = plt.subplots(figsize=(11.5, 3.4))
    ax.set_xlim(0, 25)
    ax.set_ylim(-0.5, 4)
    ax.axis('off')

    items = [
        {'text': 'per-pixel input\nNdotV + aux + env\n@32²', 'color': '#ffe4b5'},
        {'text': '1×1 Conv\n+LReLU\nhidden', 'color': '#add8e6'},
        {'text': '1×1 Conv\n+LReLU\nhidden', 'color': '#add8e6'},
        {'text': '1×1 Conv\n+LReLU\nhidden', 'color': '#add8e6'},
        {'text': '1×1 Conv\n+LReLU\nhidden', 'color': '#add8e6'},
        {'text': 'phys_factored head\nshade + res', 'color': '#f08080'},
        {'text': 'albedo⊙softplus(shade)\n+ res\n→ radiance', 'color': '#ffb6c1'},
    ]
    boxes = chain_left(ax, 1.7, 0.5, 0.3, items)

    for i in range(len(boxes) - 1):
        draw_arrow(ax, boxes[i], boxes[i + 1])

    set_xlim_from_boxes(ax, boxes)
    save(fig, 'schematic_expB_mlp.png')


if __name__ == '__main__':
    draw_expA_unet()
    draw_expB_shallow_cnn()
    draw_expB_mrt_nonorm()
    draw_expB_mlp()
    print('All schematics saved to', OUT_DIR)
