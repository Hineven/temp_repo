# 技术方案 — 单物体渲染数据集生成

## 1. 整体架构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         数据集生成 Pipeline                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│  Phase 1: 纹理预生成 (系统 Python)                                            │
│    ├── 对每个变体生成: sss_weight.png, coat_weight.png, coat_tint.png        │
│    └── 输出到 textures/{model}/variant_{v:02d}/                              │
│                                                                              │
│  Phase 2: 批量渲染 (Blender Python)                                           │
│    ├── 加载 scene.blend 模板                                                 │
│    ├── 导入 GLB → 替换默认 Model                                             │
│    ├── 对每个变体:                                                            │
│    │   ├── 修改材质 graph (AOV + 纹理接入)                                    │
│    │   ├── 随机旋转物体                                                       │
│    │   ├── 采样 22 个相机位姿 (rejection, |elevation| ≤ 85°)                │
│    │   ├── 对每个视角:                                                        │
│    │   │   ├── 放置相机, 更新 Compositor 路径                                │
│    │   │   ├── Cycles 渲染 (1024 spp, denoise)                               │
│    │   │   └── File Output 自动保存 7 张 PNG + 写 metadata.json              │
│    │   └── ...                                                               │
│    └── ...                                                                   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Phase 1: 程序化纹理生成

### 2.1 算法设计

使用**多尺度 Value 噪声叠加** + 随机断层，纯 NumPy 实现：

```
for octave in [2, 4, 8, 16, 32]:
    grid = random.rand(size//octave, size//octave)
    upsample(grid) → size×size
    accumulate(grid / octave)

# 可选: 添加 2-5 条水平/垂直断层带
for band in random_bands:
    result[band.y : band.y+h] += random_shift

normalize to [0, 1]
```

### 2.2 纹理规格

| 纹理 | 尺寸 | 通道 | 值域 |
|------|------|------|------|
| `sss_weight.png` | 1024×1024 | 1 (R) | [0, 1] |
| `coat_weight.png` | 1024×1024 | 1 (R) | [0, 1] |
| `coat_tint.png` | 1024×1024 | 3 (RGB) | [0, 1] |

### 2.3 随机种子

每个变体使用独立种子链：
```
base_seed = hash(model_name) + variant_id * 1000
sss_seed  = base_seed + 1
coat_seed = base_seed + 2
tint_seed = base_seed + 3
```

## 3. Phase 2: Blender 渲染 Pipeline

### 3.1 场景初始化

1. 加载 `scene.blend`
2. 删除默认 `Model` 物体
3. 导入 GLB (`bpy.ops.import_scene.gltf`)
4. 将导入的根物体重命名为 `Model`
5. 计算变换后 AABB → 确定相机距离

### 3.2 材质 Graph 重构

对每个 `Model` 的 mesh 材质，执行以下修改：

#### 原始 Graph
```
[Image Texture: base_color] ──────────────────────→ BSDF.Base Color
[Image Texture: MR] → [Separate Color] ──Blue────→ BSDF.Metallic
                                     └─Green────→ BSDF.Subsurface Weight  (断开)
[Image Texture: normal] → [Normal Map] ──────────→ BSDF.Normal
```

#### 修改后 Graph
```
[Image Texture: base_color] ──────────────────────→ BSDF.Base Color
                                                    AOV "albedo" (via pass)

[Image Texture: MR] → [Separate Color] ──Blue────→ BSDF.Metallic
                                     └───────────→ AOV "metallic" (VALUE)

[Value: 0.75] ────────────────────────────────────→ BSDF.Roughness
                                                    AOV "roughness" (VALUE)

[Image Texture: sss_weight.png] ──────────────────→ BSDF.Subsurface Weight
                                                    AOV "sss_weight" (VALUE)

[Image Texture: coat_weight.png] ─────────────────→ BSDF.Coat Weight
                                                    AOV "coat_weight" (VALUE)

[Image Texture: coat_tint.png] ───────────────────→ BSDF.Coat Tint
                                                    AOV "coat_tint" (COLOR)

[Image Texture: normal] → [Normal Map] ───────────→ BSDF.Normal
                                     ├───────────→ [Encode: (N+1)/2]
                                     └──────────────────────────────→ AOV "normal_ws" (COLOR)
```

#### 节点操作清单

| 操作 | 说明 |
|------|------|
| 断开 `Separate Color.Green → BSDF.Subsurface Weight` | 原 scene 连接，不再使用 |
| 添加 `Value` 节点 = 0.75 → `BSDF.Roughness` | 覆盖 GLB 自带 roughness |
| 添加 3 个 `Image Texture` 节点 | 加载生成的 sss/coattint 纹理 |
| 添加 6 个 `AOV Output` 节点 | metallic, roughness, sss_weight, coat_weight, coat_tint, normal_ws |
| 添加 `Vector Math` 编码节点 (normal) | `(N_world + 1) / 2` 映射到 [0,1] 以便 Color AOV 存储 |

### 3.3 View Layer & AOV 配置

```python
vl = bpy.context.view_layer

# 标准 Pass
vl.use_pass_diffuse_color = True   # Albedo
vl.use_pass_normal = True          # Normal (camera space, backup)

# AOV 注册
aovs = [
    ("metallic",   "VALUE"),
    ("roughness",  "VALUE"),
    ("sss_weight", "VALUE"),
    ("coat_weight","VALUE"),
    ("coat_tint",  "COLOR"),
    ("normal_ws",  "COLOR"),  # world-space normal, encoded
]
for name, typ in aovs:
    aov = vl.aovs.add()
    aov.name = name
    aov.type = typ
```

### 3.4 Compositor 配置 (File Output)

```
[Render Layers] ──Image──────────────→ [File Output: slot "rgb"]
              ──DiffCol─────────────→ [File Output: slot "albedo"]
              ──Normal──────────────→ [File Output: slot "normal_cs"]  (backup)
              ──metallic────────────→ [File Output: slot "metallic"]
              ──roughness───────────→ [File Output: slot "roughness"]
              ──sss_weight──────────→ [File Output: slot "sss_weight"]
              ──coat_weight─────────→ [File Output: slot "coat_weight"]
              ──coat_tint───────────→ [File Output: slot "coat_tint"]
              ──normal_ws───────────→ [File Output: slot "normal"]
```

> **File Output** 节点每帧渲染后自动保存各 slot 到 `base_path/` 下。每视角渲染前更新 `base_path` 为当前 view 目录。

### 3.5 相机采样策略

```python
def sample_cameras(n_samples, aabb_center, aabb_size, fov=45°):
    """
    球面均匀采样，rejection sampling 保证 |elevation| ≤ 85°
    """
    distance = max(aabb_size) * 2.5  # 自适应距离因子
    cameras = []
    while len(cameras) < n_samples:
        # 球面均匀采样
        theta = random.uniform(0, 2*pi)      # azimuth
        phi = acos(1 - 2*random.uniform(0,1)) # elevation [0, π]
        elevation = degrees(phi) - 90        # [-90°, 90°]
        
        if abs(elevation) > 85:
            continue  # rejection
        
        # 球坐标 → 笛卡尔
        x = distance * sin(phi) * cos(theta)
        y = distance * sin(phi) * sin(theta)
        z = distance * cos(phi)
        
        cam_pos = aabb_center + Vector((x, y, z))
        cameras.append(cam_pos)
    return cameras
```

### 3.6 渲染设置

| 参数 | 值 |
|------|-----|
| Engine | CYCLES |
| Device | GPU (CUDA/OPTIX if available, fallback CPU) |
| Samples | 1024 |
| Resolution | 1024 × 1024 |
| Denoising | 启用 (OptiX/NLM) |
| Color Management | Standard (Linear, 无 view transform 干扰 G-Buffer) |
| File Format | PNG 16-bit (保证 AOV 精度) |

> ⚠️ **关键**: G-Buffer 输出需使用 **Linear** 颜色管理，避免 sRGB/ACES 变换污染数值。

### 3.7 每视角渲染流程

```python
def render_view(view_dir, camera_pos, look_at):
    # 1. 放置相机
    camera.location = camera_pos
    camera.rotation_euler = look_at(camera_pos, look_at)
    
    # 2. 更新 Compositor File Output 路径
    file_output.base_path = view_dir
    
    # 3. 渲染
    bpy.ops.render.render()
    
    # 4. File Output 自动保存各 pass
    #    文件名格式: rgb0001.png, albedo0001.png, ...
    
    # 5. 重命名去掉帧号后缀
    rename_files(view_dir)
    
    # 6. 写 metadata.json
    write_metadata(view_dir, camera_pos, ...)
```

## 4. Normal 后处理解码

AOV `normal_ws` 中的法线被编码为 `(N_world + 1) / 2`。读取后需解码：

```python
def decode_normal(img_path):
    img = imageio.imread(img_path).astype(np.float32) / 65535.0
    normal = img[:, :, :3] * 2.0 - 1.0
    # 归一化
    norm = np.linalg.norm(normal, axis=2, keepdims=True)
    normal = normal / (norm + 1e-8)
    return normal
```

> 若用户后续不需要 world-space，也可以输出 camera-space Normal（标准 pass），省去编码/解码步骤。**当前方案保留编码的 world-space。**

## 5. 代码文件结构

```
FixedLighting1ItemTemplate/
├── PRD.md                          # 需求文档
├── TECH_SPEC.md                    # 本技术方案
├── render_pipeline.py              # Blender 渲染主脚本
├── texture_gen.py                  # 程序化纹理生成 (系统 Python / Blender Python)
├── run.bat / run.sh                # 一键启动脚本
├── textures/                       # 预生成纹理缓存
│   └── {model_name}/
│       └── variant_{v:02d}/
│           ├── sss_weight.png
│           ├── coat_weight.png
│           └── coat_tint.png
└── dataset/                        # 最终输出
    └── {model_name}/
        └── variant_{v:02d}/
            └── view_{c:02d}/
                ├── rgb.png
                ├── albedo.png
                ├── metallic_roughness.png   # R=Metallic, G=Roughness
                ├── normal.png               # world-space, decoded
                ├── sss_weight.png
                ├── coat_weight.png
                ├── coat_tint.png
                └── metadata.json
```

## 6. 关键风险与应对

| 风险 | 影响 | 应对 |
|------|------|------|
| AOV 无法同时输出 World-Space Normal | Normal 精度/可用性 | 已验证可通过 Vector Math + Color AOV 实现；备选方案用标准 Normal pass + 后处理矩阵变换 |
| Compositor File Output 不支持 16-bit PNG | G-Buffer 精度损失 | 验证后若不支持，改用 EXR 输出再转 PNG |
| GPU 显存不足 (大模型 + 1024²) | 渲染失败 | 自动 fallback 到 CPU；或降低 tile size |
| GLB 材质结构不一致 | AOV 连接失败 | 导入后统一遍历所有材质，检查节点类型并适配 |
| 11 模型 × 10 变体 × 22 视角 = 2420 次渲染 | 耗时极长 | 支持断点续传（已完成的视角跳过）；支持 `--model` 和 `--variant` 参数单任务运行 |

## 7. 待确认问题

本技术方案中以下假设需确认：

1. **Normal 编码方案**：world-space normal 通过 `(N+1)/2` 编码到 Color AOV，读取时解码。是否接受？
2. **粗糙度处理方式**：`metallic_roughness.png` 中 G 通道放固定值 0.75（uniform），是否需要在 metadata 中额外标注？
3. **SSS / Coat 的随机范围**：SSS Weight 和 Coat Weight 纹理的值域是 [0,1] 全范围，还是有偏好的子区间（如 Coat Weight 更常出现在 [0.2, 0.8]）？
4. **断点续传需求**：2420 次渲染预计耗时数小时到数十小时（取决于 GPU），是否需要支持中断后继续？
