# 单物体渲染数据集生成 — 需求文档（PRD）

## 1. 项目概述

基于 Blender + Cycles 渲染引擎，构建一个**单物体 + 环境光**的复杂材质渲染数据集。每个物体产生多个材质变体，每个变体从多个环绕视角渲染，输出 RGB 图像及完整 G-Buffer，共 **2420 个样本**（11 模型 × 10 变体 × 22 视角，见 §3.2）。

## 2. 现有资源

| 资源 | 描述 |
|------|------|
| `scene.blend` | 基准场景，已配置好 Cycles 渲染器、环境贴图 (`tief_etz_4k.exr`, 4096×2048)、默认材质 graph |
| `Items/*.glb` | 11 个 GLB 模型（含 UV、自带贴图：base color / metallic-roughness / normal） |
| Blender 4.2.3 LTS | 渲染引擎 |

### 2.1 scene.blend 材质结构
- **Principled BSDF** 为核心节点
- 已有贴图连接：
  - `Image Texture` → `Base Color`
  - `Image Texture.001` (metallic+roughness) → `Separate Color` → `Metallic` (B channel)
  - `Image Texture.002` (normal) → `Normal Map` → `Normal`
- 当前 Roughness 固定为 0.75
- 当前 `Subsurface Weight` 已接入 `Separate Color` 的 Green 通道（原 scene 设置）

## 3. 数据生成规范

### 3.1 变体生成（每 GLB × 10 个变体）

对每个变体，**保留原 GLB 自带材质属性**（base color、metallic、normal 贴图等），并覆盖以下参数：

| 参数 | 生成规则 |
|------|----------|
| **Subsurface Weight** | 生成 **1-chan 纹理** [0, 1]（相对正常，频率有变化，无高频噪音，可含少量断层） |
| **Coat Weight** | 生成 **1-chan 纹理** [0, 1]（同上） |
| **Coat Tint** | 生成 **RGB 纹理**（同上） |
| **Roughness** | 固定为 **0.75**（覆盖 GLB 自带值） |
| **模型 Rotation** | 随机 Euler 旋转 |

> **材质贴图生成要求**：使用模型自带 UV，不需有意义的语义内容，保证视觉上"相对正常"即可（频率变化、无高频噪点、允许少量断层）。

### 3.2 相机设置（每变体 × 22 个视角）

- 相机**环绕**物体，始终**看向物体 AABB 中心**
- 相机位置在球面上采样，**elevation 限制在 [-85°, 85°]** 范围内（避免退化视角）
- 距离基于**变换后 AABB** 自适应（如 `distance = max(AABB_dim) * factor`）
- 使用 Cycles **Path Tracing** 渲染
- **1024 spp**，渲染后**降噪**
- **分辨率**：1024×1024

### 3.3 输出内容（每视角）

#### 渲染输出
- `rgb.png` — 最终渲染图像 (1024×1024)

#### G-Buffer（per-pixel）
- `albedo.png` — Base Color（反照率）
- `metallic_roughness.png` — Metallic + Roughness
- `normal.png` — 法线（世界空间或切线空间，需约定）
- `sss_weight.png` — Subsurface Scattering Weight
- `coat_weight.png` — Coat Weight
- `coat_tint.png` — Coat Tint (RGB)

#### Metadata（JSON）
- **Camera metadata**：位置、旋转、FOV、指向目标等
- **Model transform metadata**：位置、旋转、缩放、AABB 等
- **Material metadata**：sssw, coatw 等随机参数的具体数值、随机种子

## 4. 数据规模

| 项目 | 数量 |
|------|------|
| GLB 模型 | 11 个（无重复） |
| 每模型变体数 | 10 |
| 每变体视角数 | 22（注：原需求 20，考虑 rejection sampling 后补到 22 以保底 20 张有效） |
| **总视角数** | **2420** |
| 每视角输出文件数 | 1 RGB + 6 G-Buffer + 1 Metadata = 8 个 |
| **总文件数** | **~19,360** |

## 5. 技术路线

### 5.1 G-Buffer 提取 — 方案 B（Blender AOV）

利用 Blender View Layer 的 **AOV（Arbitrary Output Variables）** 机制：

| G-Buffer 项 | 获取方式 |
|-------------|----------|
| Albedo | `use_pass_diffuse_color` 标准 Pass |
| Normal | `use_pass_normal` 标准 Pass |
| Metallic | Value AOV（从 Separate Color → Metallic 链路提取，保留 GLB 自带） |
| Roughness | Value AOV（固定值 0.75） |
| SSS Weight | Value AOV（连到生成的 1-chan 纹理） |
| Coat Weight | Value AOV（连到生成的 1-chan 纹理） |
| Coat Tint | Color AOV（连到生成的 RGB 纹理） |

所有 AOV 在一次渲染中同时输出，通过 **Compositor** 的 `File Output` 节点分别保存为 PNG。

### 5.2 Pipeline 概览

```
foreach glb in Items/*.glb:
    load scene.blend template
    clear default "Model" object
    import glb → rename to "Model"
    compute AABB, center

    foreach variant in 0..9:
        # 1. Generate material maps
        generate coat_tint texture (procedural noise on UV)
        generate random: sssw, coatw, rotation

        # 2. Setup material graph
        replace Principled BSDF params
        add AOV Output nodes for each G-Buffer channel
        set roughness = 0.75

        # 3. Camera sampling
        sample 22 camera poses (spherical, elevation ∈ [-85°, 85°])

        foreach view in 0..21:
            # 4. Render
            set camera
            render (1024 spp, denoise)
            save RGB + 6 G-Buffer PNGs
            save metadata.json
```

## 6. 输出目录结构

```
dataset/
├── crab/
│   ├── variant_00/
│   │   ├── view_00/
│   │   │   ├── rgb.png
│   │   │   ├── albedo.png
│   │   │   ├── metallic_roughness.png
│   │   │   ├── normal.png
│   │   │   ├── sss_weight.png
│   │   │   ├── coat_weight.png
│   │   │   ├── coat_tint.png
│   │   │   └── metadata.json
│   │   ├── view_01/
│   │   │   └── ...
│   │   └── ...
│   ├── variant_01/
│   └── ...
├── tree/
└── ...
```

## 7. 待确认问题

以下问题待用户确认后定稿：

1. **Elevation 限制的具体语义**：
   - 方案 A：采样时拒绝 |elevation| > 85° 的视角（rejection sampling，保底 20 张）
   - 方案 B：将 elevation 硬性 clamp 到 [-85°, 85°]（可能聚集在边界）
   - 推荐 **方案 A**，可预采样 22 个再过滤，保证每张都是均匀分布

2. **Metadata JSON 字段**：确认以下字段是否足够：
   ```json
   {
     "model_name": "crab",
     "variant_id": 0,
     "view_id": 0,
     "camera": {
       "location": [x, y, z],
       "rotation_euler": [rx, ry, rz],
       "fov": 45.0,
       "look_at": [cx, cy, cz]
     },
     "model_transform": {
       "location": [0, 0, 0],
       "rotation_euler": [rx, ry, rz],
       "scale": [1, 1, 1],
       "aabb_min": [x, y, z],
       "aabb_max": [x, y, z]
     },
     "material": {
       "sss_weight": 0.42,
       "coat_weight": 0.73,
       "roughness": 0.75,
       "coat_tint_seed": 12345,
       "sss_weight_seed": 12346,
       "coat_weight_seed": 12347,
       "random_seed": 67890
     }
   }
   ```

3. **Normal 空间**：G-Buffer 中的 Normal 输出为**世界空间**还是**切线空间**？（推荐世界空间，下游处理更通用）

4. **Metallic+Roughness 贴图格式**：`metallic_roughness.png` 如何编码？
   - 方案 A：R=Metallic, G=Roughness, B=0（类似 glTF 的 metallic-roughness 贴图布局）
   - 方案 B：两个独立灰度图 `metallic.png` + `roughness.png`
   - 推荐 **方案 A**（省文件数，且与 glTF 惯例一致）
