#!/usr/bin/env python3
"""
Full-frame quantitative eval for HW_DATASET neural_tex runs.

Loads a checkpoint, rasterizes each val view's UV + geometry on the fly (same path as the
dataloader), runs tiled inference, stitches back to full-res, and reports masked LDR metrics:
    L1 (per-channel mean), PSNR, SSIM, LPIPS.

Outputs:
    <run>/eval_metrics.json      aggregate + per-view numbers
    <run>/vis_eval_metrics/      GT|Pred|Error panels for sampled views
"""
import argparse
import json
import math
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import nvdiffrast.torch as dr
from PIL import Image

import rasterize_hw as RHW
from train_lighting.dataset import _tile_chw, _tile_chw_halo, TILE_SIZE
from train_lighting.single_view_eval import experiment_from_checkpoint


def _view_dirs_from_c2w(cam2world, fov_deg, h, w):
    col0, col1, col2 = cam2world[:3, 0], cam2world[:3, 1], cam2world[:3, 2]
    tan = math.tan(math.radians(fov_deg) / 2.0)
    u = np.arange(w, dtype=np.float32) + 0.5
    v = np.arange(h, dtype=np.float32) + 0.5
    x = (2.0 * u / w - 1.0) * tan
    y = (1.0 - 2.0 * v / h) * tan
    xs, ys = np.meshgrid(x, y, indexing="xy")
    ray = (xs[..., None] * col0 + ys[..., None] * col1 - col2).astype(np.float32)
    ray /= (np.linalg.norm(ray, axis=2, keepdims=True) + 1e-8)
    return ray


def _load_full_view(hw_dir, view_idx, mesh, ctx, fov_deg, feature_spec, res=1024,
                    convention="opengl"):
    hw_dir = Path(hw_dir)
    rgb = np.array(Image.open(hw_dir / "images" / f"{view_idx:04d}_0001.png").convert("RGB"), dtype=np.float32) / 255.0
    doc = json.loads((hw_dir / "transforms_all.json").read_text())
    cam2world = np.array(doc["frames"][view_idx]["transform_matrix"], dtype=np.float32)
    verts, faces, uvs, normals = mesh
    uv, normal, mask = RHW.rasterize_view(ctx, verts, faces, uvs, normals, cam2world,
                                          fov_deg, res, 1.0, 0.05, 20.0,
                                          convention=convention)
    uv = uv.astype(np.float32)
    normal = normal.astype(np.float32)
    mask = mask.astype(np.float32)
    out = {"rgb_gt": rgb, "uv": uv, "mask": mask}
    need = feature_spec.compute_ndotv or feature_spec.compute_reflection or feature_spec.compute_view_dir
    if need:
        h, w = mask.shape[:2]
        view_dir = _view_dirs_from_c2w(cam2world, fov_deg, h, w)
        ndotv = np.clip(np.sum(normal * view_dir, axis=2, keepdims=True), 0.0, 1.0)
        if feature_spec.compute_ndotv or feature_spec.compute_reflection:
            out["normal"] = normal
        if feature_spec.compute_ndotv:
            out["ndotv"] = ndotv
        if feature_spec.compute_reflection:
            refl = 2.0 * ndotv * normal - view_dir
            refl /= (np.linalg.norm(refl, axis=2, keepdims=True) + 1e-8)
            out["reflection_dir"] = refl
        if feature_spec.compute_view_dir:
            out["view_dir"] = view_dir
    return out


def _tile_for_eval(raw, ts, halo):
    tiled = {}
    for name, arr in raw.items():
        arr = arr[..., None] if arr.ndim == 2 else arr
        if halo > 0 and name not in ("rgb_gt", "mask"):
            tiled[name] = _tile_chw_halo(arr, ts, halo)
        else:
            tiled[name] = _tile_chw(arr, ts, ts)
    return tiled


def _masked_mse(pred, gt, mask):
    """pred, gt: [3,H,W]; mask: [1,H,W] bool/float."""
    return ((pred - gt) ** 2 * mask).sum() / mask.sum().item()


def _masked_psnr(pred, gt, mask):
    mse = _masked_mse(pred, gt, mask)
    return float(-10.0 * np.log10(mse + 1e-10))


def _masked_ssim(pred, gt, mask):
    """Channel-average SSIM map, masked mean. pred/gt in [0,1]."""
    from skimage.metrics import structural_similarity
    mask_np = mask[0].astype(bool)
    if not mask_np.any():
        return 0.0
    ssim_sum = 0.0
    for c in range(3):
        _, ssim_map = structural_similarity(
            pred[c], gt[c], data_range=1.0, full=True, gaussian_weights=True
        )
        ssim_sum += ssim_map[mask_np].mean()
    return float(ssim_sum / 3.0)


def _masked_lpips(pred, gt, mask, lpips_fn, device):
    """Spatial LPIPS map upsampled to mask resolution, then masked mean. pred/gt numpy [3,H,W] in [0,1]."""
    mask_np = mask[0].astype(bool)
    if not mask_np.any():
        return 1.0
    p_t = torch.from_numpy(pred).unsqueeze(0).float().to(device) * 2.0 - 1.0
    g_t = torch.from_numpy(gt).unsqueeze(0).float().to(device) * 2.0 - 1.0
    h, w = mask_np.shape
    with torch.no_grad():
        dist_map = lpips_fn(p_t, g_t)  # [1,1,H',W']
        dist_up = F.interpolate(dist_map, size=(h, w), mode="bilinear", align_corners=False)
    dist = dist_up[0, 0].cpu().numpy()
    return float(dist[mask_np].mean())


@torch.no_grad()
def eval_one_view(experiment, modules, device, hw_dir, view_idx, mesh, ctx, fov_deg,
                  lpips_fn, halo, ts, out_vis_dir=None, convention="opengl"):
    raw = _load_full_view(hw_dir, view_idx, mesh, ctx, fov_deg, experiment.feature_spec,
                          convention=convention)
    rgb_gt = raw["rgb_gt"].transpose(2, 0, 1).astype(np.float32)  # [3,H,W]
    mask = raw["mask"][None, ...].astype(np.float32)              # [1,H,W]
    h, w = mask.shape[-2], mask.shape[-1]
    ny, nx = h // ts, w // ts

    tiled = _tile_for_eval(raw, ts, halo)
    mask_t = tiled["mask"].reshape(ny, nx, *tiled["mask"].shape[2:])
    pred_canvas = np.zeros((3, h, w), dtype=np.float32)

    for ty in range(ny):
        for tx in range(nx):
            if mask_t[ty, tx, 0].sum() == 0:
                continue
            batch = {}
            for k, arr in tiled.items():
                tile = arr.reshape(ny, nx, *arr.shape[2:])[ty, tx]
                batch[k] = torch.from_numpy(tile).unsqueeze(0).float().to(device)
            pred = experiment.forward(batch, modules, device)[0].cpu().numpy()
            pred_canvas[:, ty * ts:(ty + 1) * ts, tx * ts:(tx + 1) * ts] = pred

    msk_bool = mask[0] > 0.5
    l1 = float(np.abs(pred_canvas - rgb_gt)[:, msk_bool].mean())
    psnr = _masked_psnr(pred_canvas, rgb_gt, mask)
    ssim = _masked_ssim(pred_canvas, rgb_gt, mask)
    lpips = _masked_lpips(pred_canvas, rgb_gt, mask, lpips_fn, device)

    if out_vis_dir is not None:
        out_vis_dir.mkdir(parents=True, exist_ok=True)
        err = np.abs(pred_canvas - rgb_gt).sum(0)
        err[~msk_bool] = 0
        panel = np.concatenate([
            rgb_gt.transpose(1, 2, 0),
            pred_canvas.transpose(1, 2, 0).clip(0, 1),
            np.repeat((err / max(err.max(), 1e-6))[:, :, None], 3, axis=2),
        ], axis=1)
        Image.fromarray((panel * 255).astype(np.uint8)).save(
            out_vis_dir / f"view_{view_idx:04d}_psnr={psnr:.2f}_ssim={ssim:.3f}_lpips={lpips:.3f}.png"
        )

    return {"view_idx": int(view_idx), "l1": l1, "psnr": psnr, "ssim": ssim, "lpips": lpips}


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", required=True)
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--num_views", type=int, default=None,
                    help="number of val views to evaluate; default = all")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--no_vis", action="store_true", help="skip saving GT|Pred|Error panels")
    ap.add_argument("--cam_convention", default="opengl",
                    choices=list(RHW.CAM_CONVENTIONS),
                    help="how to interpret transform_matrix")
    args = ap.parse_args()

    run_dir = Path(args.run_dir)
    ckpt = args.checkpoint or str(run_dir / "checkpoints" / "best.pt")
    experiment, modules, device = experiment_from_checkpoint(ckpt)
    for m in modules.values():
        m.eval()

    cfg = json.loads((run_dir / "config.json").read_text())
    hw_dir = cfg["args"]["dataset_dir"]
    halo = cfg["args"].get("halo", 0)
    fov_deg = math.degrees(json.loads((Path(hw_dir) / "transforms_all.json").read_text())["camera_angle_x"])

    mesh = RHW.load_mesh(Path(hw_dir) / "mesh.ply")
    ctx = dr.RasterizeCudaContext(device=torch.device("cuda"))

    val_doc = json.loads((Path(hw_dir) / "transforms_val.json").read_text())
    val_idxs = [int(f["file_path"].split("/")[-1].split("_")[0]) for f in val_doc["frames"]]
    rng = random.Random(args.seed)
    rng.shuffle(val_idxs)
    chosen = val_idxs if args.num_views is None else val_idxs[:args.num_views]

    import lpips
    lpips_fn = lpips.LPIPS(net="alex").to(device)
    lpips_fn.eval()

    ts = TILE_SIZE
    out_vis = None if args.no_vis else run_dir / "vis_eval_metrics"

    results = []
    print(f"Evaluating {len(chosen)} val views from {hw_dir} ...")
    for i, vi in enumerate(chosen):
        r = eval_one_view(experiment, modules, device, hw_dir, vi, mesh, ctx, fov_deg,
                          lpips_fn, halo, ts, out_vis_dir=out_vis,
                          convention=args.cam_convention)
        results.append(r)
        print(f"  [{i+1}/{len(chosen)}] view {vi:04d}: L1={r['l1']:.5f}  "
              f"PSNR={r['psnr']:.3f}  SSIM={r['ssim']:.4f}  LPIPS={r['lpips']:.4f}")

    agg = {
        "n_views": len(results),
        "l1_mean": float(np.mean([r["l1"] for r in results])),
        "l1_std": float(np.std([r["l1"] for r in results])),
        "psnr_mean": float(np.mean([r["psnr"] for r in results])),
        "psnr_std": float(np.std([r["psnr"] for r in results])),
        "ssim_mean": float(np.mean([r["ssim"] for r in results])),
        "ssim_std": float(np.std([r["ssim"] for r in results])),
        "lpips_mean": float(np.mean([r["lpips"] for r in results])),
        "lpips_std": float(np.std([r["lpips"] for r in results])),
        "per_view": results,
    }

    out_json = run_dir / "eval_metrics.json"
    out_json.write_text(json.dumps(agg, indent=2), encoding="utf-8")
    print(f"\nAggregate (masked LDR):")
    print(f"  L1   = {agg['l1_mean']:.5f} ± {agg['l1_std']:.5f}")
    print(f"  PSNR = {agg['psnr_mean']:.3f} ± {agg['psnr_std']:.3f}")
    print(f"  SSIM = {agg['ssim_mean']:.4f} ± {agg['ssim_std']:.4f}")
    print(f"  LPIPS= {agg['lpips_mean']:.4f} ± {agg['lpips_std']:.4f}")
    print(f"Saved to {out_json}")


if __name__ == "__main__":
    main()
