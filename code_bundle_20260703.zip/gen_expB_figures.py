"""Generate experiment B figures for shading_VRS.tex."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

OUT = Path(r'd:\TestScene\FixedLighting1ItemTemplate\figures\hcx')
OUT.mkdir(parents=True, exist_ok=True)

# Try a Chinese font, fall back to sans-serif
try:
    import matplotlib.font_manager as fm
    fonts = [f.name for f in fm.fontManager.ttflist]
    for cn in ['Microsoft YaHei', 'SimHei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC']:
        if cn in fonts:
            plt.rcParams['font.family'] = cn
            plt.rcParams['axes.unicode_minus'] = False
            break
except Exception:
    pass


def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / name, dpi=300, bbox_inches='tight')
    plt.close(fig)


# ------------------------------------------------------------------
# Figure 1: generalization gap + data scaling
# ------------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(10, 4))

# Left: data scaling on frozen single-object
views = np.array([300, 600, 1200, 1800])
val_l1 = np.array([0.1465, 0.1064, 0.0805, 0.068])
axes[0].plot(views, val_l1, 'o-', color='#2E86AB', linewidth=2, markersize=7, label='frozen 71.glb (no-aug)')
axes[0].axhline(0.054, color='#A23B72', linestyle='--', linewidth=1.5, label='converged 100ep')
axes[0].set_xlabel('Training views')
axes[0].set_ylabel('val L1')
axes[0].set_title('Single-object: more views → lower error')
axes[0].legend()
axes[0].grid(alpha=0.3)

# Right: generalization gap
methods = ['multi-scene\nch16', 'multi-scene\nch32', 'single-scene\nrichfeat', 'single-scene\nconverged']
values = [0.0999, 0.0932, 0.0480, 0.054]
colors = ['#F18F01', '#F18F01', '#2E86AB', '#A23B72']
bars = axes[1].bar(methods, values, color=colors, edgecolor='black', alpha=0.85)
axes[1].set_ylabel('val L1')
axes[1].set_title('Generalization gap')
axes[1].grid(axis='y', alpha=0.3)
for bar, v in zip(bars, values):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.002,
                 f'{v:.3f}', ha='center', va='bottom', fontsize=9)

save(fig, 'expB_generalization.png')


# ------------------------------------------------------------------
# Figure 2: tile seam ratio
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7, 4))
methods = ['richfeat', 'tile PE', 'tile dist', 'attention', 'attention\n+halo=4']
ratios = [1.29, 1.26, 1.29, 1.35, 1.17]
colors = ['#2E86AB', '#F18F01', '#F18F01', '#C73E1D', '#3B1F2B']
bars = ax.bar(methods, ratios, color=colors, edgecolor='black', alpha=0.85)
ax.axhline(1.0, color='gray', linestyle='--', linewidth=1)
ax.set_ylabel('Boundary / interior error ratio')
ax.set_title('Only overlap (halo) reduces the tile seam ratio')
ax.set_ylim(0.9, 1.5)
ax.grid(axis='y', alpha=0.3)
for bar, r in zip(bars, ratios):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.015,
            f'{r:.2f}×', ha='center', va='bottom', fontsize=10, fontweight='bold')

save(fig, 'expB_halo.png')


# ------------------------------------------------------------------
# Figure 3: baking progression
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 4.5))
methods = [
    'U-Net (PBR)',
    'U-Net（烘焙）',
    'U-Net（烘焙 + env maps）',
    'U-Net（烘焙 + 多分辨率）',
    'U-Net（烘焙 + Transformer）',
    'U-Net（烘焙 + Transformer + halo）',
    'MLP（烘焙）',
]
# Raw 3-channel sums from training logs; display as per-channel mean (/3)
values_raw = [0.0480, 0.0395, 0.0340, 0.0317, 0.0309, 0.0280, 0.0262]
values = [v / 3.0 for v in values_raw]
colors = plt.cm.Greens(np.linspace(0.25, 0.9, len(values)))[::-1]
colors[0] = (0.7, 0.7, 0.7, 1.0)  # gray for PBR baseline
bars = ax.barh(methods, values, color=colors, edgecolor='black')
ax.set_xlabel('val L1 (per-channel mean)')
ax.set_title('Baking neural texture progression on fixed object')
ax.grid(axis='x', alpha=0.3)
for bar, v in zip(bars, values):
    ax.text(v + 0.0003, bar.get_y() + bar.get_height()/2,
            f'{v:.4f}', va='center', fontsize=9)
ax.invert_yaxis()

save(fig, 'expB_baking.png')


# ------------------------------------------------------------------
# Figure 4: architecture budget comparison
# ------------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), sharey=False)

datasets_10g = ['regular 71', 'glossy 71', 'SSS12']
cnn_10g = [0.0265, 0.0896, 0.0912]
mlp_10g = [0.0295, 0.1007, 0.0927]
unet_10g = [np.nan, 0.0962, 0.0965]  # mrt_nonorm

x = np.arange(len(datasets_10g))
width = 0.25
axes[0].bar(x - width, cnn_10g, width, label='CNN', color='#2E86AB', edgecolor='black')
axes[0].bar(x, mlp_10g, width, label='MLP-1L', color='#F18F01', edgecolor='black')
axes[0].bar(x + width, unet_10g, width, label='U-Net', color='#C73E1D', edgecolor='black')
axes[0].set_xticks(x)
axes[0].set_xticklabels(datasets_10g)
axes[0].set_ylabel('val L1')
axes[0].set_title('~10 GFLOPs budget')
axes[0].legend()
axes[0].grid(axis='y', alpha=0.3)

datasets_27g = ['glossy 71', 'SSS12']
cnn_27g = [0.0843, 0.0870]
mlp_27g = [0.0811, 0.0860]
trans_27g = [0.0814, np.nan]
unet_27g = [0.0891, 0.0955]

x = np.arange(len(datasets_27g))
width = 0.2
axes[1].bar(x - 1.5*width, cnn_27g, width, label='CNN', color='#2E86AB', edgecolor='black')
axes[1].bar(x - 0.5*width, mlp_27g, width, label='MLP-2L', color='#F18F01', edgecolor='black')
axes[1].bar(x + 0.5*width, trans_27g, width, label='Transformer', color='#3B1F2B', edgecolor='black')
axes[1].bar(x + 1.5*width, unet_27g, width, label='deep U-Net', color='#C73E1D', edgecolor='black')
axes[1].set_xticks(x)
axes[1].set_xticklabels(datasets_27g)
axes[1].set_ylabel('val L1')
axes[1].set_title('~27 GFLOPs budget')
axes[1].legend()
axes[1].grid(axis='y', alpha=0.3)

save(fig, 'expB_arch_budget.png')


# ------------------------------------------------------------------
# Figure 5: Pareto front
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(10, 7))
methods = [
    ('U-Net (PBR)', 222, 0.0480, 230),
    ('U-Net（无烘焙表）', 26.6, 0.1142, 27),
    ('U-Net（仅方向表）', 12.1, 0.0707, 12),
    ('U-Net（烘焙）', 58, 0.0340, 60),
    ('U-Net（烘焙 + MR）', 33.7, 0.0317, 35),
    ('U-Net（烘焙 + T）', 16.0, 0.0309, 29),
    ('U-Net（烘焙 + T + halo）', 20.7, 0.0280, 29),
    ('MLP（烘焙）', 44.3, 0.0262, 10),
    ('Shallow CNN（烘焙 + halo=3）', 10.6, 0.02546, 4),
]
# Convert raw 3-channel val_l1 to per-channel mean
methods = [(n, g, v / 3.0, p) for n, g, v, p in methods]
names, gflops, val_l1, net_params = zip(*methods)
# marker size by runtime net params (log scale), keep small-param points visible
sizes = np.array(net_params, dtype=float)
sizes = 80 + 450 * (np.log10(sizes) - 0.6) / (2.4 - 0.6)
# color: PBR baseline purple; no-bakeable-view-table orange; CNN green; rest blue
colors = []
for n in names:
    if 'PBR' in n:
        colors.append('#A23B72')
    elif '无烘焙表' in n:
        colors.append('#F18F01')
    elif 'CNN' in n:
        colors.append('#2E8B57')
    else:
        colors.append('#2E86AB')
scatter = ax.scatter(gflops, val_l1, s=sizes, c=colors, edgecolors='black', alpha=0.85, zorder=3)

# Simple offset labels for uncrowded points
offset_labels = {
    0: (12, 4),   # U-Net (PBR)
    1: (10, 8),   # U-Net（无烘焙表）
    2: (10, 8),   # U-Net（方向表）
    3: (12, 22),  # U-Net（烘焙 + env） -> up/right
}
for i, txt in enumerate(names):
    if i in offset_labels:
        ax.annotate(txt, (gflops[i], val_l1[i]), textcoords='offset points',
                    xytext=offset_labels[i], fontsize=9,
                    ha='left', va='bottom',
                    bbox=dict(boxstyle='round,pad=0.25', facecolor='white',
                              edgecolor='none', alpha=0.85),
                    zorder=4)

# Arrow labels for the crowded bottom-left cluster
arrow_style = dict(arrowstyle='->', color='gray', lw=0.8)
bbox_style = dict(boxstyle='round,pad=0.25', facecolor='white',
                  edgecolor='none', alpha=0.85)
ax.annotate(names[8], (gflops[8], val_l1[8]),
            xytext=(8.5, 0.0115), textcoords='data',
            fontsize=9, ha='center', va='bottom',
            arrowprops=arrow_style, bbox=bbox_style, zorder=4)
ax.annotate(names[5], (gflops[5], val_l1[5]),
            xytext=(13.0, 0.0135), textcoords='data',
            fontsize=9, ha='center', va='bottom',
            arrowprops=arrow_style, bbox=bbox_style, zorder=4)
ax.annotate(names[6], (gflops[6], val_l1[6]),
            xytext=(28.0, 0.0068), textcoords='data',
            fontsize=9, ha='center', va='top',
            arrowprops=arrow_style, bbox=bbox_style, zorder=4)
ax.annotate(names[4], (gflops[4], val_l1[4]),
            xytext=(55.0, 0.0088), textcoords='data',
            fontsize=9, ha='center', va='bottom',
            arrowprops=arrow_style, bbox=bbox_style, zorder=4)
ax.annotate(names[7], (gflops[7], val_l1[7]),
            xytext=(110.0, 0.0095), textcoords='data',
            fontsize=9, ha='center', va='bottom',
            arrowprops=arrow_style, bbox=bbox_style, zorder=4)

ax.set_xlabel('GFLOPs @ 1080p', fontsize=11)
ax.set_ylabel('val L1 (per-channel mean)', fontsize=11)
ax.set_title('Pareto front: baking route dominates PBR-param route', fontsize=13)
ax.set_xscale('log')
ax.set_xlim(6, 320)
ax.grid(True, alpha=0.2, which='both', zorder=0)

save(fig, 'expB_pareto.png')

print('Generated figures:', list(OUT.glob('expB_*.png')))
