# HW 数据集训练与评估说明

本目录支持在 **HW_DATASET** 格式（`images/` + `mesh.ply` + `transforms_*.json`）下进行神经着色网络的训练与评估。
HW 格式没有预计算的 G-Buffer/Raster，所有输入通道（UV、world-space normal、ndotv、reflection_dir 等）在数据加载时通过 **nvdiffrast** 从 PLY mesh 和相机参数实时栅格化得到。

---

## 1. 数据集目录结构

一个合法的 HW 数据集目录应包含：

```
dataset_hw_xxx/
├── mesh.ply                 # 待渲染的 mesh（顶点、面、UV）
├── transforms_all.json      # 所有视角的相机参数
├── transforms_train.json    # 训练视角列表
├── transforms_val.json      # 验证视角列表
└── images/
    ├── 0000_0001.png        # 每个视角的 LDR GT 图像（与 transforms_all.json 中的帧顺序对应）
    ├── 0001_0001.png
    └── ...
```

`transforms_*.json` 格式与 NeRF/Instant-NGP 类似：

```json
{
  "camera_angle_x": 0.7853981633974483,
  "frames": [
    {
      "file_path": "images/0000_0001",
      "transform_matrix": [
        [...],
        [...],
        [...],
        [0, 0, 0, 1]
      ]
    }
  ]
}
```

其中 `transform_matrix` 是 **camera-to-world** 4×4 矩阵。

---

## 2. 相机约定（重要）

不同工具生成的 `transform_matrix` 可能使用不同的相机坐标系约定。代码内部统一使用 **OpenGL 相机坐标系**：

- 右手系
- +X = 右
- +Y = 上
- **-Z = 相机前方**

如果你的数据集来自其他工具，请通过 `--cam_convention` 指定正确的约定。当前支持：

| 约定 | 坐标系 | 说明 |
|------|--------|------|
| `opengl` / `blender` | 右手系，-Z forward，+Y up | **默认**。我们的 HW 数据集使用此约定。 |
| `colmap` | 右手系，+Z forward，Y down | COLMAP 图像/相机坐标系。 |
| `unity` / `directx` | 左手系，+Z forward，+Y up | Unity / DirectX 常用约定。 |

转换在 `rasterize_hw.py` 的 `cam2world_from_raw()` 中完成，本质是对 `transform_matrix` 右乘一个坐标系修正矩阵。

> **如何判断约定是否正确？** 训练前先用 `rasterize_hw.py --validate <view_idx>` 检查 mask IoU 是否 > 0.99。如果不对，换 `--cam_convention` 再试。

---

## 3. 训练

### 3.1 入口

```bash
python -m train_lighting.run \
    --experiment <experiment_name> \
    --dataset_dir <path_to_hw_dataset> \
    --tag <run_tag> \
    [其他超参]
```

`run.py` 会自动检测数据集格式：若目录下存在 `mesh.ply` + `transforms_all.json`，则走 HW 数据加载器；否则走 legacy 数据加载器。

### 3.2 常用实验

| 实验 | 说明 |
|------|------|
| `neural_tex` | 仅烘焙 UV neural texture，无 env map |
| `neural_tex_env` | UV neural texture + 可烘焙方向 env map |
| `neural_tex_mr` | multi-resolution texture injection |
| `neural_tex_mrt` | MR + lightweight transformer bottleneck |
| `neural_tex_mrt_nonorm` | MRT 变体，常用于 glossy/SSS 材质 |
| `neural_tex_mlp` | 纯 per-pixel MLP baseline |
| `neural_tex_shallow_cnn` | 浅层 2-layer UNet-like CNN |

### 3.3 示例命令

```bash
# U-Net mrt-nonorm 烘焙，HW 数据集
python -m train_lighting.run \
    --experiment neural_tex_mrt_nonorm \
    --dataset_dir ./dataset_hw_71_glossy \
    --tag glossy_10g \
    --base_ch 16 --bottleneck_blocks 6 --num_transformer_blocks 1 \
    --env_dim 8 --neural_tex_dim 22 --use_raw_geom --phys_factored \
    --epochs 100 --batch_size 1024 --lr_network 3e-4 --lr_env_map 1e-3

# MLP 烘焙
python -m train_lighting.run \
    --experiment neural_tex_mlp \
    --dataset_dir ./dataset_hw_71_glossy \
    --tag mlp_glossy \
    --hidden_dim 64 --num_hidden_layers 3 \
    --epochs 100 --batch_size 1024

# Shallow CNN 烘焙，带 halo=3（训练时也带 halo）
python -m train_lighting.run \
    --experiment neural_tex_shallow_cnn \
    --dataset_dir ./dataset_hw_71_glossy \
    --tag cnn_halo3_glossy \
    --base_ch 15 --halo 3 \
    --epochs 100 --batch_size 1024
```

### 3.4 关键 CLI 参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--dataset_dir` | `dataset` | 数据集目录 |
| `--cam_convention` | `opengl` | 相机约定，见第 2 节 |
| `--halo` | 0 | tile 边缘重叠像素（建议 0/3） |
| `--batch_size` | 1024 | tile batch size |
| `--data_device` | `cpu` | 数据驻留设备（`cpu` 或 `cuda`） |
| `--neural_tex_dim` | 16 | neural texture 通道数 |
| `--neural_tex_res` | 256 | neural texture 分辨率 |
| `--env_dim` | 8 | env map 特征维度 |
| `--base_ch` | 16 | 网络基础通道数 |
| `--bottleneck_blocks` | 3 | U-Net bottleneck 块数 |
| `--use_raw_geom` | - | 额外输入 raw normal + reflection_dir |
| `--phys_factored` | - | 使用物理分解的输出头 |

---

## 4. 评估

### 4.1 全幅定量评估（PSNR / SSIM / LPIPS）

```bash
python hw_eval_metrics.py \
    --run_dir experiments/neural_tex_shallow_cnn/<timestamp>_tag \
    [--checkpoint checkpoints/best.pt] \
    [--num_views 8] \
    [--cam_convention opengl]
```

输出：
- 终端打印每个 view 的 `L1 / PSNR / SSIM / LPIPS`
- `<run_dir>/eval_metrics.json`：均值、标准差、逐 view 结果
- `<run_dir>/vis_eval_metrics/`：GT | Pred | Error 对比图

### 4.2 全幅可视化评估

```bash
python hw_eval.py \
    --run_dir experiments/neural_tex_shallow_cnn/<timestamp>_tag \
    --num_views 6 \
    --cam_convention opengl
```

输出 `<run_dir>/vis_eval/hw/view_xxxx.png`。

### 4.3 Shallow CNN halo 对比评估

```bash
python eval_shallowcnn_halo.py \
    --checkpoint experiments/neural_tex_shallow_cnn/<timestamp>_tag/checkpoints/best.pt \
    --dataset_dir ./dataset_hw_71_glossy \
    --cam_convention opengl \
    [--max_full_views 20]
```

输出 `tiled_halo0 / tiled_halo3 / full_image` 的 val_l1（raw 3-channel sum 与 per-channel mean）。

---

## 5. 快速验证（Smoke Test）

在不启动完整训练的情况下，验证某个实验 + 数据集 + 相机约定能否正常跑通前反向：

```bash
python smoke_hw_train.py \
    --experiment neural_tex_mlp \
    --dataset_dir ./dataset_hw_71_glossy \
    --cam_convention opengl
```

若输出 `Smoke test PASSED`，说明数据加载、栅格化、模型前向/反向均正常。

---

## 6. 迁移到新机器 / 新数据集 checklist

1. **确认 nvdiffrast 可用**：`python -c "import nvdiffrast.torch as dr; print('ok')"`
2. **确认 `lpips` 已安装**：用于 `hw_eval_metrics.py`
3. **确认数据集结构**：`mesh.ply` + `transforms_all.json` + `transforms_train.json` + `transforms_val.json` + `images/`
4. **确认相机约定**：先用 `rasterize_hw.py --validate 0` 验证 mask 对齐
5. **先跑 smoke test**：`python smoke_hw_train.py --experiment neural_tex_mlp --dataset_dir <your_dir> --cam_convention <your_convention>`
6. **小批量训练几 epoch 看 loss 是否下降**

---

## 7. 相机约定数学细节

所有约定最终都归一化到 OpenGL 相机坐标系（右手法则，-Z forward，+Y up）。
归一化方式是对原始 `transform_matrix` 右乘一个 4×4 修正矩阵：

- `opengl` / `blender`: `I`
- `colmap`: `diag(1, -1, -1, 1)`  （Y、Z 反向）
- `unity` / `directx`: `diag(1, 1, -1, 1)`  （Z 反向，同时完成左手到右手的转换）

实现见 `rasterize_hw.py` 中的 `CAM_CONVENTIONS` 与 `cam2world_from_raw()`。

---

## 8. 常见问题

**Q: 训练时报错 `No mesh.ply found`？**
A: `--dataset_dir` 没有指向 HW 格式目录，或目录下缺少 `mesh.ply` / `transforms_all.json`。

**Q: `rasterize_hw.py --validate` 的 mask IoU 很低？**
A: 多半是 `--cam_convention` 不对。尝试 `colmap` 或 `unity`。

**Q: 评估时提示 `config.json` 找不到？**
A: `--run_dir` 应该指向训练输出目录（包含 `config.json` 和 `checkpoints/`），而不是 checkpoint 文件本身。

**Q: 想跳过可视化以节省磁盘？**
A: `hw_eval_metrics.py` 加 `--no_vis`。
