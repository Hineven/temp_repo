# HW数据集结构描述
单个data directory下的目录结构：
`images/`：存储视角图像数据，其中包含00xx_0001.png（tonemap后渲染结果），编号xx从00到99连续。
`mesh.ply`：存储mesh，顶点上有xyz、st（uv）这五个参数。
`transforms_all/test/train/val.json`：所有视角的metadata。
其中，`transforms_xxx.json`的格式为：

{
    "camera_angle_x": radians // 浮点数，表示相机x方向的fov
    "frames": [
        {
            "file_path": "images/0000_0001", // 文件（名，不包含扩展名）
            "transform_matrix": [ // 相机transform
                [....],
                [....],
                [....],
                [0, 0, 0, 1]
            ],
            "time": 0.1231123 // 没用
        }, ...
    ]
}
