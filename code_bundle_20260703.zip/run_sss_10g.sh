#!/usr/bin/env bash
# 10 GFLOPs comparison on high-SSS dataset (~900 views)
set -e

COMMON="--dataset_dir dataset_hw_71_sss12 --epochs 100 --batch_size 1024 --num_workers 4 --load_workers 8 --data_device cpu --env_dim 8 --env_h 64 --env_w 128 --use_raw_geom --phys_factored --halo 0 --lambda_smooth 0.0001"

echo "=== 10G: shallow CNN base_ch=15 ==="
python -m train_lighting.run --experiment neural_tex_shallow_cnn --tag sss12_10g_cnn \
    $COMMON --neural_tex_dim 22 --neural_tex_res 256 --aux_full 8 --aux_half 4 --aux_quarter 4 --base_ch 15

echo "=== 10G: 1-layer MLP ==="
python -m train_lighting.run --experiment neural_tex_mlp --tag sss12_10g_mlp1 \
    $COMMON --neural_tex_dim 16 --neural_tex_res 256 --hidden_dim 64 --num_hidden_layers 1 --base_ch 16 --bottleneck_blocks 3

echo "=== 10G: mrt_nonorm base_ch=8 bn=4 ==="
python -m train_lighting.run --experiment neural_tex_mrt_nonorm --tag sss12_10g_nonorm \
    $COMMON --neural_tex_dim 22 --neural_tex_res 256 --aux_full 8 --aux_half 4 --aux_quarter 4 --base_ch 8 --bottleneck_blocks 4 --num_transformer_blocks 1

echo "=== 10G comparison done ==="
