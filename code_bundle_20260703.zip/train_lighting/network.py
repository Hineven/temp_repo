"""
Neural Radiance Prediction Network.

Components:
    NeuralEnvMap:     Learnable spherical feature grid (equirectangular)
    SepConvBlock:     Depthwise separable conv block
    UNetRadiance:     3-level U-Net predicting per-tile HDR radiance

Structural variants are now separate concerns, not flags: the output head has two modes
(plain linear, or physics-factored albedo⊙shading+residual) selected by `phys_factored`.
Falsified switches from the R4 campaign (SE / dropout / detail / split-heads / fresnel-gate /
ConvTranspose2d-upsample) have been removed. New structures should be new classes, not new flags.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def _gn_groups(ch):
    for g in [8, 4, 2, 1]:
        if ch % g == 0:
            return g
    return 1


# ============================================================================
# NeuralEnvMap: Spherical Equirectangular Feature Grid
# ============================================================================

class NeuralEnvMap(nn.Module):
    """
    Learnable spherical feature map stored in equirectangular projection.
    Query by world-space direction vector.
    """
    def __init__(self, feature_dim=8, h=64, w=128):
        super().__init__()
        self.feature_dim = feature_dim
        self.h = h
        self.w = w
        # Initialize with small random values
        self.grid = nn.Parameter(torch.randn(1, feature_dim, h, w) * 0.01)

    def query(self, directions):
        """
        Args:
            directions: [B, H, W, 3] unit vectors in world space
        Returns:
            features: [B, feature_dim, H, W]
        """
        # directions → spherical coords (θ, φ)
        theta = torch.atan2(directions[..., 1], directions[..., 0])  # [-π, π]
        phi = torch.acos(torch.clamp(directions[..., 2], -1.0, 1.0))  # [0, π]

        # Map to [0, 1]
        u = theta / (2.0 * math.pi) + 0.5
        v = phi / math.pi

        # grid_sample expects [-1, 1]
        uv = torch.stack([u, v], dim=-1) * 2.0 - 1.0  # [B, H, W, 2]

        # grid_sample: [B, C, H, W], [B, H, W, 2] → [B, C, H, W]
        features = F.grid_sample(
            self.grid.expand(directions.size(0), -1, -1, -1),
            uv,
            mode='bilinear',
            padding_mode='border',
            align_corners=False,
        )
        return features


# ============================================================================
# SepConvBlock: Depthwise Separable Convolution
# ============================================================================

class SepConvBlock(nn.Module):
    """
    Depthwise separable conv block:
      DepthwiseConv3x3 → GroupNorm → act
      PointwiseConv1x1 → GroupNorm → act
    """
    def __init__(self, in_ch, out_ch, act=nn.LeakyReLU(0.1, inplace=True)):
        super().__init__()
        self.block = nn.Sequential(
            # Depthwise
            nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=False),
            nn.GroupNorm(_gn_groups(in_ch), in_ch),
            act,
            # Pointwise
            nn.Conv2d(in_ch, out_ch, 1, bias=False),
            nn.GroupNorm(_gn_groups(out_ch), out_ch),
            act,
        )

    def forward(self, x):
        return self.block(x)


class SepConvBlockNoNorm(nn.Module):
    """
    Depthwise separable conv block WITHOUT normalization.

    For per-tile inference, removing normalization eliminates per-tile statistic
    differences that can cause visible brightness seams between tiles. Conv layers
    use bias=True since there is no following normalization layer.
    """
    def __init__(self, in_ch, out_ch, act=nn.LeakyReLU(0.1, inplace=True)):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=True),
            act,
            nn.Conv2d(in_ch, out_ch, 1, bias=True),
            act,
        )

    def forward(self, x):
        return self.block(x)


class SepConvBlockNoNormReplicate(nn.Module):
    """
    Depthwise separable conv block WITHOUT normalization and with REPLICATE padding.

    Replicate padding mirrors the edge pixels instead of padding zeros. For per-tile
    inference this is critical: zero padding creates a dark bias at tile boundaries,
    while replicate padding lets the boundary conv see coherent values and avoids the
    tile seam artifact.
    """
    def __init__(self, in_ch, out_ch, act=nn.LeakyReLU(0.1, inplace=True)):
        super().__init__()
        self.pad = nn.ReplicationPad2d(1)
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 3, padding=0, groups=in_ch, bias=True),
            act,
            nn.Conv2d(in_ch, out_ch, 1, bias=True),
            act,
        )

    def forward(self, x):
        return self.block(self.pad(x))


# ============================================================================
# UNetRadiance: Per-Tile HDR Radiance Prediction
# ============================================================================

class UNetRadiance(nn.Module):
    """
    3-level encoder-bottleneck-decoder U-Net for per-tile (32×32) radiance prediction.

    Decoder upsamples via Upsample(nearest)+Conv (anti-checkerboard; the
    ConvTranspose2d alternative caused 2×2 speckle and was removed).

    Output head (selected by `phys_factored`):
      False : radiance = head(fused)                                   [plain linear]
      True  : radiance = albedo ⊙ softplus(shading) + residual         [physics-factored]
              Multiplicative albedo fusion preserves dynamic range; the residual
              absorbs specular/coat/sss/errors so the prior is a safe superset.
    """
    def __init__(self, in_channels, base_ch=16, bottleneck_blocks=3,
                 phys_factored=False):
        super().__init__()
        c1 = base_ch
        c2 = base_ch * 2
        bn_ch = base_ch * 4
        self.phys_factored = phys_factored

        # Encoder
        self.enc1 = SepConvBlock(in_channels, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)   # 32→16

        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)   # 16→8

        # Bottleneck: configurable depth, Mish activation
        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2, bn_ch, act=mish)]
        for _ in range(bottleneck_blocks - 1):
            bn_blocks.append(SepConvBlock(bn_ch, bn_ch, act=mish))
        self.bottleneck = nn.Sequential(*bn_blocks)

        # Decoder upsampling: Upsample+Conv (anti-checkerboard)
        self.up2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(bn_ch, c2, 3, padding=1, bias=False),
        )
        self.up1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(c2, c1, 3, padding=1, bias=False),
        )

        self.dec2 = SepConvBlock(c2 * 2, c2)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        # Fusing: concat with albedo(3) + coat_tint(3) = 6 extra channels
        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )

        # Output head
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)  # nonneg diffuse shading (via softplus)
            self.head_res = nn.Conv2d(c1, 3, 1)    # residual: specular/coat/sss/errors (unbounded)
        else:
            self.head = nn.Conv2d(c1, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        # Small init on output heads so initial radiance ≈ 0
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        # phys_factored: bias shading head negative so softplus→small (≈0.05) at init, keeping
        # initial radiance ≈ albedo·0.05 ≈ dark (stable start); residual stays ~0 via the loop above.
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        """
        Args:
            x:        [B, in_channels, H, W]  network input (features + env features)
            albedo:   [B, 3, H, W]            from G-Buffer
            coat_tint:[B, 3, H, W]            from G-Buffer
        Returns:
            radiance: [B, 3, H, W]            predicted HDR radiance
        """
        # Encoder
        e1 = self.enc1(x)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)

        # Bottleneck
        b = self.bottleneck(p2)

        # Decoder
        d2 = self.dec2(torch.cat([self.up2(b), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))

        # Fusing with albedo and coat_tint
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))

        # Output head
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))          # [3,H,W] nonneg diffuse shading
            radiance = albedo * shading + self.head_res(fused)    # albedo-modulated diffuse + residual
        else:
            radiance = self.head(fused)

        return radiance


# ============================================================================
# MultiResUNetRadiance: inject texture features at multiple resolutions
# ============================================================================

class MultiResUNetRadiance(nn.Module):
    """U-Net that injects the neural-texture features at MULTIPLE resolutions instead of all at enc1.

    The expensive 32² path (enc1/dec1) only carries the geom + the FULL-res aux slice; the rest of
    the texture channels are mean-pooled by 2 / 4 and injected at the 16² decoder (dec2) and the 8²
    bottleneck respectively. Since the 32² convs dominate FLOPs, moving texture channels off enc1 and
    into the cheap lower-res levels cuts compute for a fixed total feature budget.

    Topology (mirrors UNetRadiance, with two extra concat injections):
      enc1(in_full, c1)@32² → pool → enc2(c1,c2)@16² → pool →
      bottleneck(cat[c2, aux_quarter] → bn_ch)@8² →
      up2 → dec2(cat[c2, c2, aux_half] → c2)@16² → up1 → dec1(cat[c1, c1] → c1)@32² →
      fuse(+albedo, coat_tint) → head

    aux_half / aux_quarter are pre-pooled by the caller (avg_pool2d ×2 / ×4) to the matching level.
    """
    def __init__(self, in_full, aux_half_ch, aux_quarter_ch, base_ch=16,
                 bottleneck_blocks=6, phys_factored=False):
        super().__init__()
        c1, c2, bn_ch = base_ch, base_ch * 2, base_ch * 4
        self.phys_factored = phys_factored
        self.aux_half_ch = aux_half_ch
        self.aux_quarter_ch = aux_quarter_ch

        self.enc1 = SepConvBlock(in_full, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)
        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)

        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2 + aux_quarter_ch, bn_ch, act=mish)]
        for _ in range(bottleneck_blocks - 1):
            bn_blocks.append(SepConvBlock(bn_ch, bn_ch, act=mish))
        self.bottleneck = nn.Sequential(*bn_blocks)

        self.up2 = nn.Sequential(nn.Upsample(scale_factor=2, mode='nearest'),
                                 nn.Conv2d(bn_ch, c2, 3, padding=1, bias=False))
        self.dec2 = SepConvBlock(c2 * 2 + aux_half_ch, c2)
        self.up1 = nn.Sequential(nn.Upsample(scale_factor=2, mode='nearest'),
                                 nn.Conv2d(c2, c1, 3, padding=1, bias=False))
        self.dec1 = SepConvBlock(c1 * 2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)
        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x_full, aux_half, aux_quarter, albedo, coat_tint):
        e1 = self.enc1(x_full)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(torch.cat([p2, aux_quarter], dim=1))
        d2 = self.dec2(torch.cat([self.up2(b), e2, aux_half], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


# ============================================================================
# MultiResTransformerUNetRadiance: multi-res + lightweight intra-tile attention
# ============================================================================

class MultiResTransformerUNetRadiance(nn.Module):
    """MultiResUNetRadiance with a lightweight transformer tail in the bottleneck.

    The last `num_transformer_blocks` bottleneck blocks are replaced by
    IntraTileSelfAttention (global within the 8×8 tile, ≤64 tokens), which
    gives the model explicit spatial mixing at the coarsest resolution.
    To stay inside the 10–30 GFLOP target, the expensive upsample convs are
    replaced by SepUpsample (depthwise 3×3 + pointwise 1×1) from LightUNetRadiance.

    Topology:
      enc1(in_full, c1)@32² → pool → enc2(c1,c2)@16² → pool →
      bottleneck(cat[c2, aux_quarter] → bn_ch)@8²
        [ (bn-1-num_tr) SepConvBlocks | num_tr IntraTileSelfAttention blocks ]
      → up2(SepUpsample) → dec2(cat[c2,c2,aux_half] → c2)@16²
      → up1(SepUpsample) → dec1(cat[c1,c1] → c1)@32² → fuse(+albedo,coat_tint) → head
    """

    def __init__(self, in_full, aux_half_ch, aux_quarter_ch, base_ch=12,
                 bottleneck_blocks=6, num_transformer_blocks=1,
                 attn_heads=4, attn_mlp_ratio=2.0, phys_factored=False):
        super().__init__()
        assert 0 <= num_transformer_blocks <= bottleneck_blocks - 1, (
            "num_transformer_blocks must be in [0, bottleneck_blocks-1]; "
            "the first bottleneck block is always a conv (it projects to bn_ch)")
        c1, c2, bn_ch = base_ch, base_ch * 2, base_ch * 4
        self.phys_factored = phys_factored
        self.aux_half_ch = aux_half_ch
        self.aux_quarter_ch = aux_quarter_ch

        self.enc1 = SepConvBlock(in_full, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)
        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)

        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2 + aux_quarter_ch, bn_ch, act=mish)]
        conv_tail = bottleneck_blocks - 1 - num_transformer_blocks
        for _ in range(conv_tail):
            bn_blocks.append(SepConvBlock(bn_ch, bn_ch, act=mish))
        for _ in range(num_transformer_blocks):
            bn_blocks.append(IntraTileSelfAttention(bn_ch, num_heads=attn_heads,
                                                     mlp_ratio=attn_mlp_ratio))
        self.bottleneck = nn.Sequential(*bn_blocks)

        self.up2 = SepUpsample(bn_ch, c2)
        self.dec2 = SepConvBlock(c2 * 2 + aux_half_ch, c2)
        self.up1 = SepUpsample(c2, c1)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)
        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x_full, aux_half, aux_quarter, albedo, coat_tint):
        e1 = self.enc1(x_full)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(torch.cat([p2, aux_quarter], dim=1))
        d2 = self.dec2(torch.cat([self.up2(b), e2, aux_half], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


class MultiResTransformerUNetRadianceNoNorm(nn.Module):
    """MultiResTransformerUNetRadiance with NO GroupNorm.

    Removing normalization makes the network purely convolutional/attentional,
    eliminating per-tile statistic differences that can cause visible brightness
    seams between tiles. Conv layers use bias=True; attention has no layer norm.
    """

    def __init__(self, in_full, aux_half_ch, aux_quarter_ch, base_ch=12,
                 bottleneck_blocks=6, num_transformer_blocks=1,
                 attn_heads=4, attn_mlp_ratio=2.0, phys_factored=False):
        super().__init__()
        assert 0 <= num_transformer_blocks <= bottleneck_blocks - 1, (
            "num_transformer_blocks must be in [0, bottleneck_blocks-1]; "
            "the first bottleneck block is always a conv (it projects to bn_ch)")
        c1, c2, bn_ch = base_ch, base_ch * 2, base_ch * 4
        self.phys_factored = phys_factored
        self.aux_half_ch = aux_half_ch
        self.aux_quarter_ch = aux_quarter_ch

        self.enc1 = SepConvBlockNoNorm(in_full, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)
        self.enc2 = SepConvBlockNoNorm(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)

        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlockNoNorm(c2 + aux_quarter_ch, bn_ch, act=mish)]
        conv_tail = bottleneck_blocks - 1 - num_transformer_blocks
        for _ in range(conv_tail):
            bn_blocks.append(SepConvBlockNoNorm(bn_ch, bn_ch, act=mish))
        for _ in range(num_transformer_blocks):
            bn_blocks.append(IntraTileSelfAttentionNoNorm(bn_ch, num_heads=attn_heads,
                                                          mlp_ratio=attn_mlp_ratio))
        self.bottleneck = nn.Sequential(*bn_blocks)

        self.up2 = SepUpsample(bn_ch, c2)
        self.dec2 = SepConvBlockNoNorm(c2 * 2 + aux_half_ch, c2)
        self.up1 = SepUpsample(c2, c1)
        self.dec1 = SepConvBlockNoNorm(c1 * 2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
        )
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)
        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x_full, aux_half, aux_quarter, albedo, coat_tint):
        e1 = self.enc1(x_full)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(torch.cat([p2, aux_quarter], dim=1))
        d2 = self.dec2(torch.cat([self.up2(b), e2, aux_half], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


class MultiResTransformerUNetRadianceNoNormReplicate(nn.Module):
    """No-norm multi-res transformer U-Net with REPLICATE padding everywhere.

    Combines the no-norm benefit (no per-tile statistic drift) with replicate
    padding (no zero-padding dark bias at tile boundaries). This is the most
    aggressive per-tile-seam fix short of full-frame inference.
    """

    def __init__(self, in_full, aux_half_ch, aux_quarter_ch, base_ch=12,
                 bottleneck_blocks=6, num_transformer_blocks=1,
                 attn_heads=4, attn_mlp_ratio=2.0, phys_factored=False):
        super().__init__()
        assert 0 <= num_transformer_blocks <= bottleneck_blocks - 1, (
            "num_transformer_blocks must be in [0, bottleneck_blocks-1]; "
            "the first bottleneck block is always a conv (it projects to bn_ch)")
        c1, c2, bn_ch = base_ch, base_ch * 2, base_ch * 4
        self.phys_factored = phys_factored
        self.aux_half_ch = aux_half_ch
        self.aux_quarter_ch = aux_quarter_ch

        self.enc1 = SepConvBlockNoNormReplicate(in_full, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)
        self.enc2 = SepConvBlockNoNormReplicate(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)

        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlockNoNormReplicate(c2 + aux_quarter_ch, bn_ch, act=mish)]
        conv_tail = bottleneck_blocks - 1 - num_transformer_blocks
        for _ in range(conv_tail):
            bn_blocks.append(SepConvBlockNoNormReplicate(bn_ch, bn_ch, act=mish))
        for _ in range(num_transformer_blocks):
            bn_blocks.append(IntraTileSelfAttentionNoNorm(bn_ch, num_heads=attn_heads,
                                                          mlp_ratio=attn_mlp_ratio))
        self.bottleneck = nn.Sequential(*bn_blocks)

        self.up2 = SepUpsampleReplicate(bn_ch, c2)
        self.dec2 = SepConvBlockNoNormReplicate(c2 * 2 + aux_half_ch, c2)
        self.up1 = SepUpsampleReplicate(c2, c1)
        self.dec1 = SepConvBlockNoNormReplicate(c1 * 2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
        )
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)
        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x_full, aux_half, aux_quarter, albedo, coat_tint):
        e1 = self.enc1(x_full)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(torch.cat([p2, aux_quarter], dim=1))
        d2 = self.dec2(torch.cat([self.up2(b), e2, aux_half], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


class ShallowTwoLayerUNetRadiance(nn.Module):
    """Very shallow 2-block CNN with U-Net-style multi-resolution feature injection.

    Tests whether the deep encoder-bottleneck-decoder stack is necessary, or if two
    separable conv blocks (one at full res, one at half res) with hierarchical aux
    injection and a skip connection are sufficient. Keeps GroupNorm out (following
    the no-norm campaign) to avoid per-tile statistic drift.

    Topology:
      enc1(in_full, c1)@32² → pool →
      enc2(cat[c1, aux_half, upsampled(aux_quarter)], c2)@16² →
      SepUpsample(c2 → c1)@32² →
      fuse(cat[up, e1, albedo, coat_tint]) → head
    """

    def __init__(self, in_full, aux_half_ch, aux_quarter_ch, base_ch=40,
                 phys_factored=False):
        super().__init__()
        c1, c2 = base_ch, base_ch * 2
        self.phys_factored = phys_factored
        self.aux_half_ch = aux_half_ch
        self.aux_quarter_ch = aux_quarter_ch

        self.enc1 = SepConvBlockNoNorm(in_full, c1)
        self.pool = nn.Conv2d(c1, c1, 2, stride=2)
        self.enc2 = SepConvBlockNoNorm(c1 + aux_half_ch + aux_quarter_ch, c2)
        self.up = SepUpsample(c2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 * 2 + 6, c1, 1, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
        )
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1, bias=True)
            self.head_res = nn.Conv2d(c1, 3, 1, bias=True)
        else:
            self.head = nn.Conv2d(c1, 3, 1, bias=True)
        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x_full, aux_half, aux_quarter, albedo, coat_tint):
        e1 = self.enc1(x_full)
        p1 = self.pool(e1)
        aux_q_up = F.interpolate(aux_quarter, size=p1.shape[-2:], mode='nearest')
        e2 = self.enc2(torch.cat([p1, aux_half, aux_q_up], dim=1))
        u = self.up(e2)
        fused = self.fuse(torch.cat([u, e1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


class PureMLPRadiance(nn.Module):
    """Pure per-pixel MLP: no U-Net, no spatial convolutions, no resolution splits.

    Each pixel is processed independently by a stack of 1×1 convolutions (equivalent
    to an MLP applied per spatial location). This baseline isolates whether the
    U-Net's spatial inductive bias is actually necessary, or if the bakeable
    neural texture + env maps already carry enough information.

    Input: concatenated per-pixel features (e.g. ndotv + aux + env(normal) + env(reflection)).
    Output: 3-channel radiance, optionally physics-factored.
    """

    def __init__(self, in_channels, hidden_dim=64, num_hidden_layers=3,
                 phys_factored=False):
        super().__init__()
        self.phys_factored = phys_factored

        layers = []
        layers.append(nn.Conv2d(in_channels, hidden_dim, 1, bias=True))
        layers.append(nn.LeakyReLU(0.1, inplace=True))
        for _ in range(num_hidden_layers - 1):
            layers.append(nn.Conv2d(hidden_dim, hidden_dim, 1, bias=True))
            layers.append(nn.LeakyReLU(0.1, inplace=True))
        self.mlp = nn.Sequential(*layers)

        if phys_factored:
            self.head_shade = nn.Conv2d(hidden_dim, 3, 1)
            self.head_res = nn.Conv2d(hidden_dim, 3, 1)
        else:
            self.head = nn.Conv2d(hidden_dim, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        """Args:
            x:        [B, in_channels, H, W]  per-pixel input features
            albedo:   [B, 3, H, W]
            coat_tint:[B, 3, H, W] (ignored when not phys_factored)
        Returns:
            radiance: [B, 3, H, W]
        """
        feat = self.mlp(x)
        if self.phys_factored:
            shading = F.softplus(self.head_shade(feat))
            radiance = albedo * shading + self.head_res(feat)
        else:
            radiance = self.head(feat)
        return radiance


class SepUpsample(nn.Module):
    """Upsample(nearest) + depthwise 3×3 (spatial blend) + pointwise 1×1 (channel proj).

    Replaces UNetRadiance's Upsample+full-3×3-Conv. Same anti-checkerboard spatial
    blending (the depthwise 3×3 keeps it), but ~9× cheaper because the channel
    reduction moves to a 1×1 pointwise. The full 3×3 `up1`/`up2` were 70% of
    UNetRadiance's FLOPs (they run at the two highest resolutions), so this is the
    highest-leverage cut for a 1080p compute budget. Dec SepConvBlocks still provide
    3×3 spatial mixing after the concat, so no spatial information is dropped.
    """
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode='nearest')
        self.dw = nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=False)
        self.pw = nn.Conv2d(in_ch, out_ch, 1, bias=False)

    def forward(self, x):
        return self.pw(self.dw(self.up(x)))


class SepUpsampleReplicate(nn.Module):
    """SepUpsample with REPLICATE padding instead of zero padding."""

    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode='nearest')
        self.pad = nn.ReplicationPad2d(1)
        self.dw = nn.Conv2d(in_ch, in_ch, 3, padding=0, groups=in_ch, bias=False)
        self.pw = nn.Conv2d(in_ch, out_ch, 1, bias=False)

    def forward(self, x):
        return self.pw(self.dw(self.pad(self.up(x))))


class LightUNetRadiance(nn.Module):
    """
    FLOP-reduced per-tile radiance U-Net. Identical topology to UNetRadiance
    (3-level enc/bottleneck/dec, same channel widths, same phys_factored head)
    EXCEPT the two upsample blocks use SepUpsample (depthwise 3×3 + pointwise 1×1)
    instead of Upsample+full-3×3-Conv.

    Cost at base_ch=16, bn=3, phys_factored, in=29: ~0.013 GFLOPs/tile → ~27 GFLOPs
    for a 1920×1080 frame (vs UNetRadiance's ~59). Params ~27K (vs ~46K).

    This is a distinct class, not a flag on UNetRadiance — see the network-structure
    convention (new structure = new class). Output head and init mirror UNetRadiance.
    """
    def __init__(self, in_channels, base_ch=16, bottleneck_blocks=3,
                 phys_factored=False):
        super().__init__()
        c1 = base_ch
        c2 = base_ch * 2
        bn_ch = base_ch * 4
        self.phys_factored = phys_factored

        # Encoder (identical to UNetRadiance)
        self.enc1 = SepConvBlock(in_channels, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)   # 32→16
        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)   # 16→8

        # Bottleneck (identical)
        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2, bn_ch, act=mish)]
        for _ in range(bottleneck_blocks - 1):
            bn_blocks.append(SepConvBlock(bn_ch, bn_ch, act=mish))
        self.bottleneck = nn.Sequential(*bn_blocks)

        # Decoder upsampling: SEPARABLE (the only structural difference)
        self.up2 = SepUpsample(bn_ch, c2)
        self.up1 = SepUpsample(c2, c1)

        self.dec2 = SepConvBlock(c2 * 2, c2)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        # Fusing + output head (identical to UNetRadiance)
        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )
        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        e1 = self.enc1(x)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(p2)
        d2 = self.dec2(torch.cat([self.up2(b), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


# ============================================================================
# Intra-tile self-attention bottleneck variant
# ============================================================================

class IntraTileSelfAttention(nn.Module):
    """
    Spatial self-attention that operates strictly inside a single tile.

    The 2-D feature map is reshaped into HW tokens; attention mixes tokens
    within the tile only, so it preserves the "one tile = one independent
    inference" constraint.  At the 8×8 bottleneck of a 32×32 tile there are
    only 64 tokens, making this very cheap.

    Uses GroupNorm (matches the rest of the U-Net) and a 1×1 MLP.
    """

    def __init__(self, channels, num_heads=4, mlp_ratio=2.0):
        super().__init__()
        assert channels % num_heads == 0, "channels must be divisible by num_heads"
        self.channels = channels
        self.num_heads = num_heads
        self.head_dim = channels // num_heads

        self.norm1 = nn.GroupNorm(_gn_groups(channels), channels)
        self.qkv = nn.Conv2d(channels, channels * 3, 1, bias=False)
        self.proj = nn.Conv2d(channels, channels, 1, bias=False)

        self.norm2 = nn.GroupNorm(_gn_groups(channels), channels)
        hidden = int(channels * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.Mish(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=False),
        )

    def forward(self, x):
        B, C, H, W = x.shape
        N = H * W

        # --- attention branch ---
        shortcut = x
        x = self.norm1(x)
        qkv = self.qkv(x)  # [B, 3*C, H, W]
        qkv = qkv.view(B, 3, self.num_heads, self.head_dim, N).permute(1, 0, 2, 4, 3)
        q, k, v = qkv[0], qkv[1], qkv[2]  # each [B, heads, N, head_dim]

        attn = (q @ k.transpose(-2, -1)) * (self.head_dim ** -0.5)
        attn = attn.softmax(dim=-1)
        out = (attn @ v)  # [B, heads, N, head_dim]
        out = out.transpose(1, 2).reshape(B, N, C).permute(0, 2, 1).reshape(B, C, H, W)
        out = self.proj(out)
        x = shortcut + out

        # --- FFN branch ---
        x = x + self.mlp(self.norm2(x))
        return x


class IntraTileSelfAttentionNoNorm(nn.Module):
    """Same as IntraTileSelfAttention but without GroupNorm (no per-tile stats)."""

    def __init__(self, channels, num_heads=4, mlp_ratio=2.0):
        super().__init__()
        assert channels % num_heads == 0, "channels must be divisible by num_heads"
        self.channels = channels
        self.num_heads = num_heads
        self.head_dim = channels // num_heads

        self.qkv = nn.Conv2d(channels, channels * 3, 1, bias=True)
        self.proj = nn.Conv2d(channels, channels, 1, bias=True)

        hidden = int(channels * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=True),
            nn.Mish(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=True),
        )

    def forward(self, x):
        B, C, H, W = x.shape
        N = H * W

        shortcut = x
        qkv = self.qkv(x)
        qkv = qkv.view(B, 3, self.num_heads, self.head_dim, N).permute(1, 0, 2, 4, 3)
        q, k, v = qkv[0], qkv[1], qkv[2]

        attn = (q @ k.transpose(-2, -1)) * (self.head_dim ** -0.5)
        attn = attn.softmax(dim=-1)
        out = (attn @ v)
        out = out.transpose(1, 2).reshape(B, N, C).permute(0, 2, 1).reshape(B, C, H, W)
        out = self.proj(out)
        x = shortcut + out
        x = x + self.mlp(x)
        return x


class AttentionBottleneckUNetRadiance(nn.Module):
    """
    UNetRadiance with the bottleneck blocks replaced by intra-tile self-attention.

    Encoder, decoder, fusion and output head are identical to UNetRadiance;
    only the lowest-resolution bottleneck mixes spatial information via
    global-within-tile attention instead of 3×3 separable convolutions.

    Intended to mitigate tile-boundary errors by giving boundary pixels access
    to the whole tile's context (while still not crossing tile boundaries).
    """

    def __init__(self, in_channels, base_ch=16, bottleneck_blocks=3,
                 phys_factored=False, attn_heads=4, attn_mlp_ratio=2.0):
        super().__init__()
        c1 = base_ch
        c2 = base_ch * 2
        bn_ch = base_ch * 4
        self.phys_factored = phys_factored

        # Encoder (identical to UNetRadiance)
        self.enc1 = SepConvBlock(in_channels, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)   # 32→16
        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)   # 16→8

        # Bottleneck: one conv projection + (blocks-1) self-attention layers
        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2, bn_ch, act=mish)]
        for _ in range(bottleneck_blocks - 1):
            bn_blocks.append(IntraTileSelfAttention(bn_ch, num_heads=attn_heads,
                                                    mlp_ratio=attn_mlp_ratio))
        self.bottleneck = nn.Sequential(*bn_blocks)

        # Decoder (identical to UNetRadiance)
        self.up2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(bn_ch, c2, 3, padding=1, bias=False),
        )
        self.up1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(c2, c1, 3, padding=1, bias=False),
        )
        self.dec2 = SepConvBlock(c2 * 2, c2)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )

        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        e1 = self.enc1(x)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(p2)
        d2 = self.dec2(torch.cat([self.up2(b), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance


# ============================================================================
# Mixed bottleneck: conv blocks + a subset of intra-tile self-attention blocks
# ============================================================================

class MixedAttentionBottleneckUNetRadiance(nn.Module):
    """
    UNetRadiance with a mixed bottleneck: some blocks are SepConv, the rest are
    IntraTileSelfAttention.

    The first bottleneck block is always a SepConv projection (c2 -> bn_ch).
    The remaining (bottleneck_blocks - 1) blocks are split:
      - the first (blocks - 1 - num_attn_blocks) are SepConvBlock
      - the last num_attn_blocks are IntraTileSelfAttention

    This tests whether attention is needed in every bottleneck block, or whether
    a few attention blocks placed at the end of the bottleneck are sufficient.
    """

    def __init__(self, in_channels, base_ch=16, bottleneck_blocks=3,
                 phys_factored=False, attn_heads=4, attn_mlp_ratio=2.0,
                 num_attn_blocks=3):
        super().__init__()
        c1 = base_ch
        c2 = base_ch * 2
        bn_ch = base_ch * 4
        self.phys_factored = phys_factored

        # Encoder (identical to UNetRadiance)
        self.enc1 = SepConvBlock(in_channels, c1)
        self.pool1 = nn.Conv2d(c1, c1, 2, stride=2)   # 32->16
        self.enc2 = SepConvBlock(c1, c2)
        self.pool2 = nn.Conv2d(c2, c2, 2, stride=2)   # 16->8

        # Mixed bottleneck
        mish = nn.Mish(inplace=True)
        bn_blocks = [SepConvBlock(c2, bn_ch, act=mish)]
        n_post = bottleneck_blocks - 1
        n_conv_post = max(n_post - num_attn_blocks, 0)
        for i in range(n_post):
            if i < n_conv_post:
                bn_blocks.append(SepConvBlock(bn_ch, bn_ch, act=mish))
            else:
                bn_blocks.append(IntraTileSelfAttention(bn_ch, num_heads=attn_heads,
                                                        mlp_ratio=attn_mlp_ratio))
        self.bottleneck = nn.Sequential(*bn_blocks)

        # Decoder (identical to UNetRadiance)
        self.up2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(bn_ch, c2, 3, padding=1, bias=False),
        )
        self.up1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(c2, c1, 3, padding=1, bias=False),
        )
        self.dec2 = SepConvBlock(c2 * 2, c2)
        self.dec1 = SepConvBlock(c1 * 2, c1)

        self.fuse = nn.Sequential(
            nn.Conv2d(c1 + 6, c1, 1, bias=False),
            nn.GroupNorm(_gn_groups(c1), c1),
            nn.LeakyReLU(0.1, inplace=True),
        )

        if phys_factored:
            self.head_shade = nn.Conv2d(c1, 3, 1)
            self.head_res = nn.Conv2d(c1, 3, 1)
        else:
            self.head = nn.Conv2d(c1, 3, 1)

        self._init_weights()

    def _output_heads(self):
        return [self.head_shade, self.head_res] if self.phys_factored else [self.head]

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
            elif isinstance(m, nn.GroupNorm):
                if m.weight is not None:
                    nn.init.ones_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        for h in self._output_heads():
            nn.init.normal_(h.weight, std=0.01)
            nn.init.zeros_(h.bias)
        if self.phys_factored:
            nn.init.constant_(self.head_shade.bias, -3.0)

    def forward(self, x, albedo, coat_tint):
        e1 = self.enc1(x)
        p1 = self.pool1(e1)
        e2 = self.enc2(p1)
        p2 = self.pool2(e2)
        b = self.bottleneck(p2)
        d2 = self.dec2(torch.cat([self.up2(b), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        fused = self.fuse(torch.cat([d1, albedo, coat_tint], dim=1))
        if self.phys_factored:
            shading = F.softplus(self.head_shade(fused))
            radiance = albedo * shading + self.head_res(fused)
        else:
            radiance = self.head(fused)
        return radiance
