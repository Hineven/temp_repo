"""
NeuralTexMLPExperiment — pure per-pixel MLP baseline.

No U-Net, no multi-resolution injection, no spatial convolutions. The network is a
stack of 1×1 convolutions (equivalent to an MLP applied independently per pixel).
Everything else (neural texture, env maps, loss, optimizer) matches the current
best setup so the comparison isolates the value of the U-Net spatial structure.
"""

from train_lighting.network import PureMLPRadiance, NeuralEnvMap
from train_lighting.experiments.neural_tex_env import NeuralTexEnvExperiment
from train_lighting.experiments.neural_tex import NeuralTexExperiment


class NeuralTexMLPExperiment(NeuralTexEnvExperiment):
    NAME = "neural_tex_mlp"

    def __init__(self, hidden_dim=64, num_hidden_layers=3, **kwargs):
        super().__init__(**kwargs)
        self.hidden_dim = hidden_dim
        self.num_hidden_layers = num_hidden_layers

    @classmethod
    def from_args(cls, args):
        return cls(
            neural_tex_dim=getattr(args, "neural_tex_dim", 16),
            neural_tex_res=getattr(args, "neural_tex_res", 256),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
            hidden_dim=getattr(args, "hidden_dim", 64),
            num_hidden_layers=getattr(args, "num_hidden_layers", 3),
        )

    def build_modules(self, device):
        # Skip NeuralTexEnvExperiment.build_modules (which builds UNetRadiance + env maps);
        # use NeuralTexExperiment.build_modules to get neural_tex only.
        mods = super(NeuralTexEnvExperiment, self).build_modules(device)
        mods["network"] = PureMLPRadiance(
            in_channels=self._in_channels(),
            hidden_dim=self.hidden_dim,
            num_hidden_layers=self.num_hidden_layers,
            phys_factored=self.phys_factored,
        ).to(device)
        mods["env_map"] = NeuralEnvMap(feature_dim=self.env_dim, h=self.env_h, w=self.env_w).to(device)
        mods["env_ref_map"] = NeuralEnvMap(feature_dim=self.env_dim, h=self.env_h, w=self.env_w).to(device)
        return mods

    def config(self):
        return {
            **super().config(),
            "network": "PureMLPRadiance",
            "hidden_dim": self.hidden_dim,
            "num_hidden_layers": self.num_hidden_layers,
        }
