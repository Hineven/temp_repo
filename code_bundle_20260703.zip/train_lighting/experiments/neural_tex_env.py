"""
NeuralTexEnvExperiment — neural_tex + view-dependent neural env maps (normal + reflection).

R12's neural_tex is fully view-INDEPENDENT (UV only) — it wins on mean L1 but its residual
concentrates at specular tips. This adds the two bakeable direction tables that helped in the earlier
designs, sourced from the rasterized geometry:
    env_map      (queried by normal)        — irradiance / view-independent lighting term
    env_ref_map  (queried by reflection_dir) — prefiltered specular term (reflection_dir = view-derived)
The reflection_dir depends on view_dir, so env_ref_map reintroduces view-dependence (moving specular).

Differentiable chain: uv -> neural_texture -> [albedo|coat_tint|aux]; normal -> env_map; refl -> env_ref_map;
    x = [ndotv | aux | env(normal) | env(reflection)] -> UNetRadiance -> clamp -> LDR.
The UV neural texture (surface-baked material) and the two spherical env maps (direction-baked
lighting) are complementary: the texture says WHAT the surface is, the env maps say HOW it's lit.
"""

import torch

from train_lighting.network import NeuralEnvMap
from train_lighting.experiments.base import FeatureSpec
from train_lighting.experiments.baseline import _env_map_smoothness_loss
from train_lighting.experiments.neural_tex import NeuralTexExperiment, _tv_loss
from train_lighting.tonemap import linear_to_srgb


class NeuralTexEnvExperiment(NeuralTexExperiment):
    NAME = "neural_tex_env"

    def __init__(self, env_dim=8, env_h=64, env_w=128, use_raw_geom=False, **kwargs):
        super().__init__(**kwargs)
        self.env_dim = env_dim
        self.env_h = env_h
        self.env_w = env_w
        self.use_raw_geom = use_raw_geom

    @classmethod
    def from_args(cls, args):
        return cls(
            neural_tex_dim=getattr(args, "neural_tex_dim", 16),
            neural_tex_res=getattr(args, "neural_tex_res", 256),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
        )

    @property
    def feature_spec(self):
        # Ask the HW loader for normal + reflection_dir (env-map keys) + ndotv (input).
        return FeatureSpec(compute_ndotv=True, compute_reflection=True)

    def _in_channels(self):
        n = 1 + self.aux_dim + 2 * self.env_dim            # ndotv + aux + env(normal) + env(reflection)
        if self.use_raw_geom:
            n += 6                                          # raw normal(3) + reflection(3)
        return n

    def forward(self, batch, modules, device):
        x, albedo, coat_tint = self._assemble_network_input(batch, device, modules)
        radiance = modules["network"](x, albedo, coat_tint)
        if self.halo > 0:
            ts = batch["rgb_gt"].shape[-1]
            h = self.halo
            radiance = radiance[..., h:h + ts, h:h + ts]
        self.last_radiance = radiance.detach()
        # HDR network output -> tonemap (linear->sRGB) -> clamp; loss on tonemapped LDR (matches GT).
        return torch.clamp(linear_to_srgb(radiance), 0.0, 1.0)

    def build_modules(self, device):
        # UNetRadiance built by the parent (in_channels overridden below via _in_channels); but parent
        # builds it with parent._in_channels, so rebuild with our width here.
        from train_lighting.network import UNetRadiance
        mods = super().build_modules(device)                # network (parent width) + neural_tex
        mods["network"] = UNetRadiance(
            in_channels=self._in_channels(),
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            phys_factored=self.phys_factored,
        ).to(device)
        mods["env_map"] = NeuralEnvMap(feature_dim=self.env_dim, h=self.env_h, w=self.env_w).to(device)
        mods["env_ref_map"] = NeuralEnvMap(feature_dim=self.env_dim, h=self.env_h, w=self.env_w).to(device)
        return mods

    def _assemble_network_input(self, batch, device, modules):
        uv = batch["uv"].to(device, non_blocking=True)
        feats = modules["neural_tex"].query(uv)
        albedo = feats[:, 0:3]
        coat_tint = feats[:, 3:6]
        aux = feats[:, 6:6 + self.aux_dim] if self.aux_dim > 0 else None

        normal = batch["normal"].to(device, non_blocking=True)
        reflection_dir = batch["reflection_dir"].to(device, non_blocking=True)
        ndotv = batch["ndotv"].to(device, non_blocking=True)
        env_feat = modules["env_map"].query(normal.permute(0, 2, 3, 1))
        env_ref_feat = modules["env_ref_map"].query(reflection_dir.permute(0, 2, 3, 1))

        parts = [ndotv]
        if aux is not None:
            parts.append(aux)
        parts += [env_feat, env_ref_feat]
        if self.use_raw_geom:
            parts += [normal, reflection_dir]
        return torch.cat(parts, dim=1), albedo, coat_tint

    def compute_loss(self, pred, batch, modules, device):
        rgb_gt = batch["rgb_gt"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)
        l1 = self._criterion(pred, rgb_gt, mask)
        smooth = (_tv_loss(modules["neural_tex"].grid)
                  + _env_map_smoothness_loss(modules["env_map"])
                  + _env_map_smoothness_loss(modules["env_ref_map"]))
        total = l1 + self.lambda_smooth * smooth
        return total, {"l1": l1.item(), "smooth": smooth.item()}

    def build_optimizer(self, modules, args):
        optimizer = torch.optim.AdamW([
            {"params": modules["network"].parameters(), "lr": args.lr_network,
             "weight_decay": args.weight_decay},
            {"params": modules["neural_tex"].parameters(), "lr": args.lr_env_map, "weight_decay": 0},
            {"params": list(modules["env_map"].parameters()) + list(modules["env_ref_map"].parameters()),
             "lr": args.lr_env_map, "weight_decay": 0},
        ])
        eta_min = getattr(args, "lr_eta_min", 1e-6)
        warmup = getattr(args, "lr_warmup_epochs", 0)
        cosine = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(args.epochs - warmup, 1), eta_min=eta_min)
        if warmup > 0:
            warm = torch.optim.lr_scheduler.LinearLR(optimizer, start_factor=0.1, total_iters=warmup)
            scheduler = torch.optim.lr_scheduler.SequentialLR(optimizer, [warm, cosine], milestones=[warmup])
        else:
            scheduler = cosine
        return optimizer, scheduler

    def config(self):
        return {
            **super().config(),
            "network": "UNetRadiance",
            "env_dim": self.env_dim, "env_h": self.env_h, "env_w": self.env_w,
            "use_raw_geom": self.use_raw_geom,
            "directional_tables": 2,
        }
