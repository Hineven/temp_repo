"""
NeuralTexExperiment — HW_DATASET pipeline: UV-indexed neural texture + reused U-Net, LDR output.

Minimal differentiable route (only the network + neural texture are learned; UV is a fixed input):
    uv (fixed, per view) -> grid_sample(neural_texture) -> features ->
    UNetRadiance -> clamp -> LDR

The HW format carries no G-Buffer / PBR attributes: the learnable neural texture (a 2D feature
grid in UV space) IS the sole material/input representation. Its first 6 channels feed the
backbone's albedo+coat_tint fusion path (reused verbatim from UNetRadiance); the rest are auxiliary
feature channels. Output is decoded as LDR (clamp [0,1], no tonemap) since the HW images are
tonemapped LDR renders.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from train_lighting.network import UNetRadiance
from train_lighting.experiments.base import Experiment, FeatureSpec
from train_lighting.experiments.baseline import _env_map_smoothness_loss
from train_lighting.tonemap import linear_to_srgb


class NeuralTexture(nn.Module):
    """A learnable 2D feature grid in UV space [0,1]^2. Queried by per-pixel UV via grid_sample."""
    def __init__(self, feature_dim, res=256):
        super().__init__()
        self.feature_dim = feature_dim
        self.res = res
        self.grid = nn.Parameter(torch.randn(1, feature_dim, res, res) * 0.01)

    def query(self, uv):
        """uv: [B,2,H,W] in [0,1]. Returns [B, feature_dim, H, W]."""
        uv = (uv * 2.0 - 1.0).permute(0, 2, 3, 1).contiguous()   # grid_sample layout [B,H,W,2]
        return F.grid_sample(self.grid.expand(uv.size(0), -1, -1, -1), uv,
                             mode="bilinear", padding_mode="border", align_corners=False)


def _tv_loss(grid):
    """Total-variation smoothness on a [1,C,H,W] grid (same shape as _env_map_smoothness_loss)."""
    dh = (grid[:, :, 1:, :] - grid[:, :, :-1, :]).pow(2).mean()
    dw = (grid[:, :, :, 1:] - grid[:, :, :, :-1]).pow(2).mean()
    return dh + dw


class NeuralTexExperiment(Experiment):
    NAME = "neural_tex"

    def __init__(self, neural_tex_dim=16, neural_tex_res=256, base_ch=16,
                 bottleneck_blocks=6, lambda_smooth=1e-4, phys_factored=False, halo=0, **kwargs):
        # **kwargs absorbs non-init keys written by config() (network/material_source/output_space/
        # aux_dim) so checkpoints reconstruct cleanly via experiment_from_checkpoint.
        super().__init__()
        self.neural_tex_dim = neural_tex_dim
        self.neural_tex_res = neural_tex_res
        # first 6 channels -> albedo(3)+coat_tint(3) for the backbone fusion; rest are aux input.
        self.aux_dim = max(neural_tex_dim - 6, 0)
        self.base_ch = base_ch
        self.bottleneck_blocks = bottleneck_blocks
        self.lambda_smooth = lambda_smooth
        self.phys_factored = phys_factored
        self.halo = halo

    @classmethod
    def from_args(cls, args):
        return cls(
            neural_tex_dim=getattr(args, "neural_tex_dim", 16),
            neural_tex_res=getattr(args, "neural_tex_res", 256),
            base_ch=args.base_ch,
            bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
        )

    @property
    def feature_spec(self):
        # HW format provides rgb_gt/uv/mask regardless; spec is empty (no G-Buffer, no PBR).
        return FeatureSpec()

    def _in_channels(self):
        return self.aux_dim   # the network input = the neural texture's aux channels

    def build_modules(self, device):
        network = UNetRadiance(
            in_channels=self._in_channels(),
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            phys_factored=self.phys_factored,
        ).to(device)
        neural_tex = NeuralTexture(feature_dim=self.neural_tex_dim, res=self.neural_tex_res).to(device)
        return {"network": network, "neural_tex": neural_tex}

    def forward(self, batch, modules, device):
        uv = batch["uv"].to(device, non_blocking=True)            # [B,2,H,W] in [0,1]
        feats = modules["neural_tex"].query(uv)                   # [B, neural_tex_dim, H, W]
        albedo = feats[:, 0:3]
        coat_tint = feats[:, 3:6]
        x = feats[:, 6:6 + self.aux_dim] if self.aux_dim > 0 else feats[:, 0:0]

        radiance = modules["network"](x, albedo, coat_tint)
        if self.halo > 0:
            ts = batch["rgb_gt"].shape[-1]
            h = self.halo
            radiance = radiance[..., h:h + ts, h:h + ts]
        self.last_radiance = radiance.detach()
        # HDR network output -> tonemap (linear->sRGB) -> clamp, so the loss is on the same tonemapped
        # LDR space as the GT image (Cycles renders HDR linear -> tonemapped -> sRGB PNG).
        return torch.clamp(linear_to_srgb(radiance), 0.0, 1.0)

    def compute_loss(self, pred, batch, modules, device):
        rgb_gt = batch["rgb_gt"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)
        l1 = self._criterion(pred, rgb_gt, mask)
        smooth = _tv_loss(modules["neural_tex"].grid)
        total = l1 + self.lambda_smooth * smooth
        return total, {"l1": l1.item(), "smooth": smooth.item()}

    def build_optimizer(self, modules, args):
        optimizer = torch.optim.AdamW([
            {"params": modules["network"].parameters(), "lr": args.lr_network,
             "weight_decay": args.weight_decay},
            {"params": modules["neural_tex"].parameters(), "lr": args.lr_env_map,
             "weight_decay": 0},
        ])
        eta_min = getattr(args, "lr_eta_min", 1e-6)
        warmup = getattr(args, "lr_warmup_epochs", 0)
        cosine = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(args.epochs - warmup, 1), eta_min=eta_min)
        if warmup > 0:
            warm = torch.optim.lr_scheduler.LinearLR(optimizer, start_factor=0.1, total_iters=warmup)
            scheduler = torch.optim.lr_scheduler.SequentialLR(optimizer, [warm, cosine], milestones=[warmup])
        else:
            scheduler = cosine
        return optimizer, scheduler

    def config(self):
        return {
            "network": "UNetRadiance",
            "material_source": "neural_texture_uv",
            "neural_tex_dim": self.neural_tex_dim,
            "neural_tex_res": self.neural_tex_res,
            "aux_dim": self.aux_dim,
            "base_ch": self.base_ch,
            "bottleneck_blocks": self.bottleneck_blocks,
            "phys_factored": self.phys_factored,
            "halo": self.halo,
            "output_space": "LDR",
        }
