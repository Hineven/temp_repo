"""
NeuralTexMRTNoNormReplicateExperiment — no-norm + replicate padding.

Combines the no-normalization benefit (no per-tile statistic drift) with replicate
padding (no zero-padding dark bias at tile boundaries) for the cleanest per-tile
inference result.
"""

from train_lighting.network import MultiResTransformerUNetRadianceNoNormReplicate
from train_lighting.experiments.neural_tex_mrt import NeuralTexMRTExperiment


class NeuralTexMRTNoNormReplicateExperiment(NeuralTexMRTExperiment):
    NAME = "neural_tex_mrt_nonorm_rep"

    def build_modules(self, device):
        mods = super(NeuralTexMRTExperiment, self).build_modules(device)
        mods["network"] = MultiResTransformerUNetRadianceNoNormReplicate(
            in_full=self._in_channels(),
            aux_half_ch=self.aux_half,
            aux_quarter_ch=self.aux_quarter,
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            num_transformer_blocks=self.num_transformer_blocks,
            attn_heads=self.attn_heads,
            attn_mlp_ratio=self.attn_mlp_ratio,
            phys_factored=self.phys_factored,
        ).to(device)
        return mods

    def config(self):
        return {
            **super().config(),
            "network": "MultiResTransformerUNetRadianceNoNormReplicate",
            "use_norm": False,
            "padding_mode": "replicate",
        }
