"""
NeuralTexMRTExperiment — neural_tex_mr + lightweight transformer bottleneck.

Replaces the last N bottleneck SepConvBlocks with IntraTileSelfAttention and uses
SepUpsample to keep the 1080p budget in the 10–30 GFLOP range. The multi-res
injection (aux_full/aux_half/aux_quarter) is unchanged.
"""

from train_lighting.network import MultiResTransformerUNetRadiance
from train_lighting.experiments.neural_tex_mr import NeuralTexMRExperiment


class NeuralTexMRTExperiment(NeuralTexMRExperiment):
    NAME = "neural_tex_mrt"

    def __init__(self, num_transformer_blocks=1, attn_heads=4, attn_mlp_ratio=2.0, **kwargs):
        super().__init__(**kwargs)
        self.num_transformer_blocks = num_transformer_blocks
        self.attn_heads = attn_heads
        self.attn_mlp_ratio = attn_mlp_ratio

    @classmethod
    def from_args(cls, args):
        aux_full = getattr(args, "aux_full", 8)
        aux_half = getattr(args, "aux_half", 4)
        aux_quarter = getattr(args, "aux_quarter", 4)
        neural_tex_dim = 6 + aux_full + aux_half + aux_quarter
        return cls(
            aux_full=aux_full, aux_half=aux_half, aux_quarter=aux_quarter,
            neural_tex_dim=neural_tex_dim,
            neural_tex_res=getattr(args, "neural_tex_res", 256),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
            num_transformer_blocks=getattr(args, "num_transformer_blocks", 1),
            attn_heads=getattr(args, "attn_heads", 4),
            attn_mlp_ratio=getattr(args, "attn_mlp_ratio", 2.0),
        )

    def build_modules(self, device):
        # reuse env maps / neural tex from parent, replace network
        mods = super().build_modules(device)
        mods["network"] = MultiResTransformerUNetRadiance(
            in_full=self._in_channels(),
            aux_half_ch=self.aux_half,
            aux_quarter_ch=self.aux_quarter,
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            num_transformer_blocks=self.num_transformer_blocks,
            attn_heads=self.attn_heads,
            attn_mlp_ratio=self.attn_mlp_ratio,
            phys_factored=self.phys_factored,
        ).to(device)
        return mods

    def config(self):
        return {
            **super().config(),
            "network": "MultiResTransformerUNetRadiance",
            "num_transformer_blocks": self.num_transformer_blocks,
            "attn_heads": self.attn_heads,
            "attn_mlp_ratio": self.attn_mlp_ratio,
        }
