"""
NeuralTexShallowCNNExperiment — 2-layer CNN with U-Net-style hierarchical feature injection.

Tests whether the deep encoder-bottleneck-decoder of the multi-res U-Net is necessary,
or if a very shallow 2-block CNN with multi-resolution aux injection and a skip
connection can match/beat a per-pixel MLP at the same FLOP budget.
"""

from train_lighting.network import ShallowTwoLayerUNetRadiance
from train_lighting.experiments.neural_tex_mr import NeuralTexMRExperiment


class NeuralTexShallowCNNExperiment(NeuralTexMRExperiment):
    NAME = "neural_tex_shallow_cnn"

    def __init__(self, base_ch=40, phys_factored=False, **kwargs):
        # NOTE: bottleneck_blocks / num_transformer_blocks are ignored by the shallow net,
        # but we keep them in kwargs for CLI compatibility.
        super().__init__(**kwargs)
        self.base_ch = base_ch
        self.phys_factored = phys_factored

    @classmethod
    def from_args(cls, args):
        aux_full = getattr(args, "aux_full", 8)
        aux_half = getattr(args, "aux_half", 4)
        aux_quarter = getattr(args, "aux_quarter", 4)
        neural_tex_dim = 6 + aux_full + aux_half + aux_quarter
        return cls(
            aux_full=aux_full, aux_half=aux_half, aux_quarter=aux_quarter,
            neural_tex_dim=neural_tex_dim,
            neural_tex_res=getattr(args, "neural_tex_res", 256),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
        )

    def build_modules(self, device):
        # Reuse neural_tex + env maps from the multi-res parent, replace network.
        mods = super(NeuralTexMRExperiment, self).build_modules(device)
        mods["network"] = ShallowTwoLayerUNetRadiance(
            in_full=self._in_channels(),
            aux_half_ch=self.aux_half,
            aux_quarter_ch=self.aux_quarter,
            base_ch=self.base_ch,
            phys_factored=self.phys_factored,
        ).to(device)
        return mods

    def config(self):
        return {
            **super().config(),
            "network": "ShallowTwoLayerUNetRadiance",
            "base_ch": self.base_ch,
        }
