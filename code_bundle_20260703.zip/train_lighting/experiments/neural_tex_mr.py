"""
NeuralTexMRExperiment — neural_tex_env + MULTI-RESOLUTION texture injection.

The neural-texture features are split across U-Net resolutions: a slice stays full-res (enc1, the
expensive 32² path); the rest are mean-pooled ×2 (→16², injected at dec2) and ×4 (→8², injected at
the bottleneck). This keeps the FLOP-dominant 32² path narrow while still delivering the full texture
feature budget at the appropriate (cheaper) levels. Backbone = MultiResUNetRadiance (new class).

Differentiable chain: uv -> neural_texture -> split [aux_full | aux_half_src | aux_quarter_src] ->
    aux_half = mean_pool(aux_half_src, 2), aux_quarter = mean_pool(aux_quarter_src, 4);
    x_full = [ndotv | env(normal) | env(reflection) | aux_full] -> enc1;
    aux_half -> dec2; aux_quarter -> bottleneck; -> UNetRadiance -> tonemap -> LDR.
"""

import torch
import torch.nn.functional as F

from train_lighting.network import MultiResUNetRadiance
from train_lighting.experiments.neural_tex_env import NeuralTexEnvExperiment
from train_lighting.experiments.neural_tex import _tv_loss


class NeuralTexMRExperiment(NeuralTexEnvExperiment):
    NAME = "neural_tex_mr"

    def __init__(self, aux_full=8, aux_half=4, aux_quarter=4, **kwargs):
        # neural_tex_dim must equal aux_full + aux_half + aux_quarter.
        super().__init__(**kwargs)
        self.aux_full = aux_full
        self.aux_half = aux_half
        self.aux_quarter = aux_quarter
        # reconcile: the parent's aux_dim is the TOTAL aux; here it is split three ways.
        assert self.aux_dim == aux_full + aux_half + aux_quarter, (
            f"neural_tex_dim-6 ({self.aux_dim}) must equal aux_full+aux_half+aux_quarter "
            f"({aux_full+aux_half+aux_quarter})")

    @classmethod
    def from_args(cls, args):
        aux_full = getattr(args, "aux_full", 8)
        aux_half = getattr(args, "aux_half", 4)
        aux_quarter = getattr(args, "aux_quarter", 4)
        # neural_tex_dim is DERIVED from the split (6 albedo/coat_tint + the three aux slices), so the
        # dims are always consistent — including the sweep's feature_spec pre-check (global args).
        neural_tex_dim = 6 + aux_full + aux_half + aux_quarter
        return cls(
            aux_full=aux_full, aux_half=aux_half, aux_quarter=aux_quarter,
            neural_tex_dim=neural_tex_dim,
            neural_tex_res=getattr(args, "neural_tex_res", 256),
            env_dim=args.env_dim, env_h=args.env_h, env_w=args.env_w,
            base_ch=args.base_ch, bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
        )

    def _in_channels(self):
        # enc1 (full-res) sees: ndotv + env(normal) + env(reflection) + aux_full (+ raw_geom if requested).
        return 1 + 2 * self.env_dim + self.aux_full + (6 if self.use_raw_geom else 0)

    def build_modules(self, device):
        mods = super().build_modules(device)   # neural_tex + env maps + (parent's UNet, replaced)
        mods["network"] = MultiResUNetRadiance(
            in_full=self._in_channels(),
            aux_half_ch=self.aux_half,
            aux_quarter_ch=self.aux_quarter,
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            phys_factored=self.phys_factored,
        ).to(device)
        return mods

    def _assemble_mr_inputs(self, batch, device, modules):
        uv = batch["uv"].to(device, non_blocking=True)
        feats = modules["neural_tex"].query(uv)
        albedo = feats[:, 0:3]
        coat_tint = feats[:, 3:6]
        aux = feats[:, 6:6 + self.aux_dim]
        a0 = self.aux_full
        a1 = a0 + self.aux_half
        aux_full = aux[:, 0:a0]
        aux_half = F.avg_pool2d(aux[:, a0:a1], 2)        # 32² -> 16²
        aux_quarter = F.avg_pool2d(aux[:, a1:a1 + self.aux_quarter], 4)  # -> 8²

        normal = batch["normal"].to(device, non_blocking=True)
        reflection_dir = batch["reflection_dir"].to(device, non_blocking=True)
        ndotv = batch["ndotv"].to(device, non_blocking=True)
        env_feat = modules["env_map"].query(normal.permute(0, 2, 3, 1))
        env_ref_feat = modules["env_ref_map"].query(reflection_dir.permute(0, 2, 3, 1))

        x_full = torch.cat([ndotv, env_feat, env_ref_feat, aux_full], dim=1)
        if self.use_raw_geom:
            x_full = torch.cat([x_full, normal, reflection_dir], dim=1)
        return x_full, aux_half, aux_quarter, albedo, coat_tint

    def forward(self, batch, modules, device):
        x_full, aux_half, aux_quarter, albedo, coat_tint = self._assemble_mr_inputs(batch, device, modules)
        radiance = modules["network"](x_full, aux_half, aux_quarter, albedo, coat_tint)
        if self.halo > 0:
            ts = batch["rgb_gt"].shape[-1]
            h = self.halo
            radiance = radiance[..., h:h + ts, h:h + ts]
        self.last_radiance = radiance.detach()
        from train_lighting.tonemap import linear_to_srgb
        return torch.clamp(linear_to_srgb(radiance), 0.0, 1.0)

    def compute_loss(self, pred, batch, modules, device):
        # same as neural_tex_env (masked-L1 + 3-grid smoothness)
        return super().compute_loss(pred, batch, modules, device)

    def config(self):
        return {
            **super().config(),
            "network": "MultiResUNetRadiance",
            "aux_full": self.aux_full, "aux_half": self.aux_half, "aux_quarter": self.aux_quarter,
            "multires_injection": True,
        }
