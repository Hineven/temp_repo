"""
Experiment registry.

Register new experiments here (or via register_experiment) so the CLI
(`python -m train_lighting.run --experiment <name>`) can find them.

    from train_lighting.experiments import register_experiment
    register_experiment("my_exp", MyExperiment)
"""

from train_lighting.experiments.base import (
    ALWAYS_PROVIDED,
    Experiment,
    FeatureSpec,
    GBufferChannel,
)
from train_lighting.experiments.baseline import BaselineExperiment
from train_lighting.experiments.gradloss import GradientLossExperiment
from train_lighting.experiments.light import LightExperiment
from train_lighting.experiments.richfeat import RichFeatureExperiment
from train_lighting.experiments.tile_pe import TilePEExperiment
from train_lighting.experiments.tile_dist import TileDistanceExperiment
from train_lighting.experiments.attention_bn import AttentionBottleneckExperiment
from train_lighting.experiments.tile_dist_attn import TileDistAttentionExperiment
from train_lighting.experiments.mixed_attn_bn import MixedAttentionBottleneckExperiment
from train_lighting.experiments.prt_light import PRTLightExperiment
from train_lighting.experiments.neural_tex import NeuralTexExperiment
from train_lighting.experiments.neural_tex_env import NeuralTexEnvExperiment
from train_lighting.experiments.neural_tex_mr import NeuralTexMRExperiment
from train_lighting.experiments.neural_tex_mrt import NeuralTexMRTExperiment
from train_lighting.experiments.neural_tex_mrt_nonorm import NeuralTexMRTNoNormExperiment
from train_lighting.experiments.neural_tex_mrt_nonorm_rep import NeuralTexMRTNoNormReplicateExperiment
from train_lighting.experiments.neural_tex_mlp import NeuralTexMLPExperiment
from train_lighting.experiments.neural_tex_env_attn import NeuralTexEnvAttentionExperiment
from train_lighting.experiments.neural_tex_shallow_cnn import NeuralTexShallowCNNExperiment


# name -> Experiment class
EXPERIMENT_REGISTRY: "dict[str, type[Experiment]]" = {
    "baseline": BaselineExperiment,
    "gradloss": GradientLossExperiment,
    "richfeat": RichFeatureExperiment,
    "light": LightExperiment,
    "tile_pe": TilePEExperiment,
    "tile_dist": TileDistanceExperiment,
    "attention_bn": AttentionBottleneckExperiment,
    "tile_dist_attn": TileDistAttentionExperiment,
    "mixed_attn_bn": MixedAttentionBottleneckExperiment,
    "prt_light": PRTLightExperiment,
    "neural_tex": NeuralTexExperiment,
    "neural_tex_env": NeuralTexEnvExperiment,
    "neural_tex_env_attn": NeuralTexEnvAttentionExperiment,
    "neural_tex_mr": NeuralTexMRExperiment,
    "neural_tex_mrt": NeuralTexMRTExperiment,
    "neural_tex_mrt_nonorm": NeuralTexMRTNoNormExperiment,
    "neural_tex_mrt_nonorm_rep": NeuralTexMRTNoNormReplicateExperiment,
    "neural_tex_mlp": NeuralTexMLPExperiment,
    "neural_tex_shallow_cnn": NeuralTexShallowCNNExperiment,
}


def register_experiment(name: str, cls: "type[Experiment]"):
    """Add (or replace) an experiment class in the registry."""
    if not issubclass(cls, Experiment):
        raise TypeError(f"{cls} is not an Experiment subclass")
    EXPERIMENT_REGISTRY[name] = cls


def get_experiment_class(name: str) -> "type[Experiment]":
    if name not in EXPERIMENT_REGISTRY:
        raise KeyError(
            f"Unknown experiment '{name}'. Available: {list(EXPERIMENT_REGISTRY)}"
        )
    return EXPERIMENT_REGISTRY[name]


def list_experiments() -> "list[str]":
    return sorted(EXPERIMENT_REGISTRY.keys())


__all__ = [
    "EXPERIMENT_REGISTRY",
    "register_experiment",
    "get_experiment_class",
    "list_experiments",
    "Experiment",
    "FeatureSpec",
    "GBufferChannel",
    "ALWAYS_PROVIDED",
    "BaselineExperiment",
    "GradientLossExperiment",
    "RichFeatureExperiment",
]
