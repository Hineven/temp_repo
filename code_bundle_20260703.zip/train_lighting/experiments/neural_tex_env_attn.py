"""
NeuralTexEnvAttentionExperiment — neural_tex + env maps, but with the UNet bottleneck
replaced by intra-tile self-attention.

This is the neural-texture analogue of attention_bn / mixed_attn_bn: it keeps the
same input assembly and loss as NeuralTexEnvExperiment, but swaps UNetRadiance for
AttentionBottleneckUNetRadiance so we can compare a U-Net+Transformer backbone vs
the plain U-Net (neural_tex_env) and the pure MLP (neural_tex_mlp) on HW datasets.
"""

from train_lighting.network import NeuralEnvMap, AttentionBottleneckUNetRadiance
from train_lighting.experiments.neural_tex_env import NeuralTexEnvExperiment


class NeuralTexEnvAttentionExperiment(NeuralTexEnvExperiment):
    NAME = "neural_tex_env_attn"

    def __init__(self, attn_heads=4, attn_mlp_ratio=2.0, **kwargs):
        super().__init__(**kwargs)
        self.attn_heads = attn_heads
        self.attn_mlp_ratio = attn_mlp_ratio

    @classmethod
    def from_args(cls, args):
        return cls(
            neural_tex_dim=getattr(args, "neural_tex_dim", 16),
            neural_tex_res=getattr(args, "neural_tex_res", 256),
            env_dim=args.env_dim,
            env_h=args.env_h,
            env_w=args.env_w,
            base_ch=args.base_ch,
            bottleneck_blocks=args.bottleneck_blocks,
            lambda_smooth=args.lambda_smooth,
            use_raw_geom=getattr(args, "use_raw_geom", False),
            phys_factored=getattr(args, "phys_factored", False),
            halo=getattr(args, "halo", 0),
            attn_heads=getattr(args, "attn_heads", 4),
            attn_mlp_ratio=getattr(args, "attn_mlp_ratio", 2.0),
        )

    def build_modules(self, device):
        # Start from the neural_tex_env setup (neural_tex + env maps), then swap the network.
        mods = super().build_modules(device)
        mods["network"] = AttentionBottleneckUNetRadiance(
            in_channels=self._in_channels(),
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            phys_factored=self.phys_factored,
            attn_heads=self.attn_heads,
            attn_mlp_ratio=self.attn_mlp_ratio,
        ).to(device)
        return mods

    def config(self):
        return {
            **super().config(),
            "attn_heads": self.attn_heads,
            "attn_mlp_ratio": self.attn_mlp_ratio,
        }
