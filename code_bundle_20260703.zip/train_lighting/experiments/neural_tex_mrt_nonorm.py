"""
NeuralTexMRTNoNormExperiment — neural_tex_mrt WITHOUT GroupNorm.

Per-tile normalization can cause visible brightness seams between tiles because each tile
computes its own statistics. This experiment removes all normalization from the conv and
attention blocks, making the network purely feed-forward and more consistent across tiles.
"""

from train_lighting.network import MultiResTransformerUNetRadianceNoNorm
from train_lighting.experiments.neural_tex_mrt import NeuralTexMRTExperiment


class NeuralTexMRTNoNormExperiment(NeuralTexMRTExperiment):
    NAME = "neural_tex_mrt_nonorm"

    def build_modules(self, device):
        mods = super(NeuralTexMRTExperiment, self).build_modules(device)
        mods["network"] = MultiResTransformerUNetRadianceNoNorm(
            in_full=self._in_channels(),
            aux_half_ch=self.aux_half,
            aux_quarter_ch=self.aux_quarter,
            base_ch=self.base_ch,
            bottleneck_blocks=self.bottleneck_blocks,
            num_transformer_blocks=self.num_transformer_blocks,
            attn_heads=self.attn_heads,
            attn_mlp_ratio=self.attn_mlp_ratio,
            phys_factored=self.phys_factored,
        ).to(device)
        return mods

    def config(self):
        return {**super().config(), "network": "MultiResTransformerUNetRadianceNoNorm", "use_norm": False}
