"""
In-memory tile dataset with shared memory for fast multi-worker training.

Pure data layer. Given a FeatureSpec, it loads the requested G-Buffer channels,
decodes/normalizes them, computes the geometric primitives that require camera
intrinsics (ndotv, reflection_dir), and hands each channel to the experiment as
its own batch key. Feature SELECTION and ASSEMBLY (which channels to concatenate
into the network input) is the experiment's job — see train_lighting.experiments.

All data loaded once at startup, pre-chopped into tiles, stored as shared tensors.
Training has zero disk I/O overhead.
"""

import json
import random
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tqdm import tqdm

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader

from train_lighting.utils import compute_view_direction_map
from train_lighting.experiments.base import ALWAYS_PROVIDED, FeatureSpec

DATASET_DIR = Path(__file__).parent.parent / "dataset"
TILE_SIZE = 32

# PNG file stems that are always loaded (needed by loss / fusion / mask),
# independent of FeatureSpec. mask is derived from albedo, not loaded.
_ALWAYS_FILES = ["albedo", "normal", "coat_tint", "rgb"]


def _load_png_float32(path):
    """Load PNG and return as float32 [0, 1]."""
    img = Image.open(str(path))
    return np.array(img, dtype=np.float32) / 255.0


def _tile_array(arr, tile_h, tile_w):
    """
    View array as tiled blocks [ny, nx, tile_h, tile_w, ...].
    Uses stride tricks — no data copy.
    """
    h, w = arr.shape[:2]
    assert h % tile_h == 0 and w % tile_w == 0
    ny, nx = h // tile_h, w // tile_w
    new_shape = (ny, tile_h, nx, tile_w) + arr.shape[2:]
    new_strides = (arr.strides[0] * tile_h, arr.strides[0],
                   arr.strides[1] * tile_w, arr.strides[1]) + arr.strides[2:]
    tiled = np.lib.stride_tricks.as_strided(arr, shape=new_shape, strides=new_strides)
    # [ny, tile_h, nx, tile_w, ...] -> [ny, nx, tile_h, tile_w, ...]
    return tiled.transpose(0, 2, 1, 3, *tuple(range(4, 4 + len(arr.shape[2:]))))


def _tile_chw(arr, tile_h, tile_w, idx=None):
    """Tile a [H,W,C] array into [ny,nx,C,ts,ts].

    If idx is given, take only that channel (result [ny,nx,1,ts,ts]).
    """
    tiled = _tile_array(arr, tile_h, tile_w)  # [ny,nx,ts,ts,C]
    if idx is not None:
        tiled = tiled[..., idx:idx + 1]  # [ny,nx,ts,ts,1]
    return np.ascontiguousarray(tiled.transpose(0, 1, 4, 2, 3))  # [ny,nx,C,ts,ts]


def _tile_chw_halo(arr, tile_size, halo):
    """Tile a [H,W,C] (or [H,W]) array into [ny,nx,C,full_ts,full_ts] with a halo of neighbor
    pixels around each tile (zero-padded at the image border).

    full_ts = tile_size + 2*halo. Window i covers original rows [i*ts - halo : i*ts + ts + halo];
    off-image regions are zero (from the pad), so border tiles see zeros where they have no
    neighbor — exactly the overlap-inference halo.

    Layout matches _tile_chw ([ny,nx,C,ts,ts]) so halo and non-halo channels index identically.
    Vectorized via sliding_window_view on the zero-padded array (no Python tile loop).
    """
    full_ts = tile_size + 2 * halo
    padspec = [(halo, halo), (halo, halo)] + [(0, 0)] * (arr.ndim - 2)
    padded = np.pad(arr, padspec, mode="constant")  # zero-pad all sides
    # windows over (H,W) axes; trailing axes (C) kept -> [H', W', C, full_ts, full_ts]
    windows = np.lib.stride_tricks.sliding_window_view(
        padded, window_shape=(full_ts, full_ts), axis=(0, 1)
    )
    # one window per logical tile (stride = tile_size)
    tiled = windows[::tile_size, ::tile_size]  # [ny, nx, C, full_ts, full_ts]
    return np.ascontiguousarray(tiled)


def _load_view_raw(view_dir, feature_spec: FeatureSpec | None = None):
    """
    Load one view's raw G-Buffer + geometric primitives at full resolution.

    Pure data loading: PNGs -> decoded channels + camera-derived primitives.
    No tiling, no stacking. Shared by the tile dataset (training) and the
    single-view eval dataset.

    Returns:
        dict mapping channel name -> [H, W, C] float32 (C=1 for scalars, 3 for
        vectors). Keys:
            - one per feature_spec.base_channels[i].name   (scalar, C=1)
            - 'ndotv'        (C=1)            if feature_spec.compute_ndotv
            - 'reflection_dir' (C=3)          if feature_spec.compute_reflection
            - 'view_dir'     (C=3)            if feature_spec.compute_view_dir
            - always: 'normal', 'albedo', 'coat_tint', 'rgb_gt', 'mask'
    """
    view_dir = Path(view_dir)
    assert feature_spec is not None, "feature_spec is required"

    # Camera / metadata
    with open(view_dir / "metadata.json") as f:
        meta = json.load(f)
    cam = meta["camera"]
    cam_pos = np.array(cam["location"], dtype=np.float32)
    cam_rot = cam["rotation_euler"]
    fov = cam["fov"]

    # Determine which PNG files are needed, load each once.
    needed_files = set(c.file for c in feature_spec.base_channels)
    needed_files.update(_ALWAYS_FILES)

    raw = {}
    for stem in needed_files:
        raw[stem] = _load_png_float32(view_dir / f"{stem}.png")

    albedo = raw["albedo"]
    normal_png = raw["normal"]
    coat_t = raw["coat_tint"]
    rgb = raw["rgb"]
    h, w = albedo.shape[:2]

    # Decode world-space normal [H,W,3] in [-1,1], normalized
    normal = normal_png * 2.0 - 1.0
    norm = np.linalg.norm(normal, axis=2, keepdims=True)
    normal = normal / (norm + 1e-8)

    # Mask from albedo (background = [0,0,0])
    mask = (np.sum(albedo, axis=2, keepdims=True) > 0).astype(np.float32)

    # Geometric primitives that require camera intrinsics (computed here because
    # the experiment only sees per-tile tensors, not camera params).
    view_dir_map = None
    ndotv = None
    reflection_dir = None
    if feature_spec.compute_ndotv or feature_spec.compute_reflection or feature_spec.compute_view_dir:
        view_dir_map = compute_view_direction_map(cam_pos, cam_rot, fov, h, w)
    if feature_spec.compute_ndotv:
        ndotv = np.sum(normal * view_dir_map, axis=2, keepdims=True)
        ndotv = np.clip(ndotv, 0.0, 1.0)
    if feature_spec.compute_reflection:
        if ndotv is None:
            ndotv_tmp = np.clip(np.sum(normal * view_dir_map, axis=2, keepdims=True), 0, 1)
        else:
            ndotv_tmp = ndotv
        reflection_dir = 2.0 * ndotv_tmp * normal - view_dir_map
        rnorm = np.linalg.norm(reflection_dir, axis=2, keepdims=True)
        reflection_dir = reflection_dir / (rnorm + 1e-8)

    # ---- assemble full-res channels (each [H,W,C]) ----
    out = {}

    for ch in feature_spec.base_channels:
        out[ch.name] = raw[ch.file][..., ch.channel:ch.channel + 1]  # [H,W,1]

    if ndotv is not None:
        out["ndotv"] = ndotv
    if reflection_dir is not None:
        out["reflection_dir"] = reflection_dir
    if feature_spec.compute_view_dir:
        out["view_dir"] = view_dir_map  # [H,W,3] unit vector (world space)

    out["normal"] = normal
    out["albedo"] = albedo
    out["coat_tint"] = coat_t
    out["rgb_gt"] = rgb
    out["mask"] = mask

    return out


def _load_view_tiled(view_dir, tile_size=TILE_SIZE, halo=0,
                     feature_spec: FeatureSpec | None = None):
    """
    Load a single view and return tiled channel arrays (flat dict, no stacking).

    Returns:
        dict mapping channel name -> tiled float32 array, plus:
            'valid': [ny, nx] bool — tiles containing any object pixel (center tile).

    Spatial size per channel:
        feature channels (all except rgb_gt/mask): [ny,nx,C, ts+2*halo, ts+2*halo]
            (overlap-inference halo; zero-padded at the image border)
        rgb_gt / mask: [ny,nx,C, ts, ts]   (center only — the loss/metric target)

    Keys produced: see _load_view_raw.
    """
    raw = _load_view_raw(view_dir, feature_spec)

    out = {}
    for name, arr in raw.items():
        if halo > 0 and name not in ("rgb_gt", "mask"):
            out[name] = _tile_chw_halo(arr, tile_size, halo)  # [ny,nx,C,ts+2h,ts+2h]
        else:
            out[name] = _tile_chw(arr, tile_size, tile_size)  # [ny,nx,C,ts,ts]

    # valid: any object pixel in the (center) tile
    mask_t = _tile_array(raw["mask"], tile_size, tile_size)  # [ny,nx,ts,ts,1]
    out["valid"] = mask_t.sum(axis=(2, 3, 4)) > 0            # [ny,nx] bool

    return out


class InMemoryTileDataset(Dataset):
    """
    Fully in-memory tile dataset with shared memory support.

    All data loaded once at startup via parallel workers.
    Stored as shared tensors so DataLoader workers don't duplicate data.
    """

    def __init__(self, dataset_dir=None, split='train', load_workers=8, seed=42,
                 feature_spec: FeatureSpec | None = None, device='cpu', halo=0):
        """
        Args:
            dataset_dir:  path to dataset root
            split:        'train' or 'val'
            load_workers: number of parallel workers for initial loading
            seed:         random seed for shuffling
            feature_spec: which channels to load (REQUIRED)
            device:       'cpu' (default; shared-memory, any num_workers) or 'cuda'
                          (keep all tiles resident on the GPU — eliminates per-batch
                          host->device transfer & collation; requires num_workers=0 and
                          the dataset fitting in VRAM; big speedup for small datasets).
            halo:         overlap-inference halo pixels per tile side. Feature channels are
                          cut at (tile+2*halo)² (neighbor context, zero-padded at the image
                          border); rgb_gt/mask stay at tile² (center). 0 = no overlap.
        """
        if feature_spec is None:
            raise ValueError("feature_spec is required")
        self.feature_spec = feature_spec
        self.device = device
        self.halo = halo
        self.dataset_dir = Path(dataset_dir) if dataset_dir else DATASET_DIR
        self.split = split

        # Keys = requested scalar channels + geometric primitives + always-provided
        self.KEYS = (
            [c.name for c in feature_spec.base_channels]
            + (["ndotv"] if feature_spec.compute_ndotv else [])
            + (["reflection_dir"] if feature_spec.compute_reflection else [])
            + (["view_dir"] if feature_spec.compute_view_dir else [])
            + list(ALWAYS_PROVIDED)
        )

        # 1. Split views by view (not by tile)
        all_views = sorted(self.dataset_dir.glob("*/*/view_*"))
        random.Random(seed).shuffle(all_views)

        n_train = int(len(all_views) * 0.9)
        train_views = all_views[:n_train]
        val_views = all_views[n_train:]

        views = train_views if split == 'train' else val_views
        print(f"[{split}] {len(views)} views to load...")

        # 2. Parallel load + extract valid tiles (streaming, low memory)
        t0 = time.time()
        parts = self._load_and_extract_parallel(views, load_workers)
        load_time = time.time() - t0

        # 3. Concatenate into big tensors
        t0 = time.time()
        self.data = {}
        for key in self.KEYS:
            self.data[key] = torch.from_numpy(np.concatenate(parts[key], axis=0))
            parts[key] = None  # free
        stack_time = time.time() - t0
        del parts

        print(f"[{split}] Loaded {len(self)} tiles "
              f"(load={load_time:.1f}s, stack={stack_time:.1f}s, "
              f"total={load_time + stack_time:.1f}s)")

        # 4. Shuffle
        rng = np.random.RandomState(seed if split == 'train' else seed + 1)
        perm = rng.permutation(len(self))
        for key in self.KEYS:
            self.data[key] = self.data[key][perm]

        # 5. Place the data: shared CPU memory (multi-worker) or resident on GPU (no transfer)
        if self.device == 'cpu':
            for key in self.KEYS:
                self.data[key].share_memory_()
        else:
            dev = torch.device(self.device)
            for key in self.KEYS:
                self.data[key] = self.data[key].to(dev, non_blocking=True)

        mem_gb = sum(v.numel() * v.element_size() for v in self.data.values()) / 1e9
        where = self.device
        print(f"[{split}] Dataset ready: {len(self)} tiles, ~{mem_gb:.2f} GB [{where}]")

        # 6. Augmentation (mutable; flipped on for the train split by the runner)
        self.augment = False

    def _load_and_extract_parallel(self, views, n_workers):
        """Load all views in parallel, extract valid tiles immediately (streaming).

        Uses chunked submission to bound memory: only `chunk_size` futures are
        in-flight at once, so at most chunk_size + n_workers tiled arrays live
        in memory simultaneously.
        """
        import gc

        parts = {key: [] for key in self.KEYS}
        chunk_size = n_workers * 4  # bound in-flight futures

        with ThreadPoolExecutor(max_workers=n_workers) as executor:
            for chunk_start in tqdm(range(0, len(views), chunk_size),
                                    total=(len(views) + chunk_size - 1) // chunk_size,
                                    desc=f"Loading {self.split} chunks", unit="chunk"):
                chunk_views = views[chunk_start:chunk_start + chunk_size]
                futures = [
                    executor.submit(_load_view_tiled, v, TILE_SIZE, self.halo, self.feature_spec)
                    for v in chunk_views
                ]

                for f in futures:
                    vr = f.result()
                    valid = vr['valid']
                    if valid.sum() == 0:
                        del vr
                        continue
                    for key in self.KEYS:
                        parts[key].append(vr[key][valid])
                    del vr

                del futures
                gc.collect()

        return parts

    def __len__(self):
        return self.data['mask'].size(0)

    @staticmethod
    def _hflip(sample):
        """Horizontal-flip augmentation, geometrically consistent for world-space vectors.

        Flips the W axis of every channel; for world-space direction vectors (normal,
        reflection_dir) also negates the x-component (channel 0), because mirroring the
        image inverts the horizontal axis of the scene. ndotv is a scalar dot product and
        is invariant under the simultaneous x-negation of N and V, so it needs no negation.
        This yields a valid (flipped G-Buffer -> flipped shading) pair.
        """
        out = {}
        for k, t in sample.items():
            tf = t.flip(-1).contiguous()  # [C,H,W] spatial hflip
            if k in ("normal", "reflection_dir"):
                tf[0] = -tf[0]  # negate x-component
            out[k] = tf
        return out

    def __getitem__(self, idx):
        sample = {k: v[idx] for k, v in self.data.items()}
        if getattr(self, 'augment', False) and random.random() < 0.5:
            sample = self._hflip(sample)
        return sample


def build_dataloaders(dataset_dir=None, batch_size=1024, num_workers=4,
                      load_workers=8, seed=42, feature_spec: FeatureSpec | None = None,
                      device='cpu', halo=0):
    """
    Build train/val loaders with in-memory datasets.

    device='cpu'  -> DataLoader (shared-memory tiles, any num_workers).
    device='cuda' -> GPUBatchIterator: tiles resident on GPU, each batch fetched with ONE
                     fancy-index per key (skips the DataLoader's per-sample __getitem__/collation,
                     which dominates runtime for small datasets) + vectorized on-GPU hflip augment.
    halo:          overlap-inference halo pixels per tile side (see InMemoryTileDataset).
    """
    if feature_spec is None:
        raise ValueError("feature_spec is required")
    dataset_dir = Path(dataset_dir) if dataset_dir else DATASET_DIR

    # Format dispatch: the HW_DATASET format (images/ + mesh.ply + transforms_*.json) has its own
    # loader; the legacy G-Buffer format (*/view_*) uses the in-memory tile dataset below.
    if (dataset_dir / "transforms_all.json").exists():
        from train_lighting.dataset_hw import build_dataloaders_hw
        return build_dataloaders_hw(dataset_dir=str(dataset_dir), batch_size=batch_size,
                                    num_workers=num_workers, load_workers=load_workers, seed=seed,
                                    feature_spec=feature_spec, device=device, halo=halo)

    # Dataset ALWAYS in CPU shared memory (never VRAM — avoids OOM on large datasets).
    print("=== Loading datasets into memory [cpu] ===")
    train_ds = InMemoryTileDataset(dataset_dir, split='train', load_workers=load_workers,
                                   seed=seed, feature_spec=feature_spec, device='cpu', halo=halo)
    val_ds = InMemoryTileDataset(dataset_dir, split='val', load_workers=load_workers,
                                 seed=seed, feature_spec=feature_spec, device='cpu', halo=halo)

    # BatchIterator fancy-indexes batches from CPU RAM; if device='cuda' it PREFETCHES batches to
    # VRAM in a background thread (overlapping with GPU compute). Only 1-2 transient batches in
    # VRAM — the full dataset stays in system RAM. device='cpu' = no prefetch (batches stay CPU).
    train_loader = BatchIterator(train_ds, batch_size, shuffle=True, drop_last=True, device=device)
    val_loader = BatchIterator(val_ds, batch_size, shuffle=False, drop_last=False, device=device)

    return train_loader, val_loader


class BatchIterator:
    """Iterate in-memory tiles by fancy-indexing whole batches (one op per channel per batch),
    bypassing DataLoader's per-sample __getitem__/collation — the dominant overhead for small
    in-memory datasets. Device-agnostic: indexes wherever the data lives (CPU RAM or GPU VRAM).
    Reads ``dataset.augment`` each epoch and applies vectorized horizontal flip. Quacks like a
    DataLoader (__iter__, __len__)."""

    def __init__(self, dataset, batch_size, shuffle=True, drop_last=True, device='cpu'):
        self.dataset = dataset
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.drop_last = drop_last
        self.device = device

    def __len__(self):
        n = len(self.dataset)
        return n // self.batch_size if self.drop_last else \
            (n + self.batch_size - 1) // self.batch_size

    def _make_batch(self, idx):
        """Fancy-index one batch from the (CPU-resident) dataset, augment if enabled, move to device."""
        batch = {k: v[idx] for k, v in self.dataset.data.items()}
        if getattr(self.dataset, 'augment', False):
            batch = self._augment_batch(batch)
        if self.device != 'cpu':
            batch = {k: v.to(self.device, non_blocking=True) for k, v in batch.items()}
        return batch

    def __iter__(self):
        n, bs = len(self.dataset), self.batch_size
        perm = torch.randperm(n) if self.shuffle else torch.arange(n)
        end = (n // bs) * bs if self.drop_last else n
        indices = [perm[i:i + bs] for i in range(0, end, bs)]

        if self.device == 'cpu':
            for idx in indices:
                yield self._make_batch(idx)
            return

        # Prefetch: a background thread prepares batches (fancy-index + H2D transfer) while the
        # GPU computes the current one. Dataset stays in CPU RAM; only 1-2 batches live in VRAM.
        import queue, threading
        q = queue.Queue(maxsize=2)

        def producer():
            for idx in indices:
                q.put(self._make_batch(idx))
            q.put(None)

        t = threading.Thread(target=producer, daemon=True)
        t.start()
        try:
            while True:
                batch = q.get()
                if batch is None:
                    break
                yield batch
        finally:
            t.join(timeout=5)

    @staticmethod
    def _augment_batch(batch, p=0.5):
        """Per-batch horizontal flip (one flip decision per batch — cheap on CPU). Each sample
        still sees ~50% flipped batches across epochs. Negates x-channel of normal & reflection_dir."""
        if random.random() < p:
            out = {}
            for k, t in batch.items():
                tf = t.flip(-1).contiguous()
                if k in ("normal", "reflection_dir"):
                    tf[:, 0] = -tf[:, 0]
                out[k] = tf
            return out
        return batch
