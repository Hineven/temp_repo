"""
HW_DATASET-format in-memory tile dataset.

Self-contained HW format: images/ + mesh.ply + transforms_*.json. There is NO precomputed raster
data and NO G-Buffer. At load time, each view's per-pixel UV coord map (+ coverage mask) is
rasterized ON THE FLY from mesh.ply + the frame's camera transform with nvdiffrast, stored in
memory, then run through the same pre-tile (32x32) pipeline as the legacy dataset.

Per-view channels provided (the minimum the neural-texture pipeline needs):
    rgb_gt : the tonemapped LDR image (loss target)
    uv     : per-pixel UV coord map [0,1]^2 (samples the learnable neural texture)
    mask   : object coverage (masks the loss)

Material / PBR attributes are intentionally absent — they come from the learnable neural texture
in the experiment's forward(), not from data. nvdiffrast runs on the GPU; its calls are serialized
by a lock so the surrounding PNG decode + tiling still parallelizes across load workers.
"""

import json
import math
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
import torch
import nvdiffrast.torch as dr
from PIL import Image
from tqdm import tqdm

from train_lighting.dataset import TILE_SIZE, _tile_chw, _tile_chw_halo, BatchIterator
from train_lighting.experiments.base import FeatureSpec
from rasterize_hw import load_mesh, rasterize_views_batched

DATASET_DIR = Path(__file__).resolve().parent.parent / "dataset_hw_71"

# nvdiffrast uses one process-wide CUDA context; serialize its (batched) calls across load threads.
_GPU_LOCK = threading.Lock()

# Always-provided channels (the minimal neural_tex case). Material is the neural texture.
HW_ALWAYS = ["rgb_gt", "uv", "mask"]


def _load_png_float32(path):
    return np.array(Image.open(str(path)).convert("RGB"), dtype=np.float32) / 255.0


def _view_directions_from_c2w(cam2world, fov_deg, h, w):
    """Per-pixel world-space camera->pixel ray, identical to utils.compute_view_direction_map.
    cam2world columns are the camera's world axes (X right, Y up, -Z forward)."""
    col0, col1, col2 = cam2world[:3, 0], cam2world[:3, 1], cam2world[:3, 2]
    tan = math.tan(math.radians(fov_deg) / 2.0)
    u = np.arange(w, dtype=np.float32) + 0.5
    v = np.arange(h, dtype=np.float32) + 0.5
    x = (2.0 * u / w - 1.0) * tan
    y = (1.0 - 2.0 * v / h) * tan
    xs, ys = np.meshgrid(x, y, indexing="xy")
    ray = (xs[..., None] * col0 + ys[..., None] * col1 - col2).astype(np.float32)
    ray /= (np.linalg.norm(ray, axis=2, keepdims=True) + 1e-8)
    return ray


def _hw_keys(feature_spec):
    """Channel keys: always-provided + geometry primitives the experiment asks for (via feature_spec).
    The env-map variants need normal (for env_map) + reflection_dir (for env_ref_map), which require
    compute_reflection; ndotv comes along for the same reason as the legacy loader."""
    keys = list(HW_ALWAYS)
    if feature_spec.compute_ndotv or feature_spec.compute_reflection or feature_spec.compute_view_dir:
        keys.append("normal")
    if feature_spec.compute_ndotv:
        keys.append("ndotv")
    if feature_spec.compute_reflection:
        keys.append("reflection_dir")
    if feature_spec.compute_view_dir:
        keys.append("view_dir")
    return keys


def _load_chunk_tiled_hw(hw_dir, view_idxs, cam2worlds, fov_deg, res, mesh, ctx,
                         tile_size, halo, feature_spec, convention="opengl"):
    """Load + rasterize + tile one chunk of views. Rasterization is BATCHED (one nvdiffrast call for
    the whole chunk) under the GPU lock; PNG decode + geometry + tiling run on the calling thread."""
    hw_dir = Path(hw_dir)
    verts, faces, uvs, normals = mesh
    need_geom = (feature_spec.compute_ndotv or feature_spec.compute_reflection
                 or feature_spec.compute_view_dir)
    # 1. PNG decode (CPU, per view)
    rgbs = [_load_png_float32(hw_dir / "images" / f"{vi:04d}_0001.png") for vi in view_idxs]
    # 2. batched rasterize (GPU, one call for the whole chunk) — gives uv + normal + mask per view
    with _GPU_LOCK:
        raster = rasterize_views_batched(ctx, verts, faces, uvs, normals, cam2worlds,
                                          fov_deg, res, 1.0, 0.05, 20.0,
                                          convention=convention)
    # 3. per-view geometry + tile
    results = []
    for rgb, c2w, (uv, normal, mask) in zip(rgbs, cam2worlds, raster):
        rgb_gt = rgb
        uv = uv.astype(np.float32)
        normal = normal.astype(np.float32)
        mask = mask.astype(np.float32)[..., None]
        raw = {"rgb_gt": rgb_gt, "uv": uv, "mask": mask}
        if need_geom:
            h, w = mask.shape[:2]
            view_dir = _view_directions_from_c2w(c2w, fov_deg, h, w)
            ndotv = np.clip(np.sum(normal * view_dir, axis=2, keepdims=True), 0.0, 1.0)
            if "normal" in _hw_keys(feature_spec):
                raw["normal"] = normal
            if feature_spec.compute_ndotv:
                raw["ndotv"] = ndotv
            if feature_spec.compute_reflection:
                refl = 2.0 * ndotv * normal - view_dir
                refl /= (np.linalg.norm(refl, axis=2, keepdims=True) + 1e-8)
                raw["reflection_dir"] = refl
            if feature_spec.compute_view_dir:
                raw["view_dir"] = view_dir
        out = {}
        for name, arr in raw.items():
            if halo > 0 and name not in ("rgb_gt", "mask"):
                out[name] = _tile_chw_halo(arr, tile_size, halo)
            else:
                out[name] = _tile_chw(arr, tile_size, tile_size)
        mask_t = _tile_chw(raw["mask"], tile_size, tile_size)
        out["valid"] = mask_t.sum(axis=(2, 3, 4)) > 0
        results.append(out)
    return results


class InMemoryTileDatasetHW:
    """In-memory tile dataset for the HW format. Mirrors InMemoryTileDataset semantics."""

    def __init__(self, hw_dir, split="train", load_workers=8, seed=42,
                 feature_spec=None, device="cpu", halo=0, res=1024, convention="opengl"):
        # feature_spec accepted for signature parity with the legacy loader; the HW format ignores
        # its contents (it has no G-Buffer to select — UV/rgb_gt/mask are always provided).
        self.feature_spec = feature_spec
        self.device = device
        self.halo = halo
        self.res = res
        self.convention = convention
        self.hw_dir = Path(hw_dir)
        self.split = split
        self.KEYS = _hw_keys(feature_spec) if feature_spec is not None else list(HW_ALWAYS)

        # Mesh + cameras loaded once; UV/mask rasterized per view on the fly.
        self.mesh = load_mesh(self.hw_dir / "mesh.ply")
        self.ctx = dr.RasterizeCudaContext(device=torch.device("cuda"))
        all_doc = json.loads((self.hw_dir / "transforms_all.json").read_text())
        self.fov_deg = math.degrees(all_doc["camera_angle_x"])
        self.cam2world = [np.array(f["transform_matrix"], dtype=np.float32) for f in all_doc["frames"]]
        split_doc = json.loads((self.hw_dir / f"transforms_{split}.json").read_text())
        view_idxs = [int(f["file_path"].split("/")[-1].split("_")[0]) for f in split_doc["frames"]]
        random.Random(seed).shuffle(view_idxs)
        print(f"[hw {split}] {len(view_idxs)} views (UV rasterized on-the-fly, convention={convention})")

        t0 = time.time()
        parts = self._load_and_extract_parallel(view_idxs, load_workers)
        load_time = time.time() - t0

        t0 = time.time()
        self.data = {}
        for key in self.KEYS:
            self.data[key] = torch.from_numpy(np.concatenate(parts[key], axis=0))
            parts[key] = None
        del parts
        stack_time = time.time() - t0
        print(f"[hw {split}] {len(self)} tiles (load={load_time:.1f}s stack={stack_time:.1f}s)")

        rng = np.random.RandomState(seed if split == "train" else seed + 1)
        perm = rng.permutation(len(self))
        for key in self.KEYS:
            self.data[key] = self.data[key][perm]

        if self.device == "cpu":
            for key in self.KEYS:
                self.data[key].share_memory_()
        else:
            dev = torch.device(self.device)
            for key in self.KEYS:
                self.data[key] = self.data[key].to(dev, non_blocking=True)

        mem_gb = sum(v.numel() * v.element_size() for v in self.data.values()) / 1e9
        print(f"[hw {split}] ready: {len(self)} tiles ~{mem_gb:.2f}GB [{self.device}]")
        self.augment = False

    def _load_and_extract_parallel(self, view_idxs, n_workers):
        import gc
        parts = {key: [] for key in self.KEYS}
        chunk_size = n_workers * 4
        chunks = [view_idxs[cs:cs + chunk_size] for cs in range(0, len(view_idxs), chunk_size)]

        def process_chunk(chunk):
            c2w = [self.cam2world[vi] for vi in chunk]
            return _load_chunk_tiled_hw(self.hw_dir, chunk, c2w, self.fov_deg, self.res,
                                        self.mesh, self.ctx, TILE_SIZE, self.halo, self.feature_spec,
                                        convention=self.convention)

        with ThreadPoolExecutor(max_workers=n_workers) as ex:
            for results in tqdm(ex.map(process_chunk, chunks), total=len(chunks),
                                desc=f"hw {self.split}", unit="chunk"):
                for vr in results:
                    if vr["valid"].sum() == 0:
                        continue
                    for key in self.KEYS:
                        parts[key].append(vr[key][vr["valid"]])
                del results
                gc.collect()
        return parts

    def __len__(self):
        return self.data["mask"].size(0)

    @staticmethod
    def _hflip(sample):
        # hflip the image + UV pixel grid; negate x-component of world-space direction vectors
        # (mirroring the scene's horizontal axis), matching the legacy loader's geometric consistency.
        out = {}
        for k, t in sample.items():
            tf = t.flip(-1).contiguous()
            if k in ("normal", "reflection_dir", "view_dir"):
                tf[0] = -tf[0]
            out[k] = tf
        return out

    def __getitem__(self, idx):
        sample = {k: v[idx] for k, v in self.data.items()}
        if getattr(self, "augment", False) and random.random() < 0.5:
            sample = self._hflip(sample)
        return sample


def build_dataloaders_hw(dataset_dir=None, batch_size=1024, num_workers=4,
                         load_workers=8, seed=42, feature_spec=None, device="cpu", halo=0,
                         convention="opengl"):
    """Same signature as build_dataloaders; builds HW train/val loaders."""
    hw_dir = Path(dataset_dir) if dataset_dir else DATASET_DIR
    print(f"=== Loading HW dataset [cpu] from {hw_dir} (convention={convention}) ===")
    train_ds = InMemoryTileDatasetHW(hw_dir, "train", load_workers, seed, feature_spec, "cpu", halo,
                                     convention=convention)
    val_ds = InMemoryTileDatasetHW(hw_dir, "val", load_workers, seed, feature_spec, "cpu", halo,
                                   convention=convention)
    train_loader = BatchIterator(train_ds, batch_size, shuffle=True, drop_last=True, device=device)
    val_loader = BatchIterator(val_ds, batch_size, shuffle=False, drop_last=False, device=device)
    return train_loader, val_loader
