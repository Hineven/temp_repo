#!/usr/bin/env bash
# Train 2x64 per-pixel MLP on synthetic 1-pixel point-light PBR data.
set -e

cd "$(dirname "$0")"

python train_mlp_synthetic.py \
    --output_dir "D:/mlp_synthetic_experiment" \
    --batch_size 8192 \
    --samples_per_epoch 1048576 \
    --val_samples 65536 \
    --epochs 200 \
    --lr 3e-3 \
    --seed 42

echo "=== Done ==="
