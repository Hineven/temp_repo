#!/usr/bin/env python3
"""
Full-frame visual eval for HW_DATASET neural_tex runs.

Loads a checkpoint, reconstructs the experiment, rasterizes N val views' UV on the fly (the same
path the dataloader uses), tiles them, runs inference tile-by-tile, stitches back to full-res, and
writes GT | Pred | Error panels to <run>/vis_eval/hw/.

The numeric val_l1 already comes from the training loop; this is the qualitative counterpart.
"""
import argparse
import json
import math
from pathlib import Path

import numpy as np
import torch
import nvdiffrast.torch as dr
from PIL import Image

import rasterize_hw as RHW
from train_lighting.dataset import _tile_chw, _tile_chw_halo, TILE_SIZE
from train_lighting.single_view_eval import experiment_from_checkpoint


def _view_dirs_from_c2w(cam2world, fov_deg, h, w):
    col0, col1, col2 = cam2world[:3, 0], cam2world[:3, 1], cam2world[:3, 2]
    tan = math.tan(math.radians(fov_deg) / 2.0)
    u = np.arange(w, dtype=np.float32) + 0.5
    v = np.arange(h, dtype=np.float32) + 0.5
    x = (2.0 * u / w - 1.0) * tan
    y = (1.0 - 2.0 * v / h) * tan
    xs, ys = np.meshgrid(x, y, indexing="xy")
    ray = (xs[..., None] * col0 + ys[..., None] * col1 - col2).astype(np.float32)
    ray /= (np.linalg.norm(ray, axis=2, keepdims=True) + 1e-8)
    return ray


def _load_full_view(hw_dir, view_idx, mesh, ctx, fov_deg, feature_spec, res=1024,
                    convention="opengl"):
    """Full-res channels for one view: rgb_gt, uv, mask, + geometry the feature_spec asks for."""
    hw_dir = Path(hw_dir)
    rgb = np.array(Image.open(hw_dir / "images" / f"{view_idx:04d}_0001.png").convert("RGB"), dtype=np.float32) / 255.0
    doc = json.loads((hw_dir / "transforms_all.json").read_text())
    cam2world = np.array(doc["frames"][view_idx]["transform_matrix"], dtype=np.float32)
    verts, faces, uvs, normals = mesh
    uv, normal, mask = RHW.rasterize_view(ctx, verts, faces, uvs, normals, cam2world,
                                          fov_deg, res, 1.0, 0.05, 20.0,
                                          convention=convention)
    uv = uv.astype(np.float32)
    normal = normal.astype(np.float32)
    mask = mask.astype(np.float32)
    out = {"rgb_gt": rgb, "uv": uv, "mask": mask}
    need = feature_spec.compute_ndotv or feature_spec.compute_reflection or feature_spec.compute_view_dir
    if need:
        h, w = mask.shape[:2]
        view_dir = _view_dirs_from_c2w(cam2world, fov_deg, h, w)
        ndotv = np.clip(np.sum(normal * view_dir, axis=2, keepdims=True), 0.0, 1.0)
        if feature_spec.compute_ndotv or feature_spec.compute_reflection:
            out["normal"] = normal
        if feature_spec.compute_ndotv:
            out["ndotv"] = ndotv
        if feature_spec.compute_reflection:
            refl = 2.0 * ndotv * normal - view_dir
            refl /= (np.linalg.norm(refl, axis=2, keepdims=True) + 1e-8)
            out["reflection_dir"] = refl
        if feature_spec.compute_view_dir:
            out["view_dir"] = view_dir
    return out


def _tile_for_eval(raw, ts, halo):
    """Tile features with halo context; rgb_gt/mask stay center-only."""
    tiled = {}
    for name, arr in raw.items():
        arr = arr[..., None] if arr.ndim == 2 else arr
        if halo > 0 and name not in ("rgb_gt", "mask"):
            tiled[name] = _tile_chw_halo(arr, ts, halo)
        else:
            tiled[name] = _tile_chw(arr, ts, ts)
    return tiled


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", required=True)
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--num_views", type=int, default=6)
    ap.add_argument("--seed", type=int, default=123)
    ap.add_argument("--cam_convention", default="opengl",
                    choices=list(RHW.CAM_CONVENTIONS),
                    help="how to interpret transform_matrix")
    args = ap.parse_args()

    run_dir = Path(args.run_dir)
    ckpt = args.checkpoint or str(run_dir / "checkpoints" / "best.pt")
    experiment, modules, device = experiment_from_checkpoint(ckpt)
    for m in modules.values():
        m.eval()

    cfg = json.loads((run_dir / "config.json").read_text())
    hw_dir = cfg["args"]["dataset_dir"]
    halo = cfg["args"].get("halo", 0)
    fov_deg = math.degrees(json.loads((Path(hw_dir) / "transforms_all.json").read_text())["camera_angle_x"])

    mesh = RHW.load_mesh(Path(hw_dir) / "mesh.ply")
    ctx = dr.RasterizeCudaContext(device=torch.device("cuda"))

    # pick val views
    val_doc = json.loads((Path(hw_dir) / "transforms_val.json").read_text())
    val_idxs = [int(f["file_path"].split("/")[-1].split("_")[0]) for f in val_doc["frames"]]
    rng = np.random.RandomState(args.seed)
    rng.shuffle(val_idxs)
    chosen = val_idxs[: args.num_views]

    out_dir = run_dir / "vis_eval" / "hw"
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = TILE_SIZE

    for vi in chosen:
        raw = _load_full_view(hw_dir, vi, mesh, ctx, fov_deg, experiment.feature_spec,
                              convention=args.cam_convention)
        rgb = raw["rgb_gt"]
        mask = raw["mask"]
        h, w = mask.shape
        ny, nx = h // ts, w // ts
        tiled = _tile_for_eval(raw, ts, halo)
        mask_t = tiled["mask"].reshape(ny, nx, *tiled["mask"].shape[2:])
        pred_canvas = np.zeros((3, h, w), dtype=np.float32)

        for ty in range(ny):
            for tx in range(nx):
                if mask_t[ty, tx, 0].sum() == 0:
                    continue
                batch = {}
                for k, arr in tiled.items():
                    tile = arr.reshape(ny, nx, *arr.shape[2:])[ty, tx]
                    batch[k] = torch.from_numpy(tile).unsqueeze(0).float().to(device)
                pred = experiment.forward(batch, modules, device)[0].cpu().numpy()
                pred_canvas[:, ty * ts:(ty + 1) * ts, tx * ts:(tx + 1) * ts] = pred

        msk = mask > 0.5
        # Sum over 3 channels per pixel (NOT mean) to match the training MaskedL1Loss / val_l1
        # convention: (diff*mask).sum()/mask.sum() with single-channel mask sums channels, divides
        # by pixel count. hw_eval's per-view L1 is then directly comparable to the reported val_l1.
        err = np.abs(pred_canvas - rgb.transpose(2, 0, 1)).sum(0)
        err[~msk] = 0
        panel = np.concatenate([
            rgb,
            (pred_canvas.transpose(1, 2, 0)).clip(0, 1),
            np.repeat((err / max(err.max(), 1e-6))[:, :, None], 3, axis=2),
        ], axis=1)
        mean_err = err[msk].mean() if msk.any() else 0.0
        Image.fromarray((panel * 255).astype(np.uint8)).save(out_dir / f"view_{vi:04d}.png")
        print(f"  view {vi:04d}: masked L1 = {mean_err:.4f}  -> {out_dir / f'view_{vi:04d}.png'}")

    print(f"\nDone. Panels (GT|Pred|Error) in {out_dir}")


if __name__ == "__main__":
    main()
