#!/usr/bin/env python3
"""Regenerate expA_mlp_vs_unet.png with consistent Reinhard tonemap for GT/MLP/U-Net."""
import sys
from pathlib import Path

PRE_EXP_NET = Path(r"F:\CLionProjects\Falcor-VRS\scripts\pre_experiment\network")
sys.path.insert(0, str(PRE_EXP_NET))

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from dataset import create_data_buffers
from network import ShadingNetBase


METRIC_EXPOSURE = 1.0
DISPLAY_EXPOSURE = 3.0
DISPLAY_SIZE = 512  # downsample for the figure so objects fit comfortably


def tonemap_reinhard(hdr, exposure=METRIC_EXPOSURE):
    x = hdr * exposure
    return x / (1.0 + x)


def resize_for_display(arr, size=DISPLAY_SIZE):
    """Downsample a (H,W,3) uint8/float image for compact plotting."""
    img = Image.fromarray((np.clip(arr, 0, 1) * 255).astype(np.uint8))
    img = img.resize((size, size), Image.LANCZOS)
    return np.array(img) / 255.0


def main():
    data_dir = Path(r"D:\pre_experiment_output_v3_mixed")
    ckpts = {
        'MLP 2×64': data_dir / 'checkpoints_mlp_2x64_real' / 'best_model.pt',
        'U-NetV14': data_dir / 'checkpoints_v17' / 'best_model.pt',
    }
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    train_buf, eval_buf = create_data_buffers(
        str(data_dir), batch_size=1, eval_ratio=0.1,
        target_size=1024, max_views=300, seed=42,
    )

    models = {}
    for name, ckpt in ckpts.items():
        model = ShadingNetBase.load_any(str(ckpt), device=device)
        model.eval()
        models[name] = model

    # Pick 2 eval views with visible content
    selected = [3, 17]
    display_sizes = [512, 512]
    n_rows = len(selected)
    n_cols = 3  # GT, MLP, U-Net
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(10, 3.5 * n_rows), dpi=120)
    if n_rows == 1:
        axes = axes.reshape(1, -1)

    for ri, idx in enumerate(selected):
        gbuf, albedo_t, meta_t, target_t, inten_t, inv_r2_t, _ = eval_buf.samples[idx]
        intensity = inten_t.cpu().numpy()
        tgt_hdr = target_t.cpu().numpy().transpose(1, 2, 0) * intensity

        # Metric LDR (exposure=1.0) for the printed L1 numbers
        tgt_ldr_metric = np.clip(tonemap_reinhard(tgt_hdr, exposure=METRIC_EXPOSURE), 0, 1)
        # Display LDR (brighter exposure) for the figure
        tgt_ldr_disp = np.clip(tonemap_reinhard(tgt_hdr, exposure=DISPLAY_EXPOSURE), 0, 1)

        axes[ri, 0].imshow(resize_for_display(tgt_ldr_disp, size=display_sizes[ri]))
        axes[ri, 0].set_title('GT', fontsize=10)
        axes[ri, 0].axis('off')

        for ci, (name, model) in enumerate(models.items(), start=1):
            with torch.no_grad():
                comp, _, _ = model.predict(
                    gbuf.unsqueeze(0).to(device),
                    albedo_t.unsqueeze(0).clamp(0, 1).to(device),
                )
            pred_shading = comp[0].cpu().numpy().transpose(1, 2, 0)
            pred_hdr = pred_shading * inv_r2_t[0].cpu().numpy()[:, :, None] * intensity

            pred_ldr_metric = np.clip(tonemap_reinhard(pred_hdr, exposure=METRIC_EXPOSURE), 0, 1)
            pred_ldr_disp = np.clip(tonemap_reinhard(pred_hdr, exposure=DISPLAY_EXPOSURE), 0, 1)

            err = np.abs(pred_ldr_metric - tgt_ldr_metric).sum(axis=2)
            l1 = err[tgt_hdr.sum(axis=2) > 1e-4].mean() / 3.0

            axes[ri, ci].imshow(resize_for_display(pred_ldr_disp, size=display_sizes[ri]))
            axes[ri, ci].set_title(f'{name}\nmasked LDR L1={l1:.4f}', fontsize=10)
            axes[ri, ci].axis('off')

    fig.suptitle('MLP vs U-Net on real Falcor eval views (consistent Reinhard tonemap)', fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    out_path = Path(r'd:\TestScene\FixedLighting1ItemTemplate\figures\hcx\expA_mlp_vs_unet.png')
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150, bbox_inches='tight', pad_inches=0.05)
    plt.close(fig)
    print(f'Saved {out_path}')


if __name__ == '__main__':
    main()
