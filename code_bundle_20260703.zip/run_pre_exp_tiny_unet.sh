#!/usr/bin/env bash
# Train a ~10 GFLOPs pruned UNetV14 on the old pre_experiment v3 mixed dataset
# and run a quick eval to get L1 numbers.
set -e

NET_DIR="/f/CLionProjects/Falcor-VRS/scripts/pre_experiment/network"
DATA_DIR="/d/pre_experiment_output_v3_mixed"
OUT_DIR="/d/pre_experiment_output_v3_mixed/tiny_unet_10g"

cd "$NET_DIR"

echo "=== Training tiny UNetV14 base_ch=12 bottleneck_ch=48 @1024x1024 (~10G) ==="
python train.py \
    --data_dir "$DATA_DIR" \
    --output_dir "$OUT_DIR" \
    --model UNetV14 \
    --base_ch 12 \
    --bottleneck_ch 48 \
    --encoder_out 32 \
    --feat_channels 2 \
    --target_size 1024 \
    --batch_size 4 \
    --epochs 30 \
    --lr 3e-3 \
    --max_views 300 \
    --eval_ratio 0.1

echo "=== Evaluating best checkpoint ==="
python eval.py \
    --data_dir "$DATA_DIR" \
    --checkpoint "$OUT_DIR/best_model.pt" \
    --output_dir "$OUT_DIR/eval" \
    --target_size 1024 \
    --n_samples 30

echo "=== Computing FLOPs at 1024x1024 ==="
python - "$OUT_DIR" <<'PY'
import sys, torch
sys.path.insert(0, r'F:\CLionProjects\Falcor-VRS\scripts\pre_experiment\network')
from network import UNetV14

net = UNetV14(in_channels=14, encoder_out=32, feat_channels=2, base_ch=12, bottleneck_ch=48).eval()
total = 0
for m in net.modules():
    if isinstance(m, torch.nn.Conv2d):
        macs = 1
        for s in m.kernel_size: macs *= s
        macs *= m.out_channels * (m.in_channels // m.groups)
        # actual spatial size from a forward pass is needed; use registered hook
    elif isinstance(m, torch.nn.ConvTranspose2d):
        pass  # counted below via hook

def count():
    t = 0
    def hook(m, inp, out):
        nonlocal t
        if isinstance(m, torch.nn.Conv2d):
            macs = out.shape[-2]*out.shape[-1]*m.out_channels*(m.in_channels//m.groups)*m.kernel_size[0]*m.kernel_size[1]
        elif isinstance(m, torch.nn.ConvTranspose2d):
            macs = inp[0].shape[-2]*inp[0].shape[-1]*m.in_channels*m.out_channels*m.kernel_size[0]*m.kernel_size[1]//m.groups
        else: return
        t += 2*macs
    hs = [x.register_forward_hook(hook) for x in net.modules() if isinstance(x,(torch.nn.Conv2d,torch.nn.ConvTranspose2d))]
    with torch.no_grad():
        net(torch.randn(1,14,1024,1024))
    [h.remove() for h in hs]
    return t

flops = count()
params = sum(p.numel() for p in net.parameters())
out = sys.argv[1]
with open(out+'/flops.txt','w') as f:
    f.write(f'FLOPs @1024x1024: {flops/1e9:.3f} G\nParams: {params/1e3:.1f} K\n')
print(f'FLOPs @1024x1024: {flops/1e9:.3f} G, Params: {params/1e3:.1f} K')
PY

echo "=== Done ==="
