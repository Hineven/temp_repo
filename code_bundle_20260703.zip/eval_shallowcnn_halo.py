#!/usr/bin/env python3
"""
Evaluate the best shallow CNN checkpoint under different halo sizes and compare
against true full-image (non-tiled) inference.

Outputs both the raw 3-channel-sum val_l1 (what the training engine reports) and
the per-channel mean (the report convention after dividing by 3).
"""
import argparse
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import torch
import nvdiffrast.torch as dr
from PIL import Image

from train_lighting.train import evaluate, MaskedL1Loss
from train_lighting.dataset import build_dataloaders
from train_lighting.dataset_hw import build_dataloaders_hw
from train_lighting.single_view_eval import experiment_from_checkpoint
from train_lighting.error_decomp import decompose
from train_lighting.dataset_hw import _view_directions_from_c2w
from rasterize_hw import load_mesh, rasterize_views_batched, CAM_CONVENTIONS


def _is_hw(dataset_dir):
    p = Path(dataset_dir)
    return (p / "mesh.ply").exists() and (p / "transforms_all.json").exists()


def eval_tiled(experiment, modules, device, dataset_dir, halo, seed, batch_size, convention="opengl"):
    experiment.halo = halo
    loader_kwargs = dict(
        dataset_dir=dataset_dir,
        batch_size=batch_size,
        num_workers=0,
        load_workers=4,
        seed=seed,
        feature_spec=experiment.feature_spec,
        device=str(device),
        halo=halo,
    )
    if _is_hw(dataset_dir):
        _, val_loader = build_dataloaders_hw(**loader_kwargs, convention=convention)
    else:
        _, val_loader = build_dataloaders(**loader_kwargs)
    criterion = MaskedL1Loss()
    val_l1, avg_pixel_err, rad_min, rad_max = evaluate(
        experiment, modules, val_loader, criterion, device
    )
    return val_l1, avg_pixel_err


def tile_seam_stats(experiment, modules, device, dataset_dir, halo, seed, batch_size, convention="opengl"):
    """Run error_decomp spatial analysis for a given halo."""
    experiment.halo = halo
    loader_kwargs = dict(
        dataset_dir=dataset_dir,
        batch_size=batch_size,
        num_workers=0,
        load_workers=4,
        seed=seed,
        feature_spec=experiment.feature_spec,
        device=str(device),
        halo=halo,
    )
    if _is_hw(dataset_dir):
        _, val_loader = build_dataloaders_hw(**loader_kwargs, convention=convention)
    else:
        _, val_loader = build_dataloaders(**loader_kwargs)
    r = decompose(experiment, modules, device, val_loader)
    sp = r["spatial_mean"]
    boundary = np.concatenate([sp[:, 0], sp[:, -1], sp[0, :], sp[-1, :]])
    interior = sp[1:-1, 1:-1].flatten()
    return {
        "overall": r["overall_abs"],
        "boundary": float(boundary.mean()),
        "interior": float(interior.mean()),
        "ratio": float(boundary.mean() / max(interior.mean(), 1e-8)),
    }


def load_hw_val_views(hw_dir, seed):
    hw_dir = Path(hw_dir)
    all_doc = json.loads((hw_dir / "transforms_all.json").read_text())
    fov_deg = math.degrees(all_doc["camera_angle_x"])
    cam2world = [np.array(f["transform_matrix"], dtype=np.float32) for f in all_doc["frames"]]
    split_doc = json.loads((hw_dir / "transforms_val.json").read_text())
    view_idxs = [
        int(f["file_path"].split("/")[-1].split("_")[0]) for f in split_doc["frames"]
    ]
    random.Random(seed).shuffle(view_idxs)
    return view_idxs, cam2world, fov_deg


def eval_full_image(experiment, modules, device, hw_dir, view_idxs, cam2world_list, fov_deg,
                    res=1024, max_views=None, convention="opengl"):
    """True full-image forward (one forward per view, no tiling)."""
    hw_dir = Path(hw_dir)
    mesh = load_mesh(hw_dir / "mesh.ply")
    ctx = dr.RasterizeCudaContext(device=device)

    total_err = 0.0
    total_px = 0
    per_view = []
    images_dir = hw_dir / "images"

    if max_views is not None:
        view_idxs = view_idxs[:max_views]

    t0 = time.time()
    for vi, idx in enumerate(view_idxs):
        c2w = cam2world_list[idx]
        # rasterize one view at a time to keep memory modest
        (uv, normal, mask) = rasterize_views_batched(
            ctx, *mesh, [c2w], fov_deg, res, aspect=1.0, n=0.05, f=20.0,
            convention=convention
        )[0]
        rgb = np.array(
            Image.open(images_dir / f"{idx:04d}_0001.png").convert("RGB"),
            dtype=np.float32,
        ) / 255.0

        uv = uv.astype(np.float32)
        normal = normal.astype(np.float32)
        mask = mask.astype(np.float32)
        h, w = mask.shape

        view_dir = _view_directions_from_c2w(c2w, fov_deg, h, w)
        ndotv = np.clip(np.sum(normal * view_dir, axis=2, keepdims=True), 0.0, 1.0)
        refl = 2.0 * ndotv * normal - view_dir
        refl /= (np.linalg.norm(refl, axis=-1, keepdims=True) + 1e-8)

        batch = {
            "uv": torch.from_numpy(uv.transpose(2, 0, 1)).unsqueeze(0).float().to(device),
            "normal": torch.from_numpy(normal.transpose(2, 0, 1)).unsqueeze(0).float().to(device),
            "reflection_dir": torch.from_numpy(refl.transpose(2, 0, 1)).unsqueeze(0).float().to(device),
            "ndotv": torch.from_numpy(ndotv.transpose(2, 0, 1)).unsqueeze(0).float().to(device),
            "rgb_gt": torch.from_numpy(rgb.transpose(2, 0, 1)).unsqueeze(0).float().to(device),
            "mask": torch.from_numpy(mask[:, :, None].transpose(2, 0, 1)).unsqueeze(0).float().to(device),
        }

        experiment.halo = 0
        with torch.no_grad():
            pred = experiment.forward(batch, modules, device)

        diff = (pred - batch["rgb_gt"]).abs()
        m = batch["mask"]
        err = (diff * m).sum().item()
        px = m.sum().item()
        total_err += err
        total_px += px
        per_view.append((idx, err / max(px, 1)))

        if (vi + 1) % 10 == 0 or vi == len(view_idxs) - 1:
            print(f"  full-image eval: {vi + 1}/{len(view_idxs)} views, "
                  f"current mean L1 = {total_err / max(total_px, 1):.6f}")

    print(f"  full-image eval time: {time.time() - t0:.1f}s")
    return total_err / max(total_px, 1), per_view


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint",
                        default="experiments/neural_tex_shallow_cnn/20260626_204242_regular_71_10g/checkpoints/best.pt")
    parser.add_argument("--dataset_dir", default="dataset_hw_71")
    parser.add_argument("--batch_size", type=int, default=1024)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max_full_views", type=int, default=None,
                        help="limit full-image eval to N views (for quick tests)")
    parser.add_argument("--cam_convention", default="opengl", choices=list(CAM_CONVENTIONS),
                        help="how to interpret transform_matrix")
    args = parser.parse_args()

    ckpt_path = Path(args.checkpoint)
    experiment, modules, device = experiment_from_checkpoint(str(ckpt_path))
    cfg = json.loads((ckpt_path.parent.parent / "config.json").read_text())
    dataset_dir = args.dataset_dir or cfg.get("args", {}).get("dataset_dir", "dataset_hw_71")

    print(f"\nDevice: {device}")
    print(f"Dataset: {dataset_dir}")
    print(f"Checkpoint: {ckpt_path}")
    print(f"Camera convention: {args.cam_convention}\n")

    results = {}

    # ---- tiled halo=0 baseline ----
    print("=== Tiled inference, halo=0 ===")
    raw0, _ = eval_tiled(experiment, modules, device, dataset_dir, 0, args.seed, args.batch_size,
                         convention=args.cam_convention)
    results["tiled_halo0"] = raw0
    print(f"  raw val_l1 (3ch sum): {raw0:.6f}  -> per-channel mean: {raw0 / 3.0:.6f}\n")

    # ---- tiled halo=3 ----
    print("=== Tiled inference, halo=3 ===")
    raw3, _ = eval_tiled(experiment, modules, device, dataset_dir, 3, args.seed, args.batch_size,
                         convention=args.cam_convention)
    results["tiled_halo3"] = raw3
    print(f"  raw val_l1 (3ch sum): {raw3:.6f}  -> per-channel mean: {raw3 / 3.0:.6f}\n")

    # ---- tile seam decomposition for halo=0 and halo=3 ----
    print("=== Tile seam stats (per-channel mean |err|) ===")
    for h in (0, 3):
        stats = tile_seam_stats(experiment, modules, device, dataset_dir, h, args.seed, args.batch_size,
                                convention=args.cam_convention)
        results[f"halo{h}_seam"] = stats
        print(f"  halo={h}: overall={stats['overall']:.6f}, boundary={stats['boundary']:.6f}, "
              f"interior={stats['interior']:.6f}, ratio={stats['ratio']:.3f}x")
    print()

    # ---- true full-image (non-tiled) inference ----
    print("=== Full-image (non-tiled) inference ===")
    view_idxs, cam2world, fov_deg = load_hw_val_views(dataset_dir, args.seed)
    print(f"  val views: {len(view_idxs)}")
    full_raw, per_view = eval_full_image(
        experiment, modules, device, dataset_dir, view_idxs, cam2world, fov_deg,
        res=1024, max_views=args.max_full_views, convention=args.cam_convention
    )
    results["full_image"] = full_raw
    print(f"  raw L1 (3ch sum): {full_raw:.6f}  -> per-channel mean: {full_raw / 3.0:.6f}\n")

    # ---- summary ----
    print("=" * 60)
    print("SUMMARY (val_l1 on regular 71, shallow CNN base_ch=15)")
    print("=" * 60)
    print(f"{'Mode':<30} {'raw (3ch sum)':>14} {'per-channel mean':>18}")
    print("-" * 60)
    for name, raw in [
        ("tiled halo=0", results["tiled_halo0"]),
        ("tiled halo=3", results["tiled_halo3"]),
        ("full image (non-tiled)", results["full_image"]),
    ]:
        print(f"{name:<30} {raw:>14.6f} {raw / 3.0:>18.6f}")

    gap_h3_vs_full = results["tiled_halo3"] - results["full_image"]
    print(f"\n  halo=3 vs full-image gap (raw): {gap_h3_vs_full:.6f} "
          f"({gap_h3_vs_full / 3.0:.6f} per-channel mean)")
    if abs(gap_h3_vs_full) < 1e-4:
        print("  -> halo=3 is effectively lossless (difference < 1e-4 raw).")
    else:
        print("  -> halo=3 is NOT fully lossless; residual gap remains.")

    # save json
    out = ckpt_path.parent.parent / "eval_halo_results.json"
    serializable = {}
    for k, v in results.items():
        if isinstance(v, dict):
            serializable[k] = {kk: float(vv) for kk, vv in v.items()}
        else:
            serializable[k] = float(v)
    serializable["per_view_full"] = per_view
    out.write_text(json.dumps(serializable, indent=2), encoding="utf-8")
    print(f"\nSaved detailed results to {out}")


if __name__ == "__main__":
    main()
