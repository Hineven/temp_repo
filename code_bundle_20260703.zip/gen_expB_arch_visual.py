"""Generate side-by-side visual comparison for ExpB architecture-budget analysis.

Loads the HW-eval panels (GT | Pred | Error) produced by hw_eval.py for
ShallowCNN, MLP and U-Net (mrt_nonorm) at ~10 GFLOPs, then crops them into a
compact figure: one row per scene, four columns (GT, CNN, MLP, U-Net).
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
from PIL import Image

OUT = Path(r'd:\TestScene\FixedLighting1ItemTemplate\figures\hcx')
OUT.mkdir(parents=True, exist_ok=True)

# Try a Chinese font, fall back to sans-serif
try:
    import matplotlib.font_manager as fm
    fonts = [f.name for f in fm.fontManager.ttflist]
    for cn in ['Microsoft YaHei', 'SimHei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC']:
        if cn in fonts:
            plt.rcParams['font.family'] = cn
            plt.rcParams['axes.unicode_minus'] = False
            break
except Exception:
    pass


# Run directories and best validation L1 (from train.log best val loss)
SCENES = [
    {
        'name': 'regular',
        'title': 'Regular 71',
        'gt_from': 'CNN',
        'view': 'view_0600.png',
        'models': {
            'CNN': {
                'run': 'experiments/neural_tex_shallow_cnn/20260701_103040_regular_71_10g_halo3',
                'val_l1': 0.0255,  # raw 3ch sum; displayed as per-channel mean
            },
            'MLP': {
                'run': 'experiments/neural_tex_mlp/20260626_202511_regular_71_1layer',
                'val_l1': 0.0295,
            },
            'U-Net': {
                'run': 'experiments/neural_tex_mrt_nonorm/20260628_184719_regular_71_10g_nonorm',
                'val_l1': 0.0302,
            },
        },
    },
    {
        'name': 'glossy',
        'title': 'Glossy 71',
        'gt_from': 'CNN',
        'view': 'view_0600.png',
        'models': {
            'CNN': {
                'run': 'experiments/neural_tex_shallow_cnn/20260702_105959_glossy_71_10g_halo3',
                'val_l1': 0.0849,
            },
            'MLP': {
                'run': 'experiments/neural_tex_mlp/20260626_113638_glossy_71_1layer',
                'val_l1': 0.1007,
            },
            'U-Net': {
                'run': 'experiments/neural_tex_mrt_nonorm/20260626_184205_matched_mlp1_rawgeom',
                'val_l1': 0.0962,
            },
        },
    },
    {
        'name': 'sss',
        'title': 'SSR / SSS12',
        'gt_from': 'CNN',
        'view': 'view_0032.png',
        'models': {
            'CNN': {
                'run': 'experiments/neural_tex_shallow_cnn/20260702_105824_sss12_10g_halo3',
                'val_l1': 0.0898,
            },
            'MLP': {
                'run': 'experiments/neural_tex_mlp/20260627_103124_sss12_10g_mlp1',
                'val_l1': 0.0927,
            },
            'U-Net': {
                'run': 'experiments/neural_tex_mrt_nonorm/20260627_104223_sss12_10g_nonorm',
                'val_l1': 0.0965,
            },
        },
    },
]


def center_crop(img):
    """Crop the center 1/4 of pixels (half height / half width) and scale 2x."""
    h, w = img.shape[:2]
    ch, cw = h // 2, w // 2
    y0, x0 = h // 2 - ch // 2, w // 2 - cw // 2
    cropped = img[y0:y0 + ch, x0:x0 + cw]
    # Upscale 2x with nearest-neighbor to keep pixel edges sharp in print.
    return np.array(Image.fromarray(cropped).resize((cw, ch), Image.NEAREST))


def load_panel(run_dir, view_name):
    p = Path(run_dir) / 'vis_eval' / 'hw' / view_name
    if not p.exists():
        raise FileNotFoundError(p)
    img = np.array(Image.open(p).convert('RGB'))
    h, w = img.shape[:2]
    assert w % 3 == 0, f"panel width {w} not divisible by 3"
    gt = center_crop(img[:, :w//3])
    pred = center_crop(img[:, w//3:2*w//3])
    err = center_crop(img[:, 2*w//3:])
    return gt, pred, err


n_rows = len(SCENES)
n_cols = 4  # GT + CNN + MLP + U-Net
fig, axes = plt.subplots(n_rows, n_cols, figsize=(12, 3.4 * n_rows), dpi=150)
if n_rows == 1:
    axes = axes.reshape(1, -1)

for ri, scene in enumerate(SCENES):
    gt, _, _ = load_panel(scene['models'][scene['gt_from']]['run'], scene['view'])
    axes[ri, 0].imshow(gt)
    axes[ri, 0].set_ylabel(scene['title'], fontsize=11)
    if ri == 0:
        axes[ri, 0].set_title('GT', fontsize=11)

    for ci, (model_name, info) in enumerate(scene['models'].items(), start=1):
        _, pred, err = load_panel(info['run'], scene['view'])
        axes[ri, ci].imshow(pred)
        axes[ri, ci].set_title(
            f"{model_name}\nval L1 = {info['val_l1']/3.0:.4f}",
            fontsize=10,
        )
        # Optional: draw a tiny inset error map in the lower-right corner.
        inset_size = max(64, min(pred.shape[:2]) // 5)
        h, w = pred.shape[:2]
        err_small = np.array(Image.fromarray(err).resize((inset_size, inset_size), Image.LANCZOS))
        # Copy inset onto prediction (with a subtle border)
        pred_with_inset = pred.copy()
        y0, x0 = h - inset_size - 4, w - inset_size - 4
        pred_with_inset[y0:y0+inset_size, x0:x0+inset_size] = err_small
        pred_with_inset[max(0, y0-1):y0, x0:x0+inset_size] = [255, 0, 0]
        pred_with_inset[y0:y0+inset_size, max(0, x0-1):x0] = [255, 0, 0]
        axes[ri, ci].imshow(pred_with_inset)

for ax in axes.flat:
    ax.axis('off')

fig.suptitle(
    "Architecture comparison at ~10 GFLOPs (baked neural texture)\n"
    "GT | ShallowCNN | MLP | U-Net (mrt_nonorm); red inset = 10x error map",
    fontsize=12,
    y=0.99,
)
fig.tight_layout(rect=[0, 0, 1, 0.96])
out_path = OUT / 'expB_arch_visual.png'
fig.savefig(out_path, dpi=300, bbox_inches='tight')
plt.close(fig)
print(f"Saved {out_path}")
