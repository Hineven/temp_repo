#!/usr/bin/env python3
"""
nvdiffrast rasterizer for the HW dataset.

For each view (camera from transforms_all.json), rasterize mesh.ply -> per-pixel
{uv(2), normal(3) world-space, mask(1)}. Outputs dataset_hw_*/raster/{i:04d}.npz.

Conventions (all decoded from the render pipeline + validated against the frozen GT):
  * mesh.ply is ALREADY in the Blender-"imported" frame (the glTF node rotation was baked into the
    vertices by prepare_hw_dataset.py). model_transform.rotation_euler in the frozen metadata is NOT
    applied to the geometry (the object is rendered at the imported pose), so we use the mesh as-is.
  * Camera: cam2world 4x4 from transforms.json (Blender Euler-XYZ, -Z forward, +Y up). Projection is
    the matching OpenGL perspective matrix (square sensor, fov = camera_angle_x).
  * nvdiffrast maps NDC +y to the BOTTOM row, but the renders have scene-up at row 0 (top), so every
    output is flipped vertically once to align with the PNGs.
  * Normals: area-weighted per-vertex normals (geometry-derived), in the same world frame as the
    vertices. These are self-consistent across views (what the neural-texture net consumes); they are
    NOT meant to match Blender's normal AOV pass.

Validation (--validate <view_idx>): rasterize one view, compare mask IoU to the frozen mask.png
(required >0.99). Run this before rasterizing all views.
"""
import argparse
import json
import math
from pathlib import Path

import numpy as np
import torch
import nvdiffrast.torch as dr
from PIL import Image

SCRIPT_DIR = Path(__file__).resolve().parent


def load_mesh(ply_path):
    import trimesh
    m = trimesh.load(str(ply_path), force="mesh", process=False)
    verts = np.asarray(m.vertices, dtype=np.float32)
    faces = np.asarray(m.faces, dtype=np.int32)
    uvs = np.asarray(m.visual.uv, dtype=np.float32)
    vn = _compute_vertex_normals(verts, faces)
    return verts, faces, uvs, vn


def _compute_vertex_normals(verts, faces):
    v0, v1, v2 = verts[faces[:, 0]], verts[faces[:, 1]], verts[faces[:, 2]]
    fn = np.cross(v1 - v0, v2 - v0)
    vn = np.zeros_like(verts)
    np.add.at(vn, faces[:, 0], fn)
    np.add.at(vn, faces[:, 1], fn)
    np.add.at(vn, faces[:, 2], fn)
    n = np.linalg.norm(vn, axis=1, keepdims=True)
    n[n < 1e-12] = 1.0
    return (vn / n).astype(np.float32)


def opengl_projection(fov_deg, aspect, n, f):
    """Perspective projection matching compute_view_direction_map (camera looks down -Z, +Y up)."""
    t = math.tan(math.radians(fov_deg) / 2.0)
    P = np.zeros((4, 4), dtype=np.float32)
    P[0, 0] = 1.0 / (aspect * t)
    P[1, 1] = 1.0 / t
    P[2, 2] = -(f + n) / (f - n)
    P[2, 3] = -2.0 * f * n / (f - n)
    P[3, 2] = -1.0
    return P


# Camera convention fixup matrices.
# All conventions are reduced to the OpenGL camera frame (right-handed, +X right, +Y up, -Z forward).
CAM_CONVENTIONS = {
    "opengl": np.eye(4, dtype=np.float32),
    "blender": np.eye(4, dtype=np.float32),
    "colmap": np.diag([1.0, -1.0, -1.0, 1.0]).astype(np.float32),
    "unity": np.diag([1.0, 1.0, -1.0, 1.0]).astype(np.float32),
    "directx": np.diag([1.0, 1.0, -1.0, 1.0]).astype(np.float32),
}


def cam2world_from_raw(raw_cam2world, convention="opengl"):
    """Convert a raw transform_matrix from a dataset convention to OpenGL cam2world."""
    if convention not in CAM_CONVENTIONS:
        raise ValueError(f"Unknown camera convention '{convention}'. Available: {list(CAM_CONVENTIONS)}")
    M = CAM_CONVENTIONS[convention]
    return raw_cam2world @ M


def rasterize_view(ctx, verts, faces, uvs, normals, cam2world, fov_deg, res, aspect, n, f,
                   convention="opengl"):
    """Rasterize one view. verts/normals already in WORLD/imported frame. Returns uv[H,W,2], normal[H,W,3], mask[H,W] (row 0 = top)."""
    cam2world = cam2world_from_raw(cam2world, convention)
    dev = torch.device('cuda')
    V = torch.from_numpy(np.linalg.inv(cam2world)).to(dev)
    P = torch.from_numpy(opengl_projection(fov_deg, aspect, n, f)).to(dev)
    MVP = P @ V
    vp = torch.from_numpy(verts).to(dev).unsqueeze(0)
    vh = torch.cat([vp, torch.ones(1, vp.shape[1], 1, device=dev)], dim=2)
    clip = torch.einsum('ij,bvj->bvi', MVP, vh).contiguous()
    ft = torch.from_numpy(faces).to(dev).contiguous()
    uv_t = torch.from_numpy(uvs).to(dev).unsqueeze(0).contiguous()
    nrm_t = torch.from_numpy(normals).to(dev).unsqueeze(0).contiguous()

    rast_out, _ = dr.rasterize(ctx, clip, ft, resolution=(res, res))
    uv_pix, _ = dr.interpolate(uv_t, rast_out, ft)
    nrm_pix, _ = dr.interpolate(nrm_t, rast_out, ft)

    # nvdiffrast puts NDC +y at the BOTTOM row; flip every output to match render row-0=top.
    cov = np.flipud((rast_out[..., 3] > 0)[0].cpu().numpy())
    uv = np.flipud(uv_pix[0].cpu().numpy())
    nrm = np.flipud(nrm_pix[0].cpu().numpy())
    nrm /= (np.linalg.norm(nrm, axis=-1, keepdims=True) + 1e-8)
    uv[~cov] = 0.0
    nrm[~cov] = 0.0
    mask = cov.astype(np.uint8)
    return uv.astype(np.float16), nrm.astype(np.float16), mask


def rasterize_views_batched(ctx, verts, faces, uvs, normals, cam2world_list, fov_deg, res,
                            aspect=1.0, n=0.05, f=20.0, convention="opengl"):
    """Rasterize N views in ONE nvdiffrast call (per-view MVP, shared mesh). ~30x faster than
    looping rasterize_view. Returns a list of (uv[H,W,2] f16, normal[H,W,3] f16, mask[H,W] u8),
    one per input view, row 0 = top."""
    dev = torch.device("cuda")
    B = len(cam2world_list)
    cam2world_list = [cam2world_from_raw(c2w, convention) for c2w in cam2world_list]
    vp = torch.from_numpy(verts).to(dev)                       # [V,3]
    vh = torch.cat([vp, torch.ones(vp.shape[0], 1, device=dev)], dim=1)  # [V,4]
    P = torch.from_numpy(opengl_projection(fov_deg, aspect, n, f)).to(dev)
    MVPs = torch.stack([P @ torch.from_numpy(np.linalg.inv(c2w)).to(dev) for c2w in cam2world_list])  # [B,4,4]
    clip = torch.einsum("bij,vj->bvi", MVPs, vh).contiguous()   # [B,V,4]
    ft = torch.from_numpy(faces).to(dev).contiguous()
    uv_t = torch.from_numpy(uvs).to(dev).unsqueeze(0).expand(B, -1, -1).contiguous()   # [B,V,2]
    nrm_t = torch.from_numpy(normals).to(dev).unsqueeze(0).expand(B, -1, -1).contiguous()

    rast_out, _ = dr.rasterize(ctx, clip, ft, resolution=(res, res))     # [B,H,W,4]
    uv_pix, _ = dr.interpolate(uv_t, rast_out, ft)                       # [B,H,W,2]
    nrm_pix, _ = dr.interpolate(nrm_t, rast_out, ft)                     # [B,H,W,3]

    cov_all = (rast_out[..., 3] > 0).cpu().numpy()                       # [B,H,W]
    uv_all = uv_pix.cpu().numpy()
    nrm_all = nrm_pix.cpu().numpy()
    out = []
    for b in range(B):
        cov = np.flipud(cov_all[b])
        uv = np.flipud(uv_all[b]).astype(np.float32)
        nrm = np.flipud(nrm_all[b]).astype(np.float32)
        nrm /= (np.linalg.norm(nrm, axis=-1, keepdims=True) + 1e-8)
        uv[~cov] = 0.0
        nrm[~cov] = 0.0
        out.append((uv.astype(np.float16), nrm.astype(np.float16), cov.astype(np.uint8)))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hw_dir", default=str(SCRIPT_DIR / "dataset_hw_71"))
    ap.add_argument("--frozen", default=str(SCRIPT_DIR / "dataset_frozen"),
                    help="frozen set (for validation against ground-truth mask)")
    ap.add_argument("--res", type=int, default=1024)
    ap.add_argument("--near", type=float, default=0.05)
    ap.add_argument("--far", type=float, default=20.0)
    ap.add_argument("--validate", type=int, default=None,
                    help="validate one view index against the frozen mask, then exit")
    ap.add_argument("--validate_panel", action="store_true",
                    help="also dump a rgb|normal|mask panel for the validated view")
    ap.add_argument("--cam_convention", default="opengl",
                    choices=list(CAM_CONVENTIONS),
                    help="how to interpret transform_matrix: opengl/blender (default), colmap, unity, directx")
    args = ap.parse_args()

    hw = Path(args.hw_dir)
    verts, faces, uvs, normals = load_mesh(hw / "mesh.ply")
    print(f"[mesh] V={len(verts)} F={len(faces)}")
    doc = json.loads((hw / "transforms_all.json").read_text())
    fov_deg = math.degrees(doc["camera_angle_x"])
    frames = doc["frames"]
    aspect = 1.0
    print(f"[cam] fov={fov_deg:.2f}deg res={args.res} views={len(frames)} convention={args.cam_convention}")

    dev = torch.device('cuda')
    ctx = dr.RasterizeCudaContext(device=dev)

    if args.validate is not None:
        idx = args.validate
        cam2world = np.array(frames[idx]["transform_matrix"], dtype=np.float32)
        uv, nrm, mask = rasterize_view(ctx, verts, faces, uvs, normals, cam2world,
                                       fov_deg, args.res, aspect, args.near, args.far,
                                       convention=args.cam_convention)
        # frozen ground truth: frames are in sorted-index order == sorted frozen views
        views = sorted(Path(args.frozen).glob("*/*/view_*"))
        vdir = views[idx]
        gt_mask = np.array(Image.open(vdir / "mask.png").convert("L")) > 10
        pmask = mask > 0
        iou = (pmask & gt_mask).sum() / max((pmask | gt_mask).sum(), 1)
        print(f"\n[validate] idx={idx} ({vdir.name}): mask IoU = {iou:.4f}  (need >0.99)")
        if args.validate_panel:
            out = hw / "validate"; out.mkdir(exist_ok=True)
            rgb = np.array(Image.open(vdir / "rgb.png").convert("RGB"))
            ov = np.zeros((args.res, args.res, 3), np.uint8)
            ov[pmask] = [255, 0, 0]; ov[gt_mask] = [0, 255, 255]; ov[pmask & gt_mask] = [255, 255, 255]
            uvimg = np.zeros((args.res, args.res, 3), np.float32)
            uvimg[..., 0] = uv[..., 0]; uvimg[..., 1] = uv[..., 1]; uvimg[~pmask] = 0
            nrmvis = ((nrm.astype(np.float32) * 0.5 + 0.5).clip(0, 1) * 255).astype(np.uint8)
            panel = np.concatenate([rgb, nrmvis, ov, (uvimg * 255).astype(np.uint8)], axis=1)
            Image.fromarray(panel).save(out / f"panel_{idx}.png")
            print(f"  panel -> {out}/panel_{idx}.png")
        return

    # ---- rasterize all views ----
    out = hw / "raster"; out.mkdir(exist_ok=True)
    for idx, frame in enumerate(frames):
        cam2world = np.array(frame["transform_matrix"], dtype=np.float32)
        uv, nrm, mask = rasterize_view(ctx, verts, faces, uvs, normals, cam2world,
                                       fov_deg, args.res, aspect, args.near, args.far,
                                       convention=args.cam_convention)
        np.savez_compressed(out / f"{idx:04d}.npz", uv=uv, normal=nrm, mask=mask)
        if idx % 200 == 0:
            print(f"  [{idx}/{len(frames)}]")
    print(f"[done] rasterized {len(frames)} views -> {out}")


if __name__ == "__main__":
    main()
